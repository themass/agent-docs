"""Lead agent factory.

INVARIANT — tracing callback placement
======================================

Tracing callbacks (Langfuse, LangSmith) are attached at the **graph
invocation root** in :func:`_make_lead_agent` (see the
``build_tracing_callbacks()`` block that appends to ``config["callbacks"]``).
Every ``create_chat_model(...)`` call inside this module — and inside any
middleware reachable from this graph (e.g. ``TitleMiddleware``) — MUST pass
``attach_tracing=False``.

Forgetting that flag emits duplicate spans (one rooted at the graph, one at
the model) AND prevents the Langfuse handler's ``propagate_attributes``
path from firing, so ``session_id`` / ``user_id`` never reach the trace.
The five current sites are: bootstrap agent, default agent, summarization
middleware, the async path inside ``TitleMiddleware``, and the skill security
scanner reached from the ``skill_manage`` tool (``skills/security_scanner.py``'s
``scan_skill_content``, which is dual-use: ``_scan_or_raise`` in
``tools/skill_manage_tool.py`` is the in-graph choke point and passes the flag,
while its standalone callers keep the default). Any new in-graph
``create_chat_model`` call must add to this list and pass the flag.
"""

from __future__ import annotations

import logging
import secrets
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware
from langchain_core.runnables import RunnableConfig

from deerflow.agents.interaction_policy import resolve_run_interaction_policy
from deerflow.agents.lead_agent.prompt import apply_prompt_template, has_bash_tool
from deerflow.agents.middlewares.clarification_middleware import ClarificationMiddleware
from deerflow.agents.middlewares.configured_extensions import load_configured_extension_middlewares
from deerflow.agents.middlewares.loop_detection_middleware import LoopDetectionMiddleware
from deerflow.agents.middlewares.memory_middleware import MemoryMiddleware
from deerflow.agents.middlewares.model_content_compatibility_middleware import ModelContentCompatibilityMiddleware
from deerflow.agents.middlewares.model_length_finish_reason_middleware import ModelLengthFinishReasonMiddleware
from deerflow.agents.middlewares.safety_finish_reason_middleware import SafetyFinishReasonMiddleware
from deerflow.agents.middlewares.subagent_limit_middleware import SubagentLimitMiddleware
from deerflow.agents.middlewares.summarization_middleware import DeerFlowSummarizationMiddleware, create_summarization_middleware
from deerflow.agents.middlewares.terminal_response_middleware import TerminalResponseMiddleware
from deerflow.agents.middlewares.title_middleware import TitleMiddleware
from deerflow.agents.middlewares.todo_middleware import TodoMiddleware
from deerflow.agents.middlewares.token_usage_middleware import CompletedSubagentUsageMiddleware, TokenUsageMiddleware
from deerflow.agents.middlewares.tool_declarations import layer_one_outcome, narrow_declared_tools, verify_declared_tool_view
from deerflow.agents.middlewares.tool_error_handling_middleware import build_lead_runtime_middlewares
from deerflow.agents.middlewares.view_image_middleware import ViewImageMiddleware
from deerflow.agents.task_continuity.tools import append_task_continuity_tools
from deerflow.agents.thread_state import get_thread_state_schema, normalize_middleware_state_schemas
from deerflow.authz.principal import build_principal_from_context
from deerflow.authz.provider import AuthzDecision, AuthzRequest
from deerflow.authz.runtime import resolve_authorization_provider
from deerflow.authz.tool_filter import apply_tool_authorization
from deerflow.config.agents_config import load_agent_config, validate_agent_name
from deerflow.config.app_config import AppConfig, get_app_config
from deerflow.config.memory_config import should_use_memory_tools
from deerflow.config.subagents_config import (
    effective_subagent_concurrency,
    effective_total_subagents_per_run,
)
from deerflow.models import create_chat_model
from deerflow.models.reasoning import resolve_reasoning_contract, resolve_reasoning_request
from deerflow.runtime.checkpoint_mode import (
    INTERNAL_CHECKPOINT_MODE_KEY,
    freeze_checkpoint_channel_mode,
    freeze_checkpoint_snapshot_frequency,
    frozen_checkpoint_channel_mode,
    inject_checkpoint_mode,
)
from deerflow.scheduler.runtime import SCHEDULER_CAPABILITY_CONTEXT_KEY, is_scheduler_capability
from deerflow.skills.types import Skill
from deerflow.subagents.capacity import configured_subagent_max_running
from deerflow.tracing import build_tracing_callbacks

logger = logging.getLogger(__name__)

_BOOTSTRAP_SKILL_NAMES = {"bootstrap"}

# Channels whose inbound messages originate from untrusted external
# commenters (anyone on a GitHub repo, etc.) and whose run context is
# therefore unsafe for admin-shaped tools like ``update_agent``. The
# corresponding gate lives in :func:`_make_lead_agent`; the channel name
# itself is plumbed into ``run_context`` by
# ``ChannelManager._resolve_run_params``.
_WEBHOOK_CHANNELS: frozenset[str] = frozenset({"github"})


@dataclass(frozen=True)
class LeadAgentAssembly:
    """The compiled graph plus what it was assembled from.

    ``descriptor`` is typed loosely on purpose: this module is imported during
    LangGraph Server startup and must not pull the extension contract package
    into that import path.
    """

    graph: Any
    descriptor: Any
    effective_model: str | None = None


def unwrap_agent_graph(agent_result: Any) -> Any:
    """Unwrap a lead assembly, leaving any other factory result untouched.

    The Gateway factory returns ``LeadAgentAssembly(graph, descriptor)``, but a
    third-party or test factory may still return a bare graph. Type-checking
    the result rather than duck-typing ``.graph`` keeps both contracts valid.

    Lives beside the dataclass so "what counts as an assembly, and which
    attribute holds the graph" is answered in one place. Callers that must
    survive this module failing to import (the runtime worker, the Gateway's
    state accessor — both of which have to keep serving custom factories that
    never produce an assembly) guard the import and fall back to the result
    unchanged.
    """
    return agent_result.graph if isinstance(agent_result, LeadAgentAssembly) else agent_result


def _subagent_release_policy(
    app_config: AppConfig,
    *,
    enabled: bool,
    max_concurrent: int,
    max_total: int,
    allowed_subagents: list[str] | None = None,
) -> dict[str, object]:
    """Delegation limits as the run will actually enforce them.

    The per-type turn/timeout caps are read here rather than left implicit
    because a subagent config edit changes what the lead agent can spend
    without changing anything visible in the lead's own configuration.
    """
    policy: dict[str, object] = {
        "enabled": enabled,
        "max_concurrent": max_concurrent,
        "max_total": max_total,
        "type_allowlist": [],
        "runtime_limits": {},
    }
    if not enabled:
        return policy

    from deerflow.subagents import get_available_subagent_names, get_subagent_config

    type_allowlist = sorted(set(get_available_subagent_names(app_config=app_config, allowed_subagents=allowed_subagents)))
    runtime_limits: dict[str, object] = {}
    for name in type_allowlist:
        subagent_config = get_subagent_config(name, app_config=app_config)
        if subagent_config is None:
            continue
        runtime_limits[name] = {
            "max_turns": subagent_config.max_turns,
            "timeout_seconds": subagent_config.timeout_seconds,
        }
    policy["type_allowlist"] = type_allowlist
    policy["runtime_limits"] = runtime_limits
    return policy


def _resolve_runtime_option(cfg: dict, key: str, agent_value, default):
    """Resolve a runtime option with ``request > agent config > default`` precedence.

    ``key in cfg`` (not ``cfg.get(key)``) distinguishes "request omitted the
    field" from "request set it to a falsy value", so a request-supplied
    ``thinking_enabled: false`` is honored instead of falling through to the
    agent default. ``agent_value`` is used only when it is not ``None`` (a
    custom agent's unset field means "do not override" — issue #4336).
    """
    if key in cfg:
        return cfg[key]
    if agent_value is not None:
        return agent_value
    return default


def _append_named_tools_without_conflicts(tools: list, new_tools: list, *, kind: str) -> None:
    """Append tools without dropping unrelated duplicate-named tools."""
    existing_names = {getattr(tool, "name", None) for tool in tools}
    for new_tool in new_tools:
        if new_tool.name in existing_names:
            logger.warning("%s tool name %r already exists and was skipped.", kind, new_tool.name)
            continue
        tools.append(new_tool)
        existing_names.add(new_tool.name)


def _append_memory_tools_without_name_conflicts(tools: list) -> None:
    """Append memory tools without dropping unrelated duplicate-named tools."""
    from deerflow.agents.memory.tools import get_memory_tools

    _append_named_tools_without_conflicts(tools, get_memory_tools(), kind="Memory")


def _append_project_document_tools_if_pinned(tools: list, cfg: dict) -> None:
    """Append the project shelf tools only for runs with a pinned project context.

    Registration follows the admission-pinned ``PROJECT_CONTEXT_KEY`` and
    nothing else (§10.11): a non-project run never pays the tools' schema
    tokens and never sees them, while a project run keeps them even when
    instructions and shelf are both empty. The tools themselves read the same
    pinned key at call time and fail closed without it.
    """
    from deerflow.runtime.context_keys import PROJECT_CONTEXT_KEY

    if PROJECT_CONTEXT_KEY not in cfg:
        return
    from deerflow.projects.tools import get_project_document_tools

    _append_named_tools_without_conflicts(tools, get_project_document_tools(), kind="Project document")


def _get_runtime_config(config: RunnableConfig) -> dict:
    """Merge legacy configurable options with LangGraph runtime context."""
    cfg = dict(config.get("configurable", {}) or {})
    context = config.get("context", {}) or {}
    if isinstance(context, dict):
        cfg.update(context)
    return cfg


def _resolve_model_name(requested_model_name: str | None = None, *, app_config: AppConfig | None = None) -> str:
    """Resolve a runtime model name safely, falling back to default if invalid. Returns None if no models are configured."""
    app_config = app_config or get_app_config()
    default_model_name = app_config.models[0].name if app_config.models else None
    if default_model_name is None:
        raise ValueError("No chat models are configured. Please configure at least one model in config.yaml.")

    if requested_model_name and app_config.get_model_config(requested_model_name):
        return requested_model_name

    if requested_model_name and requested_model_name != default_model_name:
        logger.warning(f"Model '{requested_model_name}' not found in config; fallback to default model '{default_model_name}'.")
    return default_model_name


def _authorize_model_name(
    model_name: str,
    *,
    context: Mapping[str, Any],
    app_config: AppConfig,
) -> str:
    """Enforce ``model:use`` authorization on the resolved model name.

    When ``authorization.enabled`` is false this is a no-op (returns
    *model_name* unchanged). When enabled, the resolved model is checked
    against the provider's policy via ``authorize("model", "use")`` so the
    runtime path and the Gateway ``get_model`` route enforce the same
    action-scoped contract (matters for custom providers that distinguish
    ``list`` from ``use``). On deny, a graceful fallback to the first
    ``filter_resources``-allowed model is attempted (RFC §9: "fall back to an
    allowed default, not error, to avoid breaking runs"). If no model is
    allowed and ``fail_closed`` is true, ``ValueError`` is raised (matching
    the existing "no models configured" contract); fail-open returns the
    original name.

    Mirrors the Principal/provider pattern of ``apply_tool_authorization`` so
    the tool path and the model path share one identity source.
    """
    authz_config = app_config.authorization
    if authz_config.enabled is not True:
        return model_name

    provider = resolve_authorization_provider(authz_config)
    if provider is None:
        return model_name

    principal = build_principal_from_context(context, default_role=authz_config.default_role)
    all_names = [m.name for m in app_config.models]

    # Check the resolved model against the action-scoped ``model:use`` policy.
    # This aligns with the Gateway ``get_model`` route, which also checks
    # ``authorize("model", "use")``. For the built-in RBAC provider (which
    # ignores ``action``) this is equivalent to a membership check; for a
    # custom provider that distinguishes ``list`` from ``use``, it prevents
    # a model visible via ``filter_resources`` but denied for ``use`` from
    # being silently selected at runtime.
    try:
        decision = provider.authorize(AuthzRequest(principal=principal, resource="model", action="use", target=model_name))
        if not isinstance(decision, AuthzDecision):
            raise TypeError("AuthorizationProvider.authorize must return AuthzDecision")
        if decision.allow:
            return model_name
    except Exception:
        logger.warning("Authorization provider failed while checking model:use for '%s'", model_name, exc_info=True)
        if authz_config.fail_closed:
            raise ValueError("No models are authorized for the current role (authorization provider error).")
        return model_name

    # Denied — graceful fallback: pick the first model that ``filter_resources``
    # says is visible AND that also passes ``authorize("model", "use")``. For the
    # built-in RBAC provider (which ignores ``action``) this is equivalent to
    # picking the first visible name; for a custom provider that distinguishes
    # ``list`` from ``use``, it ensures the fallback is actually usable.
    try:
        allowed_names = provider.filter_resources(principal, "model", all_names)
        if not isinstance(allowed_names, list) or any(not isinstance(n, str) for n in allowed_names):
            raise TypeError("AuthorizationProvider.filter_resources must return list[str]")
    except Exception:
        logger.warning("Authorization provider failed while resolving allowed models", exc_info=True)
        if authz_config.fail_closed:
            raise ValueError("No models are authorized for the current role (authorization provider error).")
        return model_name

    for candidate in allowed_names:
        if candidate == model_name:
            continue  # already denied above
        try:
            cb_decision = provider.authorize(AuthzRequest(principal=principal, resource="model", action="use", target=candidate))
            if isinstance(cb_decision, AuthzDecision) and cb_decision.allow:
                logger.warning(
                    "Model '%s' is not authorized for the current role; fallback to '%s'.",
                    model_name,
                    candidate,
                )
                return candidate
        except Exception:
            logger.warning(
                "Authorization provider failed while checking model:use fallback for '%s'",
                candidate,
                exc_info=True,
            )
            if authz_config.fail_closed:
                raise ValueError("No models are authorized for the current role (authorization provider error).")
            return model_name
    if authz_config.fail_closed:
        raise ValueError("No models are authorized for the current role.")
    logger.warning("No models are authorized for the current role; fail_open allows '%s'.", model_name)
    return model_name


def _create_summarization_middleware(
    *,
    app_config: AppConfig | None = None,
    run_model_name: str | None = None,
    skip_memory_flush: bool = False,
    extensions=None,
) -> DeerFlowSummarizationMiddleware | None:
    """Create and configure the summarization middleware from config.

    ``run_model_name`` is the resolved run model; it is the source of truth for
    ``model_name: null`` summarization and the explicit-summary-model fallback, so a
    custom agent's model is used instead of ``config.models[0]``.
    """
    return create_summarization_middleware(
        app_config=app_config,
        run_model_name=run_model_name,
        skip_memory_flush=skip_memory_flush,
        extensions=extensions,
    )


def _create_todo_list_middleware(is_plan_mode: bool) -> TodoMiddleware | None:
    """Create and configure the TodoList middleware.

    Args:
        is_plan_mode: Whether to enable plan mode with TodoList middleware.

    Returns:
        TodoMiddleware instance if plan mode is enabled, None otherwise.
    """
    if not is_plan_mode:
        return None

    # Custom prompts matching DeerFlow's style
    system_prompt = """
<todo_list_system>
You have access to the `write_todos` tool to help you manage and track complex multi-step objectives.

**CRITICAL RULES:**
- Mark todos as completed IMMEDIATELY after finishing each step - do NOT batch completions
- Keep EXACTLY ONE task as `in_progress` at any time (unless tasks can run in parallel)
- Update the todo list in REAL-TIME as you work - this gives users visibility into your progress
- DO NOT use this tool for simple tasks (< 3 steps) - just complete them directly

**When to Use:**
This tool is designed for complex objectives that require systematic tracking:
- Complex multi-step tasks requiring 3+ distinct steps
- Non-trivial tasks needing careful planning and execution
- User explicitly requests a todo list
- User provides multiple tasks (numbered or comma-separated list)
- The plan may need revisions based on intermediate results

**When NOT to Use:**
- Single, straightforward tasks
- Trivial tasks (< 3 steps)
- Purely conversational or informational requests
- Simple tool calls where the approach is obvious

**Best Practices:**
- Break down complex tasks into smaller, actionable steps
- Use clear, descriptive task names
- Remove tasks that become irrelevant
- Add new tasks discovered during implementation
- Don't be afraid to revise the todo list as you learn more

**Task Management:**
Writing todos takes time and tokens - use it when helpful for managing complex problems, not for simple requests.
</todo_list_system>
"""

    tool_description = """Use this tool to create and manage a structured task list for complex work sessions.

**IMPORTANT: Only use this tool for complex tasks (3+ steps). For simple requests, just do the work directly.**

## When to Use

Use this tool in these scenarios:
1. **Complex multi-step tasks**: When a task requires 3 or more distinct steps or actions
2. **Non-trivial tasks**: Tasks requiring careful planning or multiple operations
3. **User explicitly requests todo list**: When the user directly asks you to track tasks
4. **Multiple tasks**: When users provide a list of things to be done
5. **Dynamic planning**: When the plan may need updates based on intermediate results

## When NOT to Use

Skip this tool when:
1. The task is straightforward and takes less than 3 steps
2. The task is trivial and tracking provides no benefit
3. The task is purely conversational or informational
4. It's clear what needs to be done and you can just do it

## How to Use

1. **Starting a task**: Mark it as `in_progress` BEFORE beginning work
2. **Completing a task**: Mark it as `completed` IMMEDIATELY after finishing
3. **Updating the list**: Add new tasks, remove irrelevant ones, or update descriptions as needed
4. **Multiple updates**: You can make several updates at once (e.g., complete one task and start the next)

## Task States

- `pending`: Task not yet started
- `in_progress`: Currently working on (can have multiple if tasks run in parallel)
- `completed`: Task finished successfully

## Task Completion Requirements

**CRITICAL: Only mark a task as completed when you have FULLY accomplished it.**

Never mark a task as completed if:
- There are unresolved issues or errors
- Work is partial or incomplete
- You encountered blockers preventing completion
- You couldn't find necessary resources or dependencies
- Quality standards haven't been met

If blocked, keep the task as `in_progress` and create a new task describing what needs to be resolved.

## Best Practices

- Create specific, actionable items
- Break complex tasks into smaller, manageable steps
- Use clear, descriptive task names
- Update task status in real-time as you work
- Mark tasks complete IMMEDIATELY after finishing (don't batch completions)
- Remove tasks that are no longer relevant
- **IMPORTANT**: When you write the todo list, mark your first task(s) as `in_progress` immediately
- **IMPORTANT**: Unless all tasks are completed, always have at least one task `in_progress` to show progress

Being proactive with task management demonstrates thoroughness and ensures all requirements are completed successfully.

**Remember**: If you only need a few tool calls to complete a task and it's clear what to do, it's better to just do the task directly and NOT use this tool at all.
"""

    return TodoMiddleware(system_prompt=system_prompt, tool_description=tool_description)


# ThreadDataMiddleware must be before SandboxMiddleware to ensure thread_id is available
# UploadsMiddleware should be after ThreadDataMiddleware to access thread_id
# DanglingToolCallMiddleware patches missing ToolMessages before model sees the history
# SummarizationMiddleware should be early to reduce context before other processing
# TodoListMiddleware should be before ClarificationMiddleware to allow todo management
# TitleMiddleware generates title after first exchange
# MemoryMiddleware queues conversation for memory update (after TitleMiddleware)
# ViewImageMiddleware should be before ClarificationMiddleware to inject image details before LLM
# ToolErrorHandlingMiddleware should be before ClarificationMiddleware to convert tool exceptions to ToolMessages
# ModelContentCompatibilityMiddleware sanitizes model-incompatible URL content blocks in the request view; register near the end so it sees the near-final message list
# ClarificationMiddleware should be last to intercept clarification requests after model calls
def build_middlewares(
    config: RunnableConfig,
    model_name: str | None,
    agent_name: str | None = None,
    custom_middlewares: list[AgentMiddleware] | None = None,
    *,
    available_skills: set[str] | None = None,
    memory_enabled: bool = True,
    owns_agent_skill_projection: bool = True,
    app_config: AppConfig | None = None,
    deferred_setup=None,
    mcp_routing_middleware: AgentMiddleware | None = None,
    user_id: str | None = None,
    authorization_provider=None,
    skill_authorization=None,
    extensions=None,
    subagent_execution_capacity: int | None = None,
):
    """Build the lead-agent middleware chain based on runtime configuration.

    Public entry point for the lead agent's full middleware composition. Used by
    ``make_lead_agent`` and by the embedded ``DeerFlowClient`` (a lead-agent variant
    that needs the identical chain). Keep this name stable: it is imported across a
    module boundary, so renames/signature changes ripple into ``client.py``.

    Args:
        config: Runtime configuration containing configurable options like is_plan_mode.
        model_name: Resolved runtime model name; gates vision-only middleware.
        agent_name: If provided, MemoryMiddleware will use per-agent memory storage.
        memory_enabled: Whether this agent may read or write memory. The date-only
            dynamic context remains installed when memory is disabled.
        custom_middlewares: Optional list of custom middlewares to inject into the chain.
        owns_agent_skill_projection: Whether this lead middleware chain owns the
            thread's physical skill projection. Prompt-only bootstrap agents do
            not; their narrow skill set must not replace the thread view.
        app_config: Explicit AppConfig; falls back to ``get_app_config()`` when omitted.
        deferred_setup: Optional deferred-MCP-tool setup that attaches
            ``DeferredToolFilterMiddleware`` when ``tool_search`` is enabled.
        mcp_routing_middleware: Compatibility middleware for advisory MCP
            capability metadata; schema selection requires tool_search.
        user_id: Effective user ID for user-scoped skill loading. Passed through
            to ``SkillActivationMiddleware`` so it can resolve per-user custom skills.
        authorization_provider: Provider already resolved for assembly-time
            filtering. Reused by the execution-time authorization middleware.
        skill_authorization: Provider + principal already resolved for the
            skill visibility filter. Passed through to
            ``SkillActivationMiddleware`` so explicit slash activation also
            enforces the action-scoped ``skill:activate`` decision (custom
            providers may distinguish visibility from activation).
        subagent_execution_capacity: Startup-frozen process capacity used to
            keep advertised and enforced task concurrency aligned after reloads.
        extensions: Loaded extensions whose middleware contributions are merged
            into the final stack. Defaults to the process-wide set.

    Returns:
        List of middleware instances.
    """
    resolved_app_config = app_config or get_app_config()
    from deerflow.extensions import get_agent_build_extensions

    resolved_extensions = extensions if extensions is not None else get_agent_build_extensions()
    runtime_middleware_kwargs = {
        "app_config": resolved_app_config,
        "lazy_init": True,
    }
    if available_skills is not None:
        runtime_middleware_kwargs["available_skills"] = available_skills
    if not owns_agent_skill_projection:
        runtime_middleware_kwargs["owns_agent_skill_projection"] = False
    if authorization_provider is not None:
        runtime_middleware_kwargs["authorization_provider"] = authorization_provider
    if skill_authorization is not None:
        # Shared with the runtime chain (ToolErrorHandlingMiddleware gates the
        # skill-file-load stamp on the same skill:activate decision the
        # activation middleware enforces for slash commands).
        runtime_middleware_kwargs["skill_authorization"] = skill_authorization
    if user_id is not None:
        # ToolErrorHandlingMiddleware canonicalizes skill-read paths through
        # the same user-scoped registry the activation/policy middlewares use.
        runtime_middleware_kwargs["user_id"] = user_id
    if authorization_provider is not None and deferred_setup is not None:
        runtime_middleware_kwargs["deferred_setup"] = deferred_setup
    middlewares = build_lead_runtime_middlewares(**runtime_middleware_kwargs)

    # Always inject current date (and optionally memory) as <system-reminder> into the
    # first HumanMessage to keep the system prompt fully static for prefix-cache reuse.
    from deerflow.agents.middlewares.dynamic_context_middleware import DynamicContextMiddleware

    middlewares.append(
        DynamicContextMiddleware(
            agent_name=agent_name,
            app_config=resolved_app_config,
            memory_enabled=memory_enabled,
        )
    )

    # Deterministically load a full SKILL.md when the user starts the turn with
    # /skill-name. This keeps the base system prompt metadata-only while giving
    # explicit user activation priority over model-side relevance guessing.
    from deerflow.agents.middlewares.skill_activation_middleware import SkillActivationMiddleware

    slash_source_owner_token = secrets.token_urlsafe(24)
    middlewares.append(
        SkillActivationMiddleware(
            available_skills=available_skills,
            app_config=resolved_app_config,
            user_id=user_id,
            slash_source_owner_token=slash_source_owner_token,
            skill_authorization=skill_authorization,
        )
    )

    # Observe the final tool_search Command after every inner result
    # transformer has run. Tool wrappers are first-in-list outermost, so this
    # must be registered before the deferred filter below.
    if deferred_setup is not None and deferred_setup.deferred_names:
        from deerflow.agents.middlewares.tool_promotion_audit_middleware import DeferredToolPromotionAuditMiddleware

        middlewares.append(DeferredToolPromotionAuditMiddleware(deferred_setup.deferred_names, deferred_setup.catalog_hash))

    # Capture completed task delegations and loaded skill files before
    # summarization can compact them, then inject durable context channels
    # (summary + ledger + skills) into model calls.
    from deerflow.agents.middlewares.durable_context_middleware import DurableContextMiddleware

    middlewares.append(
        DurableContextMiddleware(
            skills_container_path=resolved_app_config.skills.container_path,
            skill_file_read_tool_names=resolved_app_config.summarization.skill_file_read_tool_names,
            inject_tool_artifacts=resolved_app_config.tool_artifacts.enabled and resolved_app_config.tool_artifacts.inject_model_context,
            task_continuity_enabled=getattr(getattr(resolved_app_config, "task_continuity", None), "enabled", False) is True,
            pii_redaction_config=getattr(resolved_app_config, "pii_redaction", None),
            # The rendered "Active skills" reminder hides entries the provider
            # denies; decisions are published per step by the activation
            # middleware under the shared chain token.
            skill_authorization=skill_authorization,
            entry_decisions_owner_token=slash_source_owner_token,
        )
    )

    # Add summarization middleware if enabled
    summarization_middleware = _create_summarization_middleware(
        app_config=resolved_app_config,
        run_model_name=model_name,
        skip_memory_flush=not memory_enabled,
        extensions=resolved_extensions,
    )
    if summarization_middleware is not None:
        middlewares.append(summarization_middleware)

    # Add TodoList middleware if plan mode is enabled
    cfg = _get_runtime_config(config)
    is_plan_mode = cfg.get("is_plan_mode", False)
    todo_list_middleware = _create_todo_list_middleware(is_plan_mode)
    if todo_list_middleware is not None:
        middlewares.append(todo_list_middleware)

    # Add TokenUsageMiddleware when token_usage tracking is enabled
    if resolved_app_config.token_usage.enabled:
        middlewares.append(TokenUsageMiddleware())

    # Add TitleMiddleware
    middlewares.append(
        TitleMiddleware(
            app_config=resolved_app_config,
            extensions=resolved_extensions,
        )
    )

    # Add MemoryMiddleware after TitleMiddleware. Tool mode normally skips it;
    # conversation-extraction backends may explicitly retain passive writes.
    if memory_enabled:
        if should_use_memory_tools(resolved_app_config.memory):
            from deerflow.agents.memory.manager import backend_requires_passive_writes_in_tool_mode

            if backend_requires_passive_writes_in_tool_mode(resolved_app_config.memory.manager_class):
                middlewares.append(
                    MemoryMiddleware(
                        agent_name=agent_name,
                        memory_config=resolved_app_config.memory,
                        pii_redaction_config=getattr(resolved_app_config, "pii_redaction", None),
                    )
                )
        else:
            if resolved_app_config.memory.mode == "tool" and not resolved_app_config.memory.enabled:
                logger.warning("memory.mode is 'tool' but memory.enabled is false; memory tools will not be registered.")
            middlewares.append(
                MemoryMiddleware(
                    agent_name=agent_name,
                    memory_config=resolved_app_config.memory,
                    pii_redaction_config=getattr(resolved_app_config, "pii_redaction", None),
                )
            )

    # Add ViewImageMiddleware only if the current model supports vision.
    # Use the resolved runtime model_name from make_lead_agent to avoid stale config values.
    model_config = resolved_app_config.get_model_config(model_name) if model_name else None
    if model_config is not None and model_config.supports_vision:
        middlewares.append(ViewImageMiddleware())

    # Auto-promote deferred MCP schemas from PR1 routing metadata before the
    # deferred filter decides which schemas to hide for this model call.
    if mcp_routing_middleware is not None:
        middlewares.append(mcp_routing_middleware)

    # Hide deferred tool schemas from model binding until tool_search promotes them.
    # The lead deferred set + catalog hash come from the full build-time MCP
    # catalog. Skill `allowed-tools` is compatibility metadata only; agent
    # assembly/execution authorization owns the permission ceiling.
    if deferred_setup is not None and deferred_setup.deferred_names:
        from deerflow.agents.middlewares.deferred_tool_filter_middleware import DeferredToolFilterMiddleware

        middlewares.append(DeferredToolFilterMiddleware(deferred_setup.deferred_names, deferred_setup.catalog_hash))
        from deerflow.agents.middlewares.mcp_routing_middleware import assert_mcp_routing_before_deferred_filter

        assert_mcp_routing_before_deferred_filter(middlewares)

    # Coalesce every SystemMessage into a single leading one before the request
    # reaches the provider. Strict backends (vLLM, SGLang, Qwen, Anthropic)
    # reject non-leading SystemMessages. See system_message_coalescing_middleware.py.
    from deerflow.agents.middlewares.system_message_coalescing_middleware import SystemMessageCoalescingMiddleware

    middlewares.append(SystemMessageCoalescingMiddleware())

    # Add SubagentLimitMiddleware to truncate excess parallel task calls
    subagent_enabled = cfg.get("subagent_enabled", False)
    effective_max_subagents_per_run: int | None = None
    if subagent_enabled:
        max_concurrent_subagents = effective_subagent_concurrency(
            cfg.get("max_concurrent_subagents"),
            resolved_app_config,
            execution_capacity=subagent_execution_capacity,
        )
        max_total_subagents = effective_total_subagents_per_run(cfg.get("max_total_subagents"), resolved_app_config)
        effective_max_subagents_per_run = max_total_subagents
        middlewares.append(SubagentLimitMiddleware(max_concurrent=max_concurrent_subagents, max_total=max_total_subagents))

    # LoopDetectionMiddleware — detect and break repetitive tool call loops
    loop_detection_config = resolved_app_config.loop_detection
    if loop_detection_config.enabled:
        middlewares.append(LoopDetectionMiddleware.from_config(loop_detection_config))

    # TokenBudgetMiddleware - enforce per-run token limits
    token_budget_config = resolved_app_config.token_budget
    if token_budget_config.enabled:
        from deerflow.agents.middlewares.token_budget_middleware import TokenBudgetMiddleware

        middlewares.append(TokenBudgetMiddleware.from_config(token_budget_config))

    # https://docs.langchain.com/oss/python/langchain/middleware/custom#execution-order
    # Backfill only completed child usage before budget enforcement. Keep
    # current-step attribution after the guards that can change tool calls.
    if token_budget_config.enabled and resolved_app_config.token_usage.enabled:
        middlewares.append(CompletedSubagentUsageMiddleware())

    # Downgrade persisted URL-sourced file/image blocks (pre-fix MCP
    # ResourceLink results) that the Chat Completions serializer rejects, so
    # threads bricked before the conversion-layer fix heal at read time.
    # Request view only: state and checkpoints are never written. Appended
    # after every built-in content transform so it sanitizes the near-final
    # message list, and outer of the MODEL_PHYSICAL extension anchor so
    # extensions placed there keep their final-request guarantee.
    middlewares.append(ModelContentCompatibilityMiddleware())

    # Inject custom middlewares before ClarificationMiddleware
    if custom_middlewares:
        middlewares.extend(custom_middlewares)

    configured_middlewares = load_configured_extension_middlewares(resolved_app_config, scope="lead")
    if configured_middlewares:
        middlewares.extend(configured_middlewares)

    # LLMErrorHandlingMiddleware gives a run one model-boundary retry for a true
    # empty stop. Keep a terminal fallback for post-tool responses that still have
    # no user-visible text, without adding a graph-level recovery turn.
    middlewares.append(TerminalResponseMiddleware())

    # A provider may also cap the final assistant response at the model output
    # limit. Detector-matched caps stamp stop_reason=model_length_capped,
    # suppress that response's tool calls, and append a length notice when no
    # visible text was produced.
    middlewares.append(ModelLengthFinishReasonMiddleware())

    # SafetyFinishReasonMiddleware — suppress tool execution when the provider
    # safety-terminated the response. Registered after the terminal-response
    # and custom/configured middlewares so LangChain's reverse-order after_model
    # dispatch runs Safety first; cleared tool_calls then flow through the
    # remaining accounting/terminal guards without firing extra alarms.
    safety_config = resolved_app_config.safety_finish_reason
    if safety_config.enabled:
        middlewares.append(SafetyFinishReasonMiddleware.from_config(safety_config))

    # ClarificationMiddleware should always be last
    middlewares.append(ClarificationMiddleware())

    from deerflow.runtime.runs.input_control import run_input_control

    if run_input_control(cfg) is not None:
        from deerflow.agents.middlewares.run_input_middleware import RunInputAdmissionMiddleware, RunInputMiddleware

        # New direct input goes through the ordinary sanitization chain.
        middlewares.insert(0, RunInputAdmissionMiddleware())
        # after_agent runs in reverse order: decide whether to continue before
        # sandbox and other terminal cleanup hooks execute.
        middlewares.append(RunInputMiddleware())

    # Extension contributions are merged only here, once the full stack exists.
    # Doing it inside build_lead_runtime_middlewares() would place
    # MODEL_PHYSICAL contributions above the lead-specific middlewares appended
    # above, changing what "the final request" means for observers.
    from deerflow_extension_api import AgentScope

    from deerflow.extensions.stack import compose_with_extensions

    if not resolved_extensions.has_middleware_contributors:
        return compose_with_extensions(middlewares, AgentScope.LEAD, None, resolved_extensions)

    from deerflow_extension_api import AgentBuildContext

    from deerflow.extensions.policy import project_host_policy

    return compose_with_extensions(
        middlewares,
        AgentScope.LEAD,
        AgentBuildContext(
            scope=AgentScope.LEAD,
            agent_name=agent_name,
            model_name=model_name,
            policy=project_host_policy(
                resolved_app_config,
                token_budget_config=token_budget_config,
                max_subagents_per_run=effective_max_subagents_per_run,
            ),
        ),
        resolved_extensions,
    )


def _available_skill_names(agent_config, is_bootstrap: bool) -> set[str] | None:
    if is_bootstrap:
        return set(_BOOTSTRAP_SKILL_NAMES)
    if agent_config and agent_config.skills is not None:
        return set(agent_config.skills)
    return None


def _insert_hitl_approval_middleware(middlewares: list, final_tools: list, app_config: AppConfig, *, supports_resume: bool) -> None:
    hitl_config = getattr(app_config, "hitl_approval", None)
    if hitl_config is None or not hitl_config.enabled:
        return
    from deerflow.agents.middlewares.hitl_approval_middleware import HitlApprovalMiddleware

    known_tool_names = {tool.name for tool in final_tools}
    unknown_names = set(hitl_config.tools) - known_tool_names
    if unknown_names:
        logger.warning("hitl_approval.tools contains names not present in this build's tool set: %s", sorted(unknown_names))
    logger.info(
        "hitl_approval enabled: tools=%s non_interactive=%s max_actions=%s",
        hitl_config.tools,
        hitl_config.non_interactive,
        hitl_config.max_actions,
    )
    middlewares.insert(
        0,
        HitlApprovalMiddleware(
            tool_names=set(hitl_config.tools),
            non_interactive=hitl_config.non_interactive,
            max_actions=hitl_config.max_actions,
            supports_resume=supports_resume,
            pii_config=getattr(app_config, "pii_redaction", None),
        ),
    )


def _load_enabled_available_skills(available_skills: set[str] | None, *, app_config: AppConfig, user_id: str | None = None) -> list[Skill]:
    try:
        from deerflow.agents.lead_agent.prompt import get_enabled_skills_for_config

        skills = get_enabled_skills_for_config(app_config, user_id=user_id)
    except Exception:
        logger.exception("Failed to load enabled skills")
        raise

    if available_skills is None:
        return skills
    return [skill for skill in skills if skill.name in available_skills]


def make_lead_agent(config: RunnableConfig):
    """LangGraph graph factory; keep the signature compatible with LangGraph Server."""
    return assemble_lead_agent(config).graph


def assemble_lead_agent(
    config: RunnableConfig,
    *,
    app_config: AppConfig | None = None,
) -> LeadAgentAssembly:
    """Return the compiled lead graph together with its assembly descriptor.

    Gateway workers use this explicit assembly result so what the agent was
    built from does not have to be recovered from LangGraph private runtime
    keys or mutable graph attributes. ``make_lead_agent`` remains the
    graph-only LangGraph Server ABI declared in ``langgraph.json``.
    """
    runtime_config = _get_runtime_config(config)
    runtime_app_config = app_config or runtime_config.get("app_config")
    if not isinstance(runtime_app_config, AppConfig):
        runtime_app_config = get_app_config()
    # Mode selection precedence, pinned by test_checkpoint_mode.py:
    # - First freeze: the app config owns the process mode; a client-supplied
    #   configurable key is ignored so a direct LangGraph request cannot
    #   reconfigure (or crash) a fresh process.
    # - Once frozen: an internally injected key (run worker / gateway) or the
    #   app config must match the frozen mode; ``freeze_checkpoint_channel_mode``
    #   fails closed on any mismatch, so neither a forged key nor a config.yaml
    #   change can silently reconfigure the process.
    frozen_mode = frozen_checkpoint_channel_mode()
    if frozen_mode is None:
        requested_mode = runtime_app_config.database.checkpoint_channel_mode
    else:
        requested_mode = (config.get("configurable", {}) or {}).get(
            INTERNAL_CHECKPOINT_MODE_KEY,
            runtime_app_config.database.checkpoint_channel_mode,
        )
    mode = freeze_checkpoint_channel_mode(requested_mode)
    # The snapshot cadence travels with the mode: restart-required, frozen
    # from the app config, and deliberately not client-injectable (a forged
    # configurable key must not recompile the channel table either).
    freeze_checkpoint_snapshot_frequency(runtime_app_config.database.checkpoint_delta.snapshot_frequency)
    inject_checkpoint_mode(config, mode)
    return _assemble_lead_agent(config, app_config=runtime_app_config)


def _make_lead_agent(config: RunnableConfig, *, app_config: AppConfig):
    """Internal graph-only entry point.

    Kept as a graph-returning wrapper because callers inside the harness (and
    the model-resolution tests) want the compiled graph without the mode
    freeze that :func:`assemble_lead_agent` performs.
    """
    return _assemble_lead_agent(config, app_config=app_config).graph


def _complete_assembly(
    *,
    config: RunnableConfig,
    graph: Any,
    namespace: str,
    agent_name: str,
    requested_model: str | None,
    effective_model: str,
    model_config: object,
    model_overrides: dict[str, object] | None = None,
    thinking_enabled: bool,
    reasoning_effort: object,
    rendered_base_prompt: str,
    tools: list[object],
    middlewares: list[object],
    deferred_names: frozenset[str],
    enabled_skills: list[object],
    effective_policies: dict[str, object],
) -> LeadAgentAssembly:
    """Describe the finished graph and hand the description to observers.

    The recursion limit is folded in here rather than at either call site: it
    is a per-invocation budget the Gateway clamps, so it belongs to the
    assembly even though nothing inside the factory chose it.

    Building the descriptor hashes every tool's description and JSON schema
    and probes every middleware — real work on every assembly. Skipped
    entirely when no observer is registered to receive it, mirroring
    ``notify_agent_assembled``'s own zero-observer fast path.
    """
    from deerflow.extensions import get_agent_build_extensions

    resolved_extensions = get_agent_build_extensions()
    from deerflow.runtime.assembly_evidence import capture_requested

    if not resolved_extensions.has_agent_assembly_observers and not capture_requested():
        return LeadAgentAssembly(graph=graph, descriptor=None, effective_model=effective_model)

    from deerflow.agents.assembly_descriptor import build_assembly_descriptor
    from deerflow.extensions.notify import notify_agent_assembled

    resolved_policies = dict(effective_policies)
    resolved_policies.setdefault(
        "recursion_limit",
        config.get("recursion_limit", "framework-default"),
    )
    descriptor = build_assembly_descriptor(
        namespace=namespace,
        agent_name=agent_name,
        requested_model=requested_model,
        effective_model=effective_model,
        model_config=model_config,
        model_overrides=model_overrides,
        thinking_enabled=thinking_enabled,
        reasoning_effort=reasoning_effort,
        rendered_base_prompt=rendered_base_prompt,
        tools=tools,
        middlewares=middlewares,
        deferred_names=deferred_names,
        enabled_skills=enabled_skills,
        effective_policies=resolved_policies,
    )
    notify_agent_assembled(descriptor, resolved_extensions)
    return LeadAgentAssembly(graph=graph, descriptor=descriptor, effective_model=effective_model)


def _assemble_lead_agent(config: RunnableConfig, *, app_config: AppConfig) -> LeadAgentAssembly:
    # Lazy import to avoid circular dependency
    from deerflow.tools import get_available_tools
    from deerflow.tools.builtins import setup_agent, update_agent
    from deerflow.tools.builtins.tool_search import assemble_deferred_tools, build_mcp_routing_middleware, get_mcp_routing_hints_prompt_section
    from deerflow.tools.conversation import CONVERSATION_READER_CONTEXT_KEY

    cfg = _get_runtime_config(config)
    resolved_app_config = app_config
    mode = (config.get("configurable", {}) or {}).get(
        INTERNAL_CHECKPOINT_MODE_KEY,
        resolved_app_config.database.checkpoint_channel_mode,
    )

    # Resolve one authoritative identity for every user-scoped factory input.
    # Agent Server's reserved auth fields win over ordinary client-supplied
    # context/configurable values; the embedded Gateway path uses context.user_id.
    from deerflow.runtime.user_context import resolve_config_user_id

    resolved_user_id = resolve_config_user_id(config)

    requested_model_name: str | None = cfg.get("model_name") or cfg.get("model")
    is_plan_mode = cfg.get("is_plan_mode", False)
    requested_subagent_enabled = cfg.get("subagent_enabled", False)
    subagent_execution_capacity = configured_subagent_max_running()
    max_concurrent_subagents = effective_subagent_concurrency(
        cfg.get("max_concurrent_subagents"),
        resolved_app_config,
        execution_capacity=subagent_execution_capacity,
    )
    max_total_subagents = effective_total_subagents_per_run(cfg.get("max_total_subagents"), resolved_app_config)
    is_bootstrap = cfg.get("is_bootstrap", False)
    interaction_policy = resolve_run_interaction_policy(config)
    non_interactive = not interaction_policy.allows_clarification
    # The live host capability never comes from checkpoint-configurable data.
    runtime_context = config.get("context")
    scheduler_capability = runtime_context.get(SCHEDULER_CAPABILITY_CONTEXT_KEY) if isinstance(runtime_context, Mapping) else None
    if is_bootstrap or cfg.get("is_subagent") or not is_scheduler_capability(scheduler_capability) or scheduler_capability.mode != interaction_policy.mode.value:
        scheduler_capability = None
    agent_name = validate_agent_name(cfg.get("agent_name"))

    agent_config = load_agent_config(agent_name, user_id=resolved_user_id) if not is_bootstrap else None
    memory_enabled = getattr(agent_config, "memory_enabled", True) is not False
    # Keep compatibility with lightweight AgentConfig-shaped objects used by
    # integrations that predate caller-level subagent restrictions.
    allowed_subagents = getattr(agent_config, "allowed_subagents", None) if agent_config is not None else None
    # The request switch may disable delegation, but it can never widen the
    # server-side custom-agent policy. An explicit empty list is a hard deny.
    subagent_enabled = bool(requested_subagent_enabled and allowed_subagents != [])
    config.setdefault("configurable", {})["subagent_enabled"] = subagent_enabled
    if isinstance(config.get("context"), dict):
        config["context"]["subagent_enabled"] = subagent_enabled
    available_skills = _available_skill_names(agent_config, is_bootstrap)

    # Phase 3: enforce skill authorization (Layer 1). Filter the skill
    # allowlist by the provider's "skill" policy so denied skills never
    # appear in <skill_index>, can never be describe_skill'd, and cannot be
    # slash-activated (SkillActivationMiddleware checks this set). When
    # authorization is disabled, this is a no-op. ``available_skills=None``
    # means "no agent-level allowlist" (all enabled skills); authorization
    # still constrains via filter_resources in that case. The resolved
    # provider/principal are threaded into ``SkillActivationMiddleware`` so
    # explicit activation additionally enforces the action-scoped
    # ``skill:activate`` decision (visibility != activation for custom
    # providers).
    from deerflow.authz.skill_filter import filter_available_skills_by_authorization, resolve_skill_authorization

    skill_authorization = resolve_skill_authorization(cfg, resolved_app_config)
    # Resolve the filter's candidate names through the cached catalog loader
    # instead of letting the filter rescan storage: the enabled-skills load
    # below (``_load_enabled_available_skills``) uses the same
    # config-identity cache, so a build pays one skill-tree walk when the
    # cache is cold and none when warm — the filter's own uncached fallback
    # double-pays it on every build (notably costly on NFS/CSI roots).
    candidate_skill_names = None
    if available_skills is None and skill_authorization is not None:
        try:
            from deerflow.agents.lead_agent.prompt import get_enabled_skills_for_config

            candidate_skill_names = [s.name for s in get_enabled_skills_for_config(resolved_app_config, user_id=resolved_user_id)]
        except Exception:
            logger.warning("Failed to pre-load enabled skills for authorization candidates", exc_info=True)
            # Leave None: the filter resolves candidates itself and applies
            # its fail-closed semantics when that resolution also fails.

    available_skills = filter_available_skills_by_authorization(
        available_skills,
        context=cfg,
        app_config=resolved_app_config,
        user_id=resolved_user_id,
        candidate_skill_names=candidate_skill_names,
        authorization=skill_authorization,
    )
    # Custom agent model from agent config (if any), or None to let _resolve_model_name pick the default
    agent_model_name = agent_config.model if agent_config and agent_config.model else None

    # thinking / reasoning precedence: request > custom agent default > runtime
    # default (issue #4336). See ``_resolve_runtime_option`` for the falsy-vs-unset
    # handling.
    agent_thinking = getattr(agent_config, "thinking_enabled", None) if agent_config else None
    agent_reasoning = getattr(agent_config, "reasoning_effort", None) if agent_config else None
    thinking_enabled = bool(_resolve_runtime_option(cfg, "thinking_enabled", agent_thinking, True))
    reasoning_effort = _resolve_runtime_option(cfg, "reasoning_effort", agent_reasoning, None)

    # Per-agent sampling overrides (temperature / max_tokens) layered on top of
    # the resolved model profile (issue #4336). None when the agent set none.
    agent_model_settings = getattr(agent_config, "model_settings", None) if agent_config else None
    agent_model_overrides = agent_model_settings.model_dump(exclude_none=True) if agent_model_settings else None

    # Final model name resolution: request → agent config → global default, with fallback for unknown names
    model_name = _resolve_model_name(requested_model_name or agent_model_name, app_config=resolved_app_config)

    # Phase 3: enforce model:use authorization. On deny, fall back to the first
    # allowed model (graceful) rather than crashing the run (RFC §9).
    explicit_selection = cfg.get("model_selection_requested")
    if explicit_selection is not None:
        from deerflow.models.selection import authorize_selected_model

        if not isinstance(explicit_selection, str) or explicit_selection != requested_model_name:
            raise ValueError("An explicit model selection must carry the same model_name.")
        if explicit_selection != model_name:
            raise ValueError("The explicitly selected model is not configured.")
        authorize_selected_model(model_name, context=cfg, app_config=resolved_app_config)
    else:
        model_name = _authorize_model_name(model_name, context=cfg, app_config=resolved_app_config)

    model_config = resolved_app_config.get_model_config(model_name)

    if model_config is None:
        raise ValueError("No chat model could be resolved. Please configure at least one model in config.yaml or provide a valid 'model_name'/'model' in the request.")
    # Normalize the request against the model's reasoning contract (issue #5073)
    # so the run metadata, the assembly descriptor and the factory agree on the
    # effective policy: required-thinking models turn the flag back on, an
    # unsupported model turns it off, and a restricted effort vocabulary maps
    # the generic value onto the provider's own.
    reasoning_contract = resolve_reasoning_contract(model_config)
    resolved_reasoning = resolve_reasoning_request(reasoning_contract, thinking_enabled=thinking_enabled, reasoning_effort=reasoning_effort)
    if "thinking_unsupported" in resolved_reasoning.adjustments:
        logger.warning(f"Thinking mode is enabled but model '{model_name}' does not support it; fallback to non-thinking mode.")
    elif resolved_reasoning.adjustments:
        logger.info("Model '%s': reasoning request adjusted by its capability contract (%s)", model_name, ", ".join(resolved_reasoning.adjustments))
    thinking_enabled = resolved_reasoning.thinking_enabled
    if reasoning_contract.source == "contract":
        # Legacy profiles keep forwarding the raw request (the factory strips
        # what the profile cannot honor, exactly as before); declared
        # contracts hand the factory the provider value they resolved to.
        reasoning_effort = resolved_reasoning.reasoning_effort

    logger.info(
        "Create Agent(%s) -> thinking_enabled: %s, reasoning_effort: %s, model_name: %s, is_plan_mode: %s, subagent_enabled: %s, max_concurrent_subagents: %s, max_total_subagents: %s",
        agent_name or "default",
        thinking_enabled,
        reasoning_effort,
        model_name,
        is_plan_mode,
        subagent_enabled,
        max_concurrent_subagents,
        max_total_subagents,
    )

    # Inject run metadata for LangSmith trace tagging
    if "metadata" not in config:
        config["metadata"] = {}

    config["metadata"].update(
        {
            "agent_name": agent_name or "default",
            "model_name": model_name or "default",
            "thinking_enabled": thinking_enabled,
            "reasoning_effort": reasoning_effort,
            "is_plan_mode": is_plan_mode,
            "subagent_enabled": subagent_enabled,
            "tool_groups": agent_config.tool_groups if agent_config else None,
            "mcp_plugins": getattr(agent_config, "mcp_plugins", None),
            "available_skills": sorted(available_skills) if available_skills is not None else None,
            "allowed_subagents": list(allowed_subagents) if allowed_subagents is not None else None,
            "memory_enabled": memory_enabled,
        }
    )

    # Inject tracing callbacks at the graph invocation root so a single LangGraph
    # run produces one trace with all node / LLM / tool calls as child spans,
    # AND so the Langfuse handler sees ``on_chain_start(parent_run_id=None)`` and
    # actually propagates ``langfuse_session_id`` / ``langfuse_user_id`` from
    # ``config["metadata"]`` onto the trace. Without root-level attachment the
    # model is a nested observation and the handler strips ``langfuse_*`` keys.
    tracing_callbacks = build_tracing_callbacks()
    if tracing_callbacks:
        existing = config.get("callbacks") or []
        if not isinstance(existing, list):
            existing = list(existing)
        config["callbacks"] = [*existing, *tracing_callbacks]

    enabled_skills = _load_enabled_available_skills(available_skills, app_config=resolved_app_config, user_id=resolved_user_id)

    # Build skill search setup (deferred skill discovery).
    # Controlled by skills.deferred_discovery — independent from tool_search.enabled.
    from deerflow.skills.describe import build_skill_search_setup

    skill_search_enabled = resolved_app_config.skills.deferred_discovery
    container_base_path = resolved_app_config.skills.container_path

    if is_bootstrap:
        # Special bootstrap agent with minimal prompt for initial custom agent creation flow
        # Keep the bootstrap skill set intentionally narrow so agent creation
        # remains deterministic before the custom agent's own config exists.
        bootstrap_skills = [s for s in enabled_skills if s.name in _BOOTSTRAP_SKILL_NAMES]
        skill_setup = build_skill_search_setup(
            bootstrap_skills,
            enabled=skill_search_enabled,
            container_base_path=container_base_path,
            skill_authorization=skill_authorization,
        )
        chat_model = create_chat_model(name=model_name, thinking_enabled=thinking_enabled, app_config=resolved_app_config, attach_tracing=False)
        raw_tools = get_available_tools(model_name=model_name, subagent_enabled=subagent_enabled, app_config=resolved_app_config, chat_model=chat_model) + [setup_agent]
        configured_tools = raw_tools
        configured_tools = [tool for tool in configured_tools if tool.name not in interaction_policy.disabled_tool_names]
        authorization_candidates = [*configured_tools]
        if skill_setup.describe_skill_tool:
            authorization_candidates.append(skill_setup.describe_skill_tool)
        if memory_enabled and should_use_memory_tools(resolved_app_config.memory):
            _append_memory_tools_without_name_conflicts(authorization_candidates)
        _append_project_document_tools_if_pinned(authorization_candidates, cfg)
        append_task_continuity_tools(authorization_candidates, resolved_app_config)
        configured_tool_ids = {id(tool) for tool in configured_tools}
        authorized_tools, _authz_provider = apply_tool_authorization(
            authorization_candidates,
            context=cfg,
            app_config=resolved_app_config,
        )
        layer_one = layer_one_outcome(authorization_candidates, authorized_tools)
        configured_tools = [tool for tool in authorized_tools if id(tool) in configured_tool_ids]
        late_tools = [tool for tool in authorized_tools if id(tool) not in configured_tool_ids]
        final_tools, setup = assemble_deferred_tools(configured_tools, enabled=resolved_app_config.tool_search.enabled)
        final_tools.extend(late_tools)
        mcp_routing_middleware = build_mcp_routing_middleware(
            final_tools,
            setup,
            top_k=resolved_app_config.tool_search.auto_promote_top_k,
        )
        middlewares = build_middlewares(
            config,
            model_name=model_name,
            agent_name=agent_name,
            # The authorization-filtered bootstrap set, not the raw
            # _BOOTSTRAP_SKILL_NAMES: when policy denies "bootstrap" this is an
            # empty set, which the activation middleware's membership gate
            # treats as "no skills activatable" (a raw {"bootstrap"} would
            # re-admit the denied skill to slash activation).
            available_skills=available_skills,
            memory_enabled=memory_enabled,
            owns_agent_skill_projection=False,
            app_config=resolved_app_config,
            deferred_setup=setup,
            mcp_routing_middleware=mcp_routing_middleware,
            user_id=resolved_user_id,
            authorization_provider=_authz_provider,
            skill_authorization=skill_authorization,
            subagent_execution_capacity=subagent_execution_capacity,
        )
        middlewares, declared_authorized = narrow_declared_tools(
            middlewares,
            outcome=layer_one,
            context=cfg,
            app_config=resolved_app_config,
            authorization_provider=_authz_provider,
        )
        _insert_hitl_approval_middleware(middlewares, final_tools, resolved_app_config, supports_resume=False)
        system_prompt = apply_prompt_template(
            subagent_enabled=subagent_enabled,
            max_concurrent_subagents=max_concurrent_subagents,
            max_total_subagents=max_total_subagents,
            # Same filtered set as build_middlewares above; the legacy prompt
            # path also consults it, and an unfiltered {"bootstrap"} would let
            # the full-metadata rendering advertise a policy-denied skill.
            available_skills=available_skills,
            app_config=resolved_app_config,
            deferred_names=setup.deferred_names,
            user_id=resolved_user_id,
            # Preserve the (possibly empty) index when deferred discovery is
            # on: converting an empty set back to None would fall through to
            # the legacy full-metadata prompt, which reloads every enabled
            # skill from storage and re-advertises the denied one. When
            # deferred discovery is off, None keeps the legacy rendering and
            # the filtered available_skills above already blanks it for a
            # denial.
            skill_names=skill_setup.skill_names if skill_search_enabled else None,
            allowed_subagents=allowed_subagents,
            subagent_execution_capacity=subagent_execution_capacity,
            interaction_policy=interaction_policy,
            memory_enabled=memory_enabled,
            bash_available=has_bash_tool(authorized_tools),
        )
        bound_middlewares = normalize_middleware_state_schemas(middlewares, mode)
        verify_declared_tool_view(bound_middlewares, authorized_names=declared_authorized)
        graph = create_agent(
            model=chat_model,
            tools=final_tools,
            middleware=bound_middlewares,
            system_prompt=system_prompt,
            state_schema=get_thread_state_schema(mode),
            context_schema=dict,
        )
        return _complete_assembly(
            config=config,
            graph=graph,
            namespace="deerflow",
            agent_name="bootstrap",
            requested_model=requested_model_name or agent_model_name,
            effective_model=model_name,
            model_config=model_config,
            thinking_enabled=thinking_enabled,
            reasoning_effort=None,
            rendered_base_prompt=system_prompt,
            tools=final_tools,
            middlewares=middlewares,
            deferred_names=setup.deferred_names,
            enabled_skills=bootstrap_skills,
            effective_policies={
                "bootstrap": True,
                "non_interactive": non_interactive,
                "plan_mode": is_plan_mode,
                "subagents": _subagent_release_policy(
                    resolved_app_config,
                    enabled=subagent_enabled,
                    max_concurrent=max_concurrent_subagents,
                    max_total=max_total_subagents,
                    allowed_subagents=allowed_subagents,
                ),
                "deferred_tools": {
                    "enabled": resolved_app_config.tool_search.enabled,
                    "catalog_hash": setup.catalog_hash,
                },
                "deferred_skills": skill_search_enabled,
            },
        )

    # Custom agents can update their own SOUL.md / config via update_agent.
    # The default agent (no agent_name) does not see this tool.
    # Build skill search setup from the agent-available skills. The same
    # allowlist is enforced by the runtime policy resolver, so describe_skill
    # cannot expose a skill this custom agent is not allowed to activate.
    skill_setup = build_skill_search_setup(
        enabled_skills,
        enabled=skill_search_enabled,
        container_base_path=container_base_path,
        skill_authorization=skill_authorization,
    )
    #
    # Withhold ``update_agent`` from runs triggered by webhook channels
    # (currently only ``github``). Webhook prompts come from arbitrary
    # external commenters — anyone who can post on a configured repo and
    # types ``@<bot>`` clears the trigger gate. Exposing the tool there
    # gives that commenter a path to mutate the agent's ``tool_groups``
    # / ``SOUL.md`` / ``model``, and the change persists for every
    # subsequent run. Self-mutation belongs in operator-trusted surfaces
    # (the chat UI, the HTTP API), not in webhook fan-out.
    #
    # The channel name is plumbed into ``run_context`` by
    # ``ChannelManager._resolve_run_params``; bootstrap and direct invocations
    # leave it unset, so ``update_agent`` remains available there.
    channel_name = cfg.get("channel_name")
    is_webhook_channel = channel_name in _WEBHOOK_CHANNELS
    extra_tools = [update_agent] if agent_name and not is_webhook_channel else []
    # Resolve the model once so tool guidance uses the same effective settings.
    chat_model = create_chat_model(name=model_name, thinking_enabled=thinking_enabled, reasoning_effort=reasoning_effort, app_config=resolved_app_config, attach_tracing=False, model_overrides=agent_model_overrides)
    raw_tools = get_available_tools(
        model_name=model_name,
        groups=agent_config.tool_groups if agent_config else None,
        mcp_plugins=getattr(agent_config, "mcp_plugins", None),
        subagent_enabled=subagent_enabled,
        include_conversation_reader=callable(cfg.get(CONVERSATION_READER_CONTEXT_KEY)) and not bool(cfg.get("is_subagent")),
        **({"scheduler_capability": scheduler_capability} if scheduler_capability is not None else {}),
        app_config=resolved_app_config,
        chat_model=chat_model,
    )
    selected_child_model = cfg.get("subagent_model_name")
    if selected_child_model is not None:
        from deerflow.models.selection import authorize_selected_model, bind_selected_task_model

        if not subagent_enabled or not isinstance(selected_child_model, str):
            raise ValueError("A child model selection requires enabled subagents and a configured model name.")
        authorize_selected_model(selected_child_model, context=cfg, app_config=resolved_app_config)
        raw_tools = bind_selected_task_model(raw_tools, selected_child_model)
    configured_tools = raw_tools + extra_tools
    configured_tools = [tool for tool in configured_tools if tool.name not in interaction_policy.disabled_tool_names]
    authorization_candidates = [*configured_tools]
    if skill_setup.describe_skill_tool:
        authorization_candidates.append(skill_setup.describe_skill_tool)
    if memory_enabled and should_use_memory_tools(resolved_app_config.memory):
        _append_memory_tools_without_name_conflicts(authorization_candidates)
    _append_project_document_tools_if_pinned(authorization_candidates, cfg)
    append_task_continuity_tools(authorization_candidates, resolved_app_config)
    configured_tool_ids = {id(tool) for tool in configured_tools}
    authorized_tools, _authz_provider = apply_tool_authorization(
        authorization_candidates,
        context=cfg,
        app_config=resolved_app_config,
    )
    layer_one = layer_one_outcome(authorization_candidates, authorized_tools)
    configured_tools = [tool for tool in authorized_tools if id(tool) in configured_tool_ids]
    late_tools = [tool for tool in authorized_tools if id(tool) not in configured_tool_ids]
    final_tools, setup = assemble_deferred_tools(configured_tools, enabled=resolved_app_config.tool_search.enabled)
    final_tools.extend(late_tools)
    mcp_routing_middleware = build_mcp_routing_middleware(
        final_tools,
        setup,
        top_k=resolved_app_config.tool_search.auto_promote_top_k,
    )
    mcp_routing_hints_section = get_mcp_routing_hints_prompt_section(authorized_tools, deferred_names=setup.deferred_names)
    middlewares = build_middlewares(
        config,
        model_name=model_name,
        agent_name=agent_name,
        available_skills=available_skills,
        memory_enabled=memory_enabled,
        app_config=resolved_app_config,
        deferred_setup=setup,
        mcp_routing_middleware=mcp_routing_middleware,
        user_id=resolved_user_id,
        authorization_provider=_authz_provider,
        skill_authorization=skill_authorization,
        subagent_execution_capacity=subagent_execution_capacity,
    )
    middlewares, declared_authorized = narrow_declared_tools(
        middlewares,
        outcome=layer_one,
        context=cfg,
        app_config=resolved_app_config,
        authorization_provider=_authz_provider,
    )
    _insert_hitl_approval_middleware(middlewares, final_tools, resolved_app_config, supports_resume=not (config.get("context") or {}).get("_hitl_disabled_resume_escape", False))
    system_prompt = apply_prompt_template(
        subagent_enabled=subagent_enabled,
        max_concurrent_subagents=max_concurrent_subagents,
        max_total_subagents=max_total_subagents,
        agent_name=agent_name,
        available_skills=available_skills,
        app_config=resolved_app_config,
        deferred_names=setup.deferred_names,
        mcp_routing_hints_section=mcp_routing_hints_section,
        user_id=resolved_user_id,
        skill_names=skill_setup.skill_names or None,
        allowed_subagents=allowed_subagents,
        subagent_execution_capacity=subagent_execution_capacity,
        interaction_policy=interaction_policy,
        memory_enabled=memory_enabled,
        bash_available=has_bash_tool(authorized_tools),
    )
    bound_middlewares = normalize_middleware_state_schemas(middlewares, mode)
    verify_declared_tool_view(bound_middlewares, authorized_names=declared_authorized)
    graph = create_agent(
        model=chat_model,
        tools=final_tools,
        middleware=bound_middlewares,
        system_prompt=system_prompt,
        state_schema=get_thread_state_schema(mode),
        context_schema=dict,
    )
    return _complete_assembly(
        config=config,
        graph=graph,
        namespace="deerflow",
        agent_name=agent_name or "lead-agent",
        requested_model=requested_model_name or agent_model_name,
        effective_model=model_name,
        model_config=model_config,
        model_overrides=agent_model_overrides,
        thinking_enabled=thinking_enabled,
        reasoning_effort=reasoning_effort,
        rendered_base_prompt=system_prompt,
        tools=final_tools,
        middlewares=middlewares,
        deferred_names=setup.deferred_names,
        enabled_skills=enabled_skills,
        effective_policies={
            "bootstrap": False,
            "non_interactive": non_interactive,
            "plan_mode": is_plan_mode,
            "subagents": _subagent_release_policy(
                resolved_app_config,
                enabled=subagent_enabled,
                max_concurrent=max_concurrent_subagents,
                max_total=max_total_subagents,
                allowed_subagents=allowed_subagents,
            ),
            "deferred_tools": {
                "enabled": resolved_app_config.tool_search.enabled,
                "catalog_hash": setup.catalog_hash,
            },
            "deferred_skills": skill_search_enabled,
        },
    )
