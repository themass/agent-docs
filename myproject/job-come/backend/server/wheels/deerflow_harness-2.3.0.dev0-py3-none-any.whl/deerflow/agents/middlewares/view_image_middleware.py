"""Middleware for injecting image details into the model request."""

import base64
import hashlib
import logging
from collections.abc import Awaitable, Callable, Mapping
from pathlib import Path
from typing import override
from uuid import uuid4

from deerflow_extension_api import ContentKind, provenance_kwargs
from langchain.agents.middleware import AgentMiddleware
from langchain.agents.middleware.types import ModelCallResult, ModelRequest, ModelResponse
from langchain_core.messages import AIMessage, AnyMessage, HumanMessage, ToolMessage

from deerflow.agents.thread_state import ThreadState
from deerflow.sandbox.download import MAX_IMAGE_BYTES as _MAX_IMAGE_BYTES
from deerflow.sandbox.lease import run_sync_lifecycle_operation

logger = logging.getLogger(__name__)

_MAX_CONTEXT_IMAGES = 4
_MAX_CONTEXT_BASE64_BYTES = 28 * 1024 * 1024
_IMAGE_CONTEXT_MESSAGE_ID_PREFIX = "view-image-context:"
_IMAGE_CONTEXT_MESSAGE_MARKER_KEY = "deerflow_view_image_context"


class ViewImageMiddlewareState(ThreadState):
    """Reuse the thread state so reducer-backed keys keep their annotations."""


class ViewImageMiddleware(AgentMiddleware[ViewImageMiddlewareState]):
    """Injects image details into the model request when view_image tool calls have completed.

    This middleware:
    1. Wraps each LLM call
    2. Checks if the last assistant message contains view_image tool calls
    3. Verifies all tool calls in that message have been completed (have corresponding ToolMessages)
    4. If conditions are met, appends a human message with recent viewed image details (including base64 data)
    5. Hands the augmented request to the model so it can see and analyze the images

    This enables the LLM to automatically receive and analyze images that were loaded via view_image tool,
    without requiring explicit user prompts to describe the images.

    Injection happens in ``wrap_model_call`` on purpose: the message exists only
    in ``ModelRequest.messages`` and is never returned as a state update, so no
    checkpoint carries the base64 payload and an interrupted run cannot strand it
    in history. Do not move this back to a ``before_model``/``after_model`` pair
    -- that writes the payload into state and can only take it out again
    afterwards (see #4267).
    """

    state_schema = ViewImageMiddlewareState

    def __init__(
        self,
        *,
        max_injected_images: int = 4,
        max_injected_total_chars: int = 32_000_000,
    ) -> None:
        """Bound the per-request image context injected after view_image rounds.

        ``viewed_images`` only grows (#6825): every model call that follows a
        ``view_image`` round re-encodes and re-sends every entry ever viewed,
        so a long PDF-inspection thread pushes the request body past provider
        limits (e.g. Anthropic's 32 MB) even though each single image is
        capped. A request admits at most four images and 28 MiB of base64.
        These knobs may further cap how many images and how much payload
        (in data-url characters) may be injected per model call; admission
        runs newest-first so the most recently viewed images survive, and
        over-budget entries keep their text bullet with a placeholder, so
        nothing silently disappears. The 32M-character default keeps a single
        max-size image injectable (20 MiB source -> ~27 MB base64) while
        bounding accumulation below typical provider request limits.
        """
        self._max_injected_images = max(1, int(max_injected_images))
        self._max_injected_total_chars = max(1, int(max_injected_total_chars))

    @staticmethod
    def _is_image_context_message(message: object) -> bool:
        """Return whether a message is trusted transient image context."""
        return isinstance(message, HumanMessage) and bool(message.id) and message.id.startswith(_IMAGE_CONTEXT_MESSAGE_ID_PREFIX) and message.additional_kwargs.get(_IMAGE_CONTEXT_MESSAGE_MARKER_KEY) is True

    def _get_last_assistant_message(self, messages: list) -> AIMessage | None:
        """Get the last assistant message from the message list.

        Args:
            messages: List of messages

        Returns:
            Last AIMessage or None if not found
        """
        for msg in reversed(messages):
            if isinstance(msg, AIMessage):
                return msg
        return None

    def _has_view_image_tool(self, message: AIMessage) -> bool:
        """Check if the assistant message contains view_image tool calls.

        Args:
            message: Assistant message to check

        Returns:
            True if message contains view_image tool calls
        """
        if not hasattr(message, "tool_calls") or not message.tool_calls:
            return False

        return any(tool_call.get("name") == "view_image" for tool_call in message.tool_calls)

    def _all_tools_completed(self, messages: list, assistant_msg: AIMessage) -> bool:
        """Check if all tool calls in the assistant message have been completed.

        Args:
            messages: List of all messages
            assistant_msg: The assistant message containing tool calls

        Returns:
            True if all tool calls have corresponding ToolMessages
        """
        if not hasattr(assistant_msg, "tool_calls") or not assistant_msg.tool_calls:
            return False

        # Get all tool call IDs from the assistant message
        tool_call_ids = {tool_call.get("id") for tool_call in assistant_msg.tool_calls if tool_call.get("id")}

        # Find the index of the assistant message
        try:
            assistant_idx = messages.index(assistant_msg)
        except ValueError:
            return False

        # Get all ToolMessages after the assistant message
        completed_tool_ids = set()
        for msg in messages[assistant_idx + 1 :]:
            if isinstance(msg, ToolMessage) and msg.tool_call_id:
                completed_tool_ids.add(msg.tool_call_id)

        # Check if all tool calls have been completed
        return tool_call_ids.issubset(completed_tool_ids)

    @staticmethod
    def _encode_image_bytes(
        image_bytes: bytes,
        mime_type: str,
        expected_size: int,
        expected_sha256: str | None = None,
    ) -> str | None:
        """Validate image bytes against recorded metadata and return a data URL."""
        current_size = len(image_bytes)
        if current_size != expected_size or current_size > _MAX_IMAGE_BYTES:
            return None
        if expected_sha256 is not None and hashlib.sha256(image_bytes).hexdigest() != expected_sha256:
            return None
        base64_data = base64.b64encode(image_bytes).decode("utf-8")
        return f"data:{mime_type};base64,{base64_data}"

    @classmethod
    def _read_host_image_as_data_url(
        cls,
        actual_path: str,
        mime_type: str,
        expected_size: int,
        expected_sha256: str | None = None,
    ) -> str | None:
        """Read a validated host mirror and return a data URL, or None on failure.

        Callers must first bind ``actual_path`` to the current run's user,
        thread, and virtual image path. The host path remains the compatibility
        path for local execution and older checkpoints. Provenance-aware
        checkpoints additionally verify the exact SHA-256 before a synchronized
        host copy can stand in for bytes from an earlier sandbox generation.
        """
        try:
            file_path = Path(actual_path)
            if not file_path.exists() or not file_path.is_file():
                return None
            current_size = file_path.stat().st_size
            if current_size != expected_size or current_size > _MAX_IMAGE_BYTES:
                return None
            with open(file_path, "rb") as f:
                image_bytes = f.read()
            return cls._encode_image_bytes(
                image_bytes,
                mime_type,
                expected_size,
                expected_sha256,
            )
        except OSError:
            return None

    @classmethod
    def _read_blob_image_as_data_url(
        cls,
        blob_ref_data: Mapping[str, object] | None,
        mime_type: str,
        expected_size: int,
        expected_sha256: str | None,
    ) -> str | None:
        """Resolve a trusted checkpoint blob ref, rejecting metadata drift."""
        if blob_ref_data is None or expected_sha256 is None:
            return None

        from deerflow.storage import BlobRef, get_blob_store_if_enabled

        try:
            ref = BlobRef.model_validate(dict(blob_ref_data))
        except (TypeError, ValueError):
            return None
        if ref.kind != "viewed-image" or ref.sha256 != expected_sha256 or ref.size != expected_size or ref.content_type != mime_type:
            return None

        try:
            store = get_blob_store_if_enabled()
            if store is None:
                return None
            image_bytes = store.get_bytes(ref)
        except Exception:
            logger.warning(
                "Failed to resolve viewed image blob %s",
                ref.sha256[:12],
                exc_info=True,
            )
            return None
        return cls._encode_image_bytes(
            image_bytes,
            mime_type,
            expected_size,
            expected_sha256,
        )

    @classmethod
    def _read_image_as_data_url(
        cls,
        state: ViewImageMiddlewareState,
        image_path: str,
        actual_path: str,
        mime_type: str,
        expected_size: int,
        expected_sha256: str | None,
        source_sandbox_id: str | None,
        blob_ref_data: Mapping[str, object] | None = None,
        *,
        allow_host_copy: bool = False,
    ) -> str | None:
        """Read the exact image bytes represented by ``viewed_images`` metadata.

        A live sandbox is authoritative only for metadata recorded from that same
        sandbox generation. If the thread now points at a replacement sandbox,
        the previous image can be reconstructed from the synchronized host mirror
        only when its SHA-256 exactly matches the bytes that ``view_image`` saw.
        Legacy metadata without a digest never authorizes this cross-generation
        fallback. When no live sandbox exists, the historical host compatibility
        path remains available (digest-checked when present).
        """
        blob_data_url = cls._read_blob_image_as_data_url(
            blob_ref_data,
            mime_type,
            expected_size,
            expected_sha256,
        )
        if blob_data_url is not None:
            return blob_data_url

        from deerflow.sandbox.overwrite import unwrap_sandbox
        from deerflow.sandbox.sandbox_provider import get_sandbox_provider

        sandbox_state, _ = unwrap_sandbox(state.get("sandbox"))
        sandbox_id = sandbox_state.get("sandbox_id") if isinstance(sandbox_state, dict) else None
        sandbox = get_sandbox_provider().get(sandbox_id) if sandbox_id else None

        if sandbox is not None:
            provenance_matches_live = source_sandbox_id == sandbox_id
            provenance_identifies_other_source = expected_sha256 is not None and source_sandbox_id != sandbox_id

            if provenance_identifies_other_source:
                # The current client belongs to a different generation (or the
                # image was originally read from the host). Reproduce the exact
                # historical bytes rather than letting an unrelated same-path
                # file in the replacement sandbox win.
                if actual_path and allow_host_copy:
                    host_data_url = cls._read_host_image_as_data_url(
                        actual_path,
                        mime_type,
                        expected_size,
                        expected_sha256,
                    )
                    if host_data_url is not None:
                        return host_data_url
                try:
                    image_bytes = sandbox.download_file(image_path, max_bytes=_MAX_IMAGE_BYTES)
                except Exception:
                    logger.warning(
                        "Failed to recover viewed image %s from replacement sandbox %s",
                        image_path,
                        sandbox_id,
                        exc_info=True,
                    )
                    return None
                return cls._encode_image_bytes(
                    image_bytes,
                    mime_type,
                    expected_size,
                    expected_sha256,
                )

            if not provenance_matches_live and expected_sha256 is None:
                # A legacy checkpoint cannot prove which sandbox generation
                # supplied these bytes. Do not silently reinterpret historical
                # image context through a newly active remote filesystem.
                return None

            try:
                image_bytes = sandbox.download_file(image_path, max_bytes=_MAX_IMAGE_BYTES)
            except Exception:
                logger.warning("Failed to read viewed image %s from sandbox %s", image_path, sandbox_id, exc_info=True)
                return None
            return cls._encode_image_bytes(
                image_bytes,
                mime_type,
                expected_size,
                expected_sha256,
            )

        if not actual_path or not allow_host_copy:
            return None
        return cls._read_host_image_as_data_url(
            actual_path,
            mime_type,
            expected_size,
            expected_sha256,
        )

    def _create_image_details_message(
        self,
        state: ViewImageMiddlewareState,
        *,
        host_path_allowed: Callable[[str, str], bool] | None = None,
    ) -> list[str | dict]:
        """Create bounded image context, prioritizing the most recently viewed paths.

        Reads image files on-demand from the active sandbox when available and
        encodes them as base64 for the model. The base64 data is NOT persisted in
        state -- only lightweight metadata (path, mime_type, size, digest, and
        source sandbox id when applicable) is stored in ``viewed_images``,
        avoiding large duplicate payloads across every checkpoint (see #4138).

        Content blocks are emitted oldest-first, but budget admission itself
        runs newest-first (reversed insertion order) so the most recently
        viewed images survive the caps (see #6825); an entry over budget keeps
        its text bullet plus a placeholder instead of its base64 payload.

        Args:
            state: Current state containing viewed_images

        Returns:
            List of content blocks (text and images) for the HumanMessage
        """
        viewed_images = state.get("viewed_images", {})
        if not viewed_images:
            # Return a properly formatted text block, not a plain string array
            return [{"type": "text", "text": "No images have been viewed."}]

        # Select newest first so older entries cannot consume the budget before
        # the image that triggered this model call. Preserve chronological
        # output and the upstream per-image omission placeholders.
        content_blocks: list[str | dict] = [{"type": "text", "text": "Here are the images you've viewed:"}]
        selected: list[list[dict]] = []
        encoded_bytes = 0
        admitted_chars = 0
        attempted_images = 0
        omitted = 0
        for image_path, image_data in reversed(list(viewed_images.items())):
            mime_type = image_data.get("mime_type", "unknown")
            actual_path = image_data.get("actual_path", "")
            expected_size = image_data.get("size", 0)
            expected_sha256 = image_data.get("sha256")
            source_sandbox_id = image_data.get("source_sandbox_id")
            blob_ref = image_data.get("blob_ref")

            estimated_bytes = 4 * ((expected_size + 2) // 3) if isinstance(expected_size, int) and expected_size >= 0 else _MAX_CONTEXT_BASE64_BYTES + 1
            estimated_chars = estimated_bytes + len(f"data:{mime_type};base64,")
            blocks = [{"type": "text", "text": f"\n- **{image_path}** ({mime_type})"}]
            # Failed reads also consume slots, bounding potentially remote read attempts.
            if attempted_images >= min(_MAX_CONTEXT_IMAGES, self._max_injected_images) or encoded_bytes + estimated_bytes > _MAX_CONTEXT_BASE64_BYTES or admitted_chars + estimated_chars > self._max_injected_total_chars:
                omitted += 1
                blocks.append({"type": "text", "text": "  (omitted: image injection budget reached; call view_image again to re-view this image)"})
                selected.append(blocks)
                continue
            attempted_images += 1
            admitted_chars += estimated_chars

            # Read the image file on-demand and encode as base64 for the model
            data_url = self._read_image_as_data_url(
                state,
                image_path,
                actual_path,
                mime_type,
                expected_size,
                expected_sha256 if isinstance(expected_sha256, str) else None,
                source_sandbox_id if isinstance(source_sandbox_id, str) else None,
                blob_ref if isinstance(blob_ref, Mapping) else None,
                allow_host_copy=host_path_allowed(image_path, actual_path) if host_path_allowed is not None else False,
            )
            if data_url:
                encoded_bytes += estimated_bytes
                blocks.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": data_url},
                    }
                )
            else:
                blocks.append({"type": "text", "text": f"  (file unavailable or changed: {image_path})"})
            selected.append(blocks)

        if omitted:
            content_blocks.append({"type": "text", "text": f"Omitted viewed images: {omitted}. Call view_image again to inspect a specific image."})
        for blocks in reversed(selected):
            content_blocks.extend(blocks)

        return content_blocks

    def _should_inject_image_message(self, messages: list[AnyMessage]) -> bool:
        """Determine if we should append an image details message.

        Args:
            messages: Messages about to be sent to the model

        Returns:
            True if we should append the message
        """
        if not messages:
            return False

        # Get the last assistant message
        last_assistant_msg = self._get_last_assistant_message(messages)
        if not last_assistant_msg:
            return False

        # Check if it has view_image tool calls
        if not self._has_view_image_tool(last_assistant_msg):
            return False

        # Check if all tools have been completed
        if not self._all_tools_completed(messages, last_assistant_msg):
            return False

        # Skip when image details are already present. ``_inject`` has stripped
        # this middleware's own messages by now, so what remains are unmarked
        # ones from checkpoints written before the marker existed -- those cannot
        # be told apart from user-authored text with certainty, so they are left
        # in place and simply not duplicated.
        assistant_idx = messages.index(last_assistant_msg)
        for msg in messages[assistant_idx + 1 :]:
            if isinstance(msg, HumanMessage):
                content_str = str(msg.content)
                if "Here are the images you've viewed" in content_str or "Here are the details of the images you've viewed" in content_str:
                    # Already added, don't add again
                    return False

        return True

    @staticmethod
    def _create_image_context_message(content: list[str | dict]) -> HumanMessage:
        """Create an identifiable, model-only image context message."""
        return HumanMessage(
            id=f"{_IMAGE_CONTEXT_MESSAGE_ID_PREFIX}{uuid4().hex}",
            content=content,
            additional_kwargs={
                "hide_from_ui": True,
                _IMAGE_CONTEXT_MESSAGE_MARKER_KEY: True,
                **provenance_kwargs(ContentKind.IMAGE_PAYLOAD, "view_image"),
            },
        )

    @staticmethod
    def _authorization_context(request: ModelRequest) -> Mapping:
        context = getattr(request.runtime, "context", None)
        return context if isinstance(context, Mapping) else {}

    @classmethod
    def _host_path_matches_request(cls, request: ModelRequest, image_path: str, actual_path: str) -> bool:
        """Bind a stored host copy to the authenticated run's user and thread."""
        from deerflow.config.paths import VIRTUAL_PATH_PREFIX, get_paths
        from deerflow.runtime.user_context import resolve_runtime_user_id
        from deerflow.sandbox.tools import resolve_and_validate_user_data_path, validate_local_tool_path
        from deerflow.tools.builtins.view_image_tool import _is_allowed_image_virtual_path

        if not isinstance(image_path, str) or not isinstance(actual_path, str) or not _is_allowed_image_virtual_path(image_path):
            return False

        from langgraph.config import get_config

        context_thread_id = cls._authorization_context(request).get("thread_id")
        try:
            configurable = get_config().get("configurable")
            configured_thread_id = configurable.get("thread_id") if isinstance(configurable, Mapping) else None
        except RuntimeError:
            configured_thread_id = None
        if configured_thread_id and context_thread_id and configured_thread_id != context_thread_id:
            return False
        thread_id = configured_thread_id or context_thread_id
        if not isinstance(thread_id, str) or not thread_id:
            return False

        try:
            user_id = resolve_runtime_user_id(request.runtime)
            thread_data = (request.state or {}).get("thread_data")
            if isinstance(thread_data, Mapping):
                # ThreadDataMiddleware may use a custom Paths base. Bind its
                # selected root to this run before using it to resolve a host copy.
                root_name = image_path.removeprefix(f"{VIRTUAL_PATH_PREFIX}/").split("/", 1)[0]
                root_path = thread_data.get(f"{root_name}_path")
                if not isinstance(root_path, str) or not root_path:
                    return False
                root = Path(root_path).resolve()
                if root.parts[-6:] != ("users", user_id, "threads", thread_id, "user-data", root_name):
                    return False
                validate_local_tool_path(image_path, thread_data, read_only=True)
                expected_path = Path(resolve_and_validate_user_data_path(image_path, thread_data))
            else:
                expected_path = get_paths().resolve_virtual_path(thread_id, image_path, user_id=user_id)
            return Path(actual_path).resolve() == expected_path
        except (OSError, PermissionError, TypeError, ValueError):
            return False

    def _image_injection_plan(self, request: ModelRequest) -> tuple[list[AnyMessage], bool, bool]:
        """Share message cleanup and read eligibility across sync/async paths."""
        messages = [message for message in request.messages if not self._is_image_context_message(message)]
        should_inject = self._should_inject_image_message(messages)
        needs_authorization = should_inject and bool((request.state or {}).get("viewed_images"))
        return messages, should_inject, needs_authorization

    def _inject(self, request: ModelRequest, *, authorization_checked: bool = False) -> ModelRequest:
        """Rebuild the request's image context from ``viewed_images``.

        Args:
            request: The pending model request
            authorization_checked: True only after ``awrap_model_call`` has
                enforced ``sandbox:execute`` for this exact request; skips the
                synchronous recheck inside its worker thread.

        Returns:
            A request whose messages carry exactly the image context this call
            warrants -- one freshly built message, or none -- leaving the
            original request untouched when there is nothing to change
        """
        # This middleware owns the image context and rebuilds it from
        # ``viewed_images`` on every call, so drop any copy already in the list.
        # A thread checkpointed by the earlier before_model/after_model pair can
        # carry one that reached state but was never removed (the run died during
        # the model call); left in place it would ride along in every later
        # request for the life of the thread. Matching requires both the reserved
        # ID prefix and the server-owned marker, and Gateway strips that marker
        # from client input, so this can never drop a user-authored message.
        messages, should_inject, needs_authorization = self._image_injection_plan(request)
        dropped_stranded = len(messages) != len(request.messages)
        if dropped_stranded:
            logger.debug("Dropping %d stranded image context message(s) from the model request", len(request.messages) - len(messages))

        if not should_inject:
            return request.override(messages=messages) if dropped_stranded else request

        if needs_authorization and not authorization_checked:
            from deerflow.authz.sandbox_authz import authorize_sandbox_execution, safe_app_config
            from deerflow.sandbox.exceptions import SandboxAuthorizationError

            try:
                authorize_sandbox_execution(context=self._authorization_context(request), app_config=safe_app_config())
            except SandboxAuthorizationError:
                # A restored view may predate a role/policy change. Never read
                # its host mirror or remote sandbox for an unauthorized request.
                return request.override(messages=messages) if dropped_stranded else request

        # Mixed content (text + images) for the model only, so hide it from the
        # chat UI and IM channels (matches the other middleware-injected context
        # messages) even though it never leaves this request.
        image_content = self._create_image_details_message(
            request.state or {},
            host_path_allowed=lambda image_path, actual_path: self._host_path_matches_request(request, image_path, actual_path),
        )
        logger.debug("Injecting image details message with images into the model request")

        return request.override(messages=[*messages, self._create_image_context_message(image_content)])

    @override
    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelCallResult:
        # Sync injection executes inline on this call stack. There is no detached
        # worker to drain: an outer sandbox lease cannot reach its finally/release
        # boundary until this blocking read returns or raises.
        return handler(self._inject(request))

    @override
    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        # Image reads + base64 encoding can be slow (up to 20MB), so offload the
        # blocking work without allowing cancellation to outlive a sandbox
        # client operation. The outer run lease may release the client as soon as
        # cancellation propagates.
        messages, _, needs_authorization = self._image_injection_plan(request)
        if needs_authorization:
            from deerflow.authz.sandbox_authz import authorize_sandbox_execution_async, safe_app_config_async
            from deerflow.sandbox.exceptions import SandboxAuthorizationError

            try:
                await authorize_sandbox_execution_async(context=self._authorization_context(request), app_config=await safe_app_config_async())
            except SandboxAuthorizationError:
                # Still sweep any old model-only image context before handing
                # the request on; do not schedule a read in a worker.
                return await handler(request.override(messages=messages))

        injected_request = await run_sync_lifecycle_operation(self._inject, request, authorization_checked=True)
        return await handler(injected_request)
