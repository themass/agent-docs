"""HarnessGuard tool-loop interceptor middleware.

Provides:
1. Optional Write-Verify Gate: Pre-execution syntax validation on .py (ast.parse) and .json writes
   for str_replace (spliced verification on valid files; opt-in).
2. Error Signature Classifier: Detects classic failure patterns and injects actionable Targeted Hints.
3. Anti-Doom-Loop: Detects consecutive identical error signatures and A -> B -> A -> B alternating failure loops,
   scoped cleanly by (thread_id, run_id) with bounded LRU tracking.
"""

from __future__ import annotations

import ast
import asyncio
import json
import logging
import re
import threading
import uuid
from collections import OrderedDict, deque
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, override

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import ToolMessage
from langgraph.prebuilt.tool_node import ToolCallRequest
from langgraph.types import Command

from deerflow.agents.middlewares._bounded_dict import BoundedDict
from deerflow.agents.middlewares.tool_result_meta import (
    TOOL_META_KEY,
    _command_messages,
    normalize_tool_result,
)
from deerflow.agents.middlewares.tool_transform_meta import append_tool_transform
from deerflow.config.harness_guard_config import HarnessGuardConfig
from deerflow.sandbox.tools import _match_line_endings, read_current_file_content

logger = logging.getLogger(__name__)

HARNESS_GUARD_KEY = "deerflow_harness_guard"
_WRITE_TOOLS = frozenset({"str_replace"})

type _ScopeKey = tuple[str, str | None]


@dataclass(frozen=True)
class ErrorSignature:
    """Classified error pattern with actionable remediation hint."""

    category: str
    entity: str
    signature: str
    targeted_hint: str


def classify_tool_error(content: str) -> ErrorSignature | None:
    """Analyze tool output content for classic failure patterns and produce targeted hints."""
    if not content or not isinstance(content, str):
        return None

    # Defensive bound: scan recent tail (where tracebacks terminate) to prevent excessive latency
    if len(content) > 50000:
        content = content[-50000:]

    # 1. ModuleNotFoundError / ImportError
    match_import_from = re.search(
        r"ImportError:\s+cannot import name\s+['\"][^'\"]+['\"]\s+from\s+['\"]([^'\"]+)['\"]",
        content,
    )
    if match_import_from:
        pkg = match_import_from.group(1).split(".")[0]
        return ErrorSignature(
            category="MODULE_NOT_FOUND",
            entity=pkg,
            signature=f"MODULE_NOT_FOUND:{pkg}",
            targeted_hint=(
                f"[HARNESS GUARD] Missing Python dependency or symbol '{pkg}'. This output does not establish the cause or the correct distribution. Inspect the environment, source and dependency declarations before choosing a remedy."
            ),
        )

    match = re.search(
        r"(?:ModuleNotFoundError|ImportError):\s+(?:No module named)\s+['\"]([^'\"]+)['\"]",
        content,
    )
    if match:
        pkg = match.group(1).split(".")[0]
        return ErrorSignature(
            category="MODULE_NOT_FOUND",
            entity=pkg,
            signature=f"MODULE_NOT_FOUND:{pkg}",
            targeted_hint=(f"[HARNESS GUARD] Missing Python dependency '{pkg}'. The import name does not establish a distribution name. Inspect the interpreter, project source and dependency declarations before choosing a remedy."),
        )

    # 2. Command not found
    match = re.search(
        r"(?:/bin/sh:\s+|bash:\s+)?(\b[\w\-.]+\b):\s+command not found|"
        r"['\"]?(\b[\w\-.]+\b)['\"]?\s+(?:is not recognized as an internal or external command|不是内部或外部命令)",
        content,
    )
    if match:
        cmd = match.group(1) or match.group(2)
        return ErrorSignature(
            category="COMMAND_NOT_FOUND",
            entity=cmd,
            signature=f"COMMAND_NOT_FOUND:{cmd}",
            targeted_hint=(f"[HARNESS GUARD] Command '{cmd}' was not found in environment. Inspect command resolution and the environment before choosing a remedy."),
        )

    # 3. FileNotFoundError / No such file
    match = re.search(
        r"(?:FileNotFoundError:\s+\[Errno 2\]\s+No such file or directory:\s+['\"]([^'\"]+)['\"]|"
        r"(?:cat|ls|head|tail):\s+['\"]?([^:'\"]+)['\"]?:\s+No such file or directory)",
        content,
    )
    if match:
        path = match.group(1) or match.group(2)
        return ErrorSignature(
            category="FILE_NOT_FOUND",
            entity=path,
            signature=f"FILE_NOT_FOUND:{path}",
            targeted_hint=(f"[HARNESS GUARD] File '{path}' does not exist. Inspect the requested path and working directory before choosing a remedy."),
        )

    # 4. SyntaxError in execution output
    if "SyntaxError:" in content:
        line_match = re.search(r"line\s+(\d+)", content)
        line = line_match.group(1) if line_match else "?"
        msg_match = re.search(r"SyntaxError:\s*([^\n\r]+)", content)
        msg = msg_match.group(1).strip() if msg_match else "invalid syntax"
        return ErrorSignature(
            category="SYNTAX_ERROR",
            entity=line,
            signature=f"SYNTAX_ERROR:line_{line}",
            targeted_hint=(f"[HARNESS GUARD] Python SyntaxError detected at line {line}: '{msg}'. Inspect the actual source and parser diagnostic before choosing a remedy."),
        )

    # 5. PermissionError
    match = re.search(
        r"(?:PermissionError:\s+\[Errno 13\]\s+Permission denied:\s+['\"]([^'\"]+)['\"]|"
        r"bash:\s+([^:]+):\s+Permission denied)",
        content,
    )
    if match:
        path = match.group(1) or match.group(2)
        return ErrorSignature(
            category="PERMISSION_DENIED",
            entity=path,
            signature=f"PERMISSION_DENIED:{path}",
            targeted_hint=(f"[HARNESS GUARD] Permission denied on '{path}'. Inspect the operation, ownership and access policy before choosing a remedy."),
        )

    # 6. Address / Port already in use
    if re.search(r"(?:Address already in use|port\s+\d+\s+already in use|Errno 98)", content):
        return ErrorSignature(
            category="PORT_IN_USE",
            entity="port",
            signature="PORT_IN_USE",
            targeted_hint=("[HARNESS GUARD] Network port is already in use. Inspect the bind address and listener ownership before choosing a remedy."),
        )

    return None


def verify_content_syntax(file_path: str, content: str) -> str | None:
    """Validate content syntax for known formats. Returns error message if invalid."""
    if not file_path or not content:
        return None

    if file_path.endswith(".py"):
        try:
            ast.parse(content, filename=file_path)
        except SyntaxError as e:
            return f"Python syntax error at line {e.lineno}, col {e.offset}: {e.msg}"
        except ValueError as e:
            return f"Python source code error: {e}"

    elif file_path.endswith(".json"):
        try:
            json.loads(content)
        except Exception as e:
            return f"Invalid JSON format: {e}"

    return None


def _extract_text_content(content: Any) -> str:
    """Extract plain text from string or structured content block list."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        texts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(str(block.get("text") or ""))
            elif isinstance(block, str):
                texts.append(block)
        return "\n".join(texts)
    return str(content) if content is not None else ""


@dataclass
class _ToolRecord:
    tool_name: str
    is_error: bool
    error_signature: str | None


class HarnessGuardMiddleware(AgentMiddleware):
    """Tool-loop interceptor for write syntax verification, error hints, and anti-doom-loop."""

    def __init__(self, config: HarnessGuardConfig | None = None) -> None:
        self.config = config if config is not None else HarnessGuardConfig()
        self._lock = threading.Lock()
        self._fallback_run_ids: OrderedDict[int, tuple[object, str]] = OrderedDict()
        self._max_fallback_run_ids = max(1, self.config.max_tracked_scopes * 2)
        # Bounded LRU history: _ScopeKey -> deque of _ToolRecord
        self._history: BoundedDict[_ScopeKey, deque[_ToolRecord]] = BoundedDict(maxsize=self.config.max_tracked_scopes)

    def _get_history(self, scope_key: _ScopeKey) -> deque[_ToolRecord]:
        with self._lock:
            if scope_key not in self._history:
                self._history[scope_key] = deque(maxlen=self.config.max_loop_history)
            return self._history[scope_key]

    def _get_thread_id(self, runtime: Any) -> str:
        ctx = getattr(runtime, "context", None)
        if isinstance(ctx, dict):
            thread_id = ctx.get("thread_id")
            if isinstance(thread_id, str) and thread_id:
                return thread_id
        return "default"

    def _get_run_id(self, runtime: Any) -> str | None:
        ctx = getattr(runtime, "context", None)
        if isinstance(ctx, dict) and "run_id" in ctx:
            return ctx["run_id"]

        execution_info = getattr(runtime, "execution_info", None)
        execution_run_id = getattr(execution_info, "run_id", None)
        if execution_run_id is not None:
            return str(execution_run_id)

        # Standalone context-less run: anchor to Runtime.control
        control = getattr(runtime, "control", None)
        anchor = control if control is not None else runtime
        anchor_id = id(anchor)
        with self._lock:
            existing = self._fallback_run_ids.get(anchor_id)
            if existing is not None and existing[0] is anchor:
                self._fallback_run_ids.move_to_end(anchor_id)
                return existing[1]

            fallback_run_id = f"__invocation__:{uuid.uuid4().hex}"
            self._fallback_run_ids[anchor_id] = (anchor, fallback_run_id)
            self._fallback_run_ids.move_to_end(anchor_id)
            while len(self._fallback_run_ids) > self._max_fallback_run_ids:
                self._fallback_run_ids.popitem(last=False)
            return fallback_run_id

    def _scope_key(self, request: ToolCallRequest) -> _ScopeKey:
        return self._get_thread_id(request.runtime), self._get_run_id(request.runtime)

    def _check_write_syntax_block(self, request: ToolCallRequest) -> ToolMessage | None:
        """Perform pre-execution syntax validation on write operations."""
        if not self.config.write_verify_syntax or not self.config.block_on_syntax_error:
            return None

        tool_name = str(request.tool_call.get("name") or "")
        if tool_name not in _WRITE_TOOLS:
            return None

        args = request.tool_call.get("args") or {}
        if not isinstance(args, dict):
            return None

        file_path = args.get("path") or args.get("file_path") or args.get("filename")
        if not isinstance(file_path, str) or not file_path:
            return None

        err: str | None = None

        if tool_name == "str_replace":
            old_str = args.get("old_str")
            new_str = args.get("new_str")
            if isinstance(old_str, str) and isinstance(new_str, str) and (file_path.endswith(".py") or file_path.endswith(".json")):
                try:
                    current = read_current_file_content(request.runtime, file_path)
                    old_str, new_str = _match_line_endings(current, old_str, new_str)
                    if old_str in current and verify_content_syntax(file_path, current) is None:
                        replace_all = bool(args.get("replace_all", False))
                        spliced = current.replace(old_str, new_str) if replace_all else current.replace(old_str, new_str, 1)
                        err = verify_content_syntax(file_path, spliced)
                except Exception:
                    # Fail open on sandbox read errors and let str_replace handle execution
                    err = None

        if err and self.config.block_on_syntax_error:
            tool_call_id = str(request.tool_call.get("id") or "missing-id")
            logger.warning("HarnessGuard blocked syntax-invalid write to %s: %s", file_path, err)
            msg = ToolMessage(
                content=(f"[HARNESS GUARD: WRITE BLOCKED] Syntax validation failed for '{file_path}':\n{err}\nThe file was NOT written to prevent execution failures. Fix the syntax and retry."),
                tool_call_id=tool_call_id,
                name=tool_name,
                status="error",
                additional_kwargs={
                    HARNESS_GUARD_KEY: {
                        "blocked": True,
                        "reason": "syntax_error",
                        "detail": err,
                        "path": file_path,
                    },
                    TOOL_META_KEY: {
                        "status": "error",
                        "error_type": "SyntaxError",
                        "recoverable_by_model": True,
                        "recommended_next_action": "correct_syntax_and_retry",
                        "source": "harness_guard",
                    },
                },
            )
            return normalize_tool_result(msg)

        return None

    def _post_process_tool_message(
        self,
        request: ToolCallRequest,
        result: ToolMessage,
    ) -> ToolMessage:
        """Analyze tool result, classify error signatures, inject hints, and detect loops."""
        tool_name = str(request.tool_call.get("name") or result.name or "unknown")
        raw_text = _extract_text_content(result.content)
        tool_meta = result.additional_kwargs.get(TOOL_META_KEY) if hasattr(result, "additional_kwargs") and isinstance(result.additional_kwargs, dict) else None
        is_error = getattr(result, "status", "success") == "error" or (isinstance(tool_meta, dict) and tool_meta.get("status") == "error")

        error_sig: ErrorSignature | None = None
        if is_error and self.config.targeted_hints_enabled:
            error_sig = classify_tool_error(raw_text)

        # Update sliding history
        scope = self._scope_key(request)
        history = self._get_history(scope)

        sig_str = error_sig.signature if error_sig else None
        record = _ToolRecord(tool_name=tool_name, is_error=is_error, error_signature=sig_str)

        repetition_warning: str | None = None
        oscillation_warning: str | None = None

        with self._lock:
            # Check consecutive identical error signatures
            if sig_str:
                matching_streak = 0
                for r in reversed(history):
                    if r.error_signature == sig_str:
                        matching_streak += 1
                    else:
                        break
                # Current call adds 1
                if matching_streak + 1 >= self.config.max_repeated_error_signatures:
                    repetition_warning = f"[HARNESS GUARD: CRITICAL REPETITION] Error '{sig_str}' has occurred {matching_streak + 1} times consecutively. Do NOT repeat this action without addressing the root cause."

            # Check alternating oscillation pattern (A -> B -> A -> B). Only
            # failures form the loop: a success ends it, its content must reach
            # the model unchanged, and a window containing it is not a loop.
            if self.config.detect_alternating_loops and is_error and len(history) >= 3:
                h = list(history)
                r0, r1, r2, r3 = h[-3], h[-2], h[-1], record
                if r0.tool_name == r2.tool_name and r1.tool_name == r3.tool_name and r0.tool_name != r1.tool_name and all(r.is_error for r in (r0, r1, r2)):
                    oscillation_warning = f"[HARNESS GUARD: OSCILLATION DETECTED] Alternating failing tool loop detected between '{r0.tool_name}' and '{r1.tool_name}'. Pause and re-evaluate your strategy."

            history.append(record)

        # Inject hints into ToolMessage content while preserving structured content blocks
        injected_parts: list[str] = []
        if error_sig:
            injected_parts.append(error_sig.targeted_hint)
        if repetition_warning:
            injected_parts.append(repetition_warning)
        if oscillation_warning:
            injected_parts.append(oscillation_warning)

        if injected_parts:
            hint_block_text = "\n\n" + "\n".join(injected_parts)
            if isinstance(result.content, list):
                # Multimodal or content blocks: append hint as a new text block
                new_blocks = list(result.content)
                new_blocks.append({"type": "text", "text": hint_block_text})
                result.content = new_blocks
            elif isinstance(result.content, str):
                separator = "\n\n" if result.content else ""
                result.content = f"{result.content}{separator}{chr(10).join(injected_parts)}"
            else:
                result.content = f"{result.content}{hint_block_text}"

            append_tool_transform(result.additional_kwargs, "diagnostic_observation", by="HarnessGuardMiddleware", version="2")
            if HARNESS_GUARD_KEY not in result.additional_kwargs:
                result.additional_kwargs[HARNESS_GUARD_KEY] = {}
            result.additional_kwargs[HARNESS_GUARD_KEY].update(
                {
                    "hints_injected": len(injected_parts),
                    "error_signature": sig_str,
                    "repetition_warning": repetition_warning is not None,
                    "oscillation_warning": oscillation_warning is not None,
                }
            )

        return result

    def _post_process_result(
        self,
        request: ToolCallRequest,
        result: ToolMessage | Command,
    ) -> ToolMessage | Command:
        """Handle ToolMessage directly or inspect Command.update messages."""
        if isinstance(result, ToolMessage):
            return self._post_process_tool_message(request, result)
        if isinstance(result, Command):
            messages = _command_messages(result)
            if messages:
                tool_call_id = request.tool_call.get("id")
                for msg in messages:
                    if isinstance(msg, ToolMessage) and (not tool_call_id or msg.tool_call_id == tool_call_id):
                        self._post_process_tool_message(request, msg)
        return result

    @override
    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command],
    ) -> ToolMessage | Command:
        if not self.config.enabled:
            return handler(request)

        blocked = self._check_write_syntax_block(request)
        if blocked is not None:
            return blocked

        result = handler(request)
        return self._post_process_result(request, result)

    @override
    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command]],
    ) -> ToolMessage | Command:
        if not self.config.enabled:
            return await handler(request)

        blocked = await asyncio.to_thread(self._check_write_syntax_block, request)
        if blocked is not None:
            return blocked

        result = await handler(request)
        return self._post_process_result(request, result)
