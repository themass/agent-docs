"""Middleware that enforces a per-result budget on tool outputs.

Oversized tool results are persisted to disk and replaced with a compact
typed synopsis containing a file reference.  When disk persistence is
unavailable the middleware falls back to head+tail truncation so the
model context is never blown by a single large tool return.

The model-call hooks also budget the other bulky side of a tool call: the
``content`` argument of a successful ``write_file`` call (issue #5328, step
2). After a successful write the file on disk is the source of truth, and the
read-before-write gate forces a ``read_file`` before the next modification of
that path, so once a *later* successful read or write of the same path exists
the historical copy is redundant with it. Such superseded content is replaced
by a short deterministic placeholder in the *model-bound request only*
(``request.override``): ``state["messages"]``, checkpoints, tool receipts,
loop detection, and the run journal keep the original arguments, and nothing
is externalized to disk (the file itself is the reference). The newest
``keep_recent_writes`` successful writes always stay visible so the model can
still say what it just wrote without a read. Gate-blocked calls are the
read-before-write middleware's own policy; both rewrite through the shared
``tool_call_args`` helper so every provider surface changes together.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import posixpath
import re
import shlex
import uuid
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import replace as dc_replace
from typing import TYPE_CHECKING, Any, NamedTuple, override

from langchain.agents import AgentState
from langchain.agents.middleware import AgentMiddleware
from langchain.agents.middleware.types import ModelCallResult, ModelRequest, ModelResponse
from langchain_core.messages import AIMessage, ToolMessage
from langgraph.prebuilt.tool_node import ToolCallRequest
from langgraph.types import Command

from deerflow.agents.middlewares.skill_context import _tool_call_path, build_skill_entry_metadata_from_read
from deerflow.agents.middlewares.skill_usage import MAX_SKILL_SNAPSHOT_CHARS, SKILL_USAGE_KEY, record_skill_usage
from deerflow.agents.middlewares.tool_call_args import ToolCallOccurrence, pair_tool_call_results, rewrite_messages_tool_call_args
from deerflow.agents.middlewares.tool_output_synopsis import render_tool_output_preview
from deerflow.agents.middlewares.tool_result_meta import TOOL_META_KEY
from deerflow.agents.middlewares.tool_transform_meta import append_tool_transform
from deerflow.community.ragflow.sources import budget_source_artifact
from deerflow.config.summarization_config import DEFAULT_SKILL_FILE_READ_TOOL_NAMES
from deerflow.config.tool_output_config import ToolOutputConfig
from deerflow.constants import DEFAULT_SKILLS_CONTAINER_PATH, WRITE_ELISION_PLACEHOLDER_TEMPLATE
from deerflow.sandbox.lease import run_sync_lifecycle_operation
from deerflow.sandbox.sandbox_provider import get_sandbox_provider
from deerflow.storage import BlobRef, BlobStoreError, get_blob_store_if_enabled

if TYPE_CHECKING:
    from deerflow.sandbox.sandbox import Sandbox

logger = logging.getLogger(__name__)

# Virtual outputs root inside the sandbox. Host-mounted sandboxes map this to
# the thread outputs dir on the host; for non-mounted (remote) sandboxes the
# same path is written directly into the sandbox filesystem so the model's
# ``read_file`` tool can read it back (issue #3416).
_VIRTUAL_OUTPUTS_BASE = "/mnt/user-data/outputs"

# Checkpointed capability added only by this middleware. The Gateway strips
# client-supplied copies before they can enter state.
TOOL_OUTPUT_BLOB_KEY = "deerflow_tool_output_blob"
_TOOL_OUTPUT_BLOB_VERSION = 1
_TOOL_OUTPUT_BLOB_KIND = "tool-output"
_TOOL_OUTPUT_CONTENT_TYPE = "text/plain; charset=utf-8"
# Matches the default local_fs backend object limit. A producer must not create
# a reference that another default-configured Gateway cannot read.
_MAX_TOOL_OUTPUT_BLOB_BYTES = 64 * 1024 * 1024
# A configured shared store must never fail back to an unbounded model payload,
# even when the operator disabled the ordinary disk-unavailable fallback.
_DURABLE_FAILURE_FALLBACK_MAX_CHARS = 30_000

# Mirrors ``sandbox.tools._BASH_EXIT_MARKER_TAIL_RE`` (pinned by a test). The
# subagent executor reads the exit status only from the end of a bash result
# (trailing ``Exit Code: N``, or whole-output ``Command exited with code N``),
# so a budget rewrite must keep the marker last or a failed command is harvested
# as success. Restricted to the same names ``executor._BASH_EVIDENCE_TOOL_NAMES``
# uses; other tools may print the phrase as ordinary text.
_BASH_EXIT_MARKER_TAIL_RE = re.compile(r"(?:\nExit Code: -?\d+|\n?Command exited with code -?\d+)\s*$")
_EXIT_MARKER_TOOL_NAMES = frozenset({"bash", "bash_tool"})


class _BudgetedContent(NamedTuple):
    replacement: str
    transform_kind: str
    blob_metadata: dict[str, Any] | None = None


def _default_config() -> ToolOutputConfig:
    return ToolOutputConfig()


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------


def _split_budgetable_content(content: Any) -> tuple[str | None, list[Any]]:
    """Render text/JSON for budgeting, retaining other blocks for the provider.

    JSON blocks count even when mixed with media. Legacy text/image results
    without JSON keep their existing pass-through behavior.
    """
    if isinstance(content, str):
        return content, []
    if isinstance(content, list):
        pieces: list[str] = []
        retained: list[Any] = []
        has_json = False
        for part in content:
            if isinstance(part, str):
                pieces.append(part)
            elif isinstance(part, dict) and part.get("type") == "json" and "json" in part:
                # Keep this serialization in sync with mindie_provider._fix_messages.
                has_json = True
                try:
                    pieces.append(json.dumps(part["json"], ensure_ascii=False))
                except (TypeError, ValueError):
                    pieces.append(str(part["json"]))
            elif isinstance(part, dict) and isinstance(part.get("text"), str):
                pieces.append(part["text"])
            else:
                retained.append(part)
        if retained and not has_json:
            return None, retained
        return ("\n".join(pieces) if pieces else None), retained
    return None, []


def _message_text(content: Any) -> str | None:
    """Return the text/JSON representation eligible for output budgeting."""
    return _split_budgetable_content(content)[0]


def _snap_to_line_boundary(text: str, pos: int) -> int:
    """Return *pos* or the nearest preceding newline+1, whichever is closer.

    Used so that previews and truncations end on a complete line when
    possible.  If no newline exists in the second half of ``text[:pos]``
    the original *pos* is returned unchanged.

    Only valid for an *end* offset: moving backwards shortens the slice that
    ends here.  Use :func:`_snap_start_to_line_boundary` for a start offset.
    """
    if pos <= 0 or pos >= len(text):
        return pos
    half = pos // 2
    nl = text.rfind("\n", half, pos)
    if nl >= 0:
        return nl + 1
    return pos


def _snap_start_to_line_boundary(text: str, pos: int) -> int:
    """Return *pos* or the nearest following newline+1, whichever is closer.

    The start-offset mirror of :func:`_snap_to_line_boundary`. Snapping a start
    backwards would *lengthen* the slice beginning there, so the tail of a
    budgeted preview must snap forward instead. If no newline exists in the
    first half of ``text[pos:]`` the original *pos* is returned unchanged.
    """
    if pos <= 0 or pos >= len(text):
        return pos
    half = pos + (len(text) - pos) // 2
    nl = text.find("\n", pos, half)
    if nl >= 0:
        return nl + 1
    return pos


# ---------------------------------------------------------------------------
# Disk persistence
# ---------------------------------------------------------------------------

_EXT_MAP: dict[str, str] = {
    "bash": "log",
    "bash_tool": "log",
    "web_fetch": "log",
}


def _sanitize_tool_name(name: str) -> str:
    """Strip path separators and traversal components from a tool name."""
    base = os.path.basename(name)
    safe = base.replace("..", "").replace("/", "_").replace("\\", "_")
    return safe or "unknown"


def _build_externalized_filename(*, tool_name: str, tool_call_id: str, content: str) -> str:
    """Build the on-disk filename for an externalized tool output.

    Shared by the host-disk and sandbox externalization paths so both
    produce the identical naming scheme.
    """
    safe_name = _sanitize_tool_name(tool_name)
    ext = _EXT_MAP.get(tool_name, "txt")
    # Hash the raw ID and content so missing IDs, sanitization collisions and
    # oversized IDs cannot overwrite distinct output. Frame the ID length to
    # keep the boundary unambiguous, including when either value contains NUL.
    call_id_bytes = tool_call_id.encode("utf-8")
    digest = hashlib.sha256()
    digest.update(len(call_id_bytes).to_bytes(8, "big"))
    digest.update(call_id_bytes)
    digest.update(content.encode("utf-8"))
    return f"{safe_name}-{digest.hexdigest()}.{ext}"


def _externalize(
    content: str,
    *,
    tool_name: str,
    tool_call_id: str,
    outputs_path: str,
    storage_subdir: str,
) -> str | None:
    """Write *content* to disk and return the virtual path, or ``None`` on failure."""
    if os.path.isabs(storage_subdir) or ".." in storage_subdir:
        return None
    storage_dir = os.path.join(outputs_path, storage_subdir)
    try:
        os.makedirs(storage_dir, exist_ok=True)
    except OSError:
        return None

    # Each writer owns a unique sibling temp file, so concurrent calls cannot
    # truncate or clean up each other's pending output. Publish only after close
    # (also required on Windows), keeping the final filename deterministic.
    tmp_path = None
    try:
        filename = _build_externalized_filename(tool_name=tool_name, tool_call_id=tool_call_id, content=content)
        filepath = os.path.join(storage_dir, filename)
        if not os.path.abspath(filepath).startswith(os.path.abspath(storage_dir)):
            return None

        candidate_path = os.path.join(storage_dir, f".tool-output-{uuid.uuid4().hex}.tmp")
        # Exclusive creation keeps per-writer ownership while honoring umask,
        # unlike NamedTemporaryFile's fixed 0600 mode on mounted outputs.
        # newline="" keeps the bytes equal to the stamped blob ref; Windows
        # text mode would write CRLF and restore would discard the file.
        with open(candidate_path, "x", encoding="utf-8", newline="") as f:
            tmp_path = candidate_path
            f.write(content)
        os.replace(tmp_path, filepath)
    except (OSError, UnicodeEncodeError):
        if tmp_path is not None:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
        return None

    return f"{_VIRTUAL_OUTPUTS_BASE}/{storage_subdir}/{filename}"


def _host_path_for_externalized_output(
    virtual_path: str,
    *,
    outputs_path: str,
    storage_subdir: str,
) -> str | None:
    """Map one middleware-owned virtual path into the current thread root.

    Blob metadata is durable capability data. Even though external callers are
    stripped at the Gateway, validate it again before a store read or host write
    so a malformed legacy checkpoint cannot escape the tool-results directory.
    """
    if not isinstance(virtual_path, str) or not virtual_path:
        return None
    if not storage_subdir or storage_subdir in {".", ".."} or os.path.isabs(storage_subdir) or "/" in storage_subdir or "\\" in storage_subdir:
        return None
    virtual_dir = f"{_VIRTUAL_OUTPUTS_BASE}/{storage_subdir}"
    if posixpath.normpath(virtual_path) != virtual_path or posixpath.dirname(virtual_path) != virtual_dir:
        return None
    filename = posixpath.basename(virtual_path)
    if not filename or filename in {".", ".."}:
        return None

    outputs_root = os.path.realpath(os.path.abspath(outputs_path))
    storage_root = os.path.realpath(os.path.join(outputs_root, storage_subdir))
    candidate = os.path.realpath(os.path.join(storage_root, filename))
    try:
        if os.path.commonpath([outputs_root, storage_root]) != outputs_root:
            return None
        if os.path.commonpath([storage_root, candidate]) != storage_root:
            return None
    except ValueError:
        return None
    if os.path.dirname(candidate) != storage_root:
        return None
    return candidate


def _externalize_to_sandbox(
    content: str,
    *,
    tool_name: str,
    tool_call_id: str,
    storage_subdir: str,
    sandbox: Sandbox,
) -> str | None:
    """Write *content* into the sandbox filesystem and return the virtual path.

    Used when the sandbox does not use thread-data mounts (e.g. a remote AIO
    sandbox): the host-side :func:`_externalize` virtual path would not exist
    inside the sandbox, so the model's ``read_file`` tool could not read it
    back (issue #3416). Returns the same virtual-path contract on success, or
    ``None`` to signal the caller to fall back to inline truncation.
    """
    if os.path.isabs(storage_subdir) or ".." in storage_subdir:
        return None
    try:
        # Hashing encodes provider text too; keep encoding errors within the
        # same failure boundary as sandbox writes so callers can truncate.
        filename = _build_externalized_filename(tool_name=tool_name, tool_call_id=tool_call_id, content=content)
        virtual_dir = f"{_VIRTUAL_OUTPUTS_BASE}/{storage_subdir}"
        virtual_path = f"{virtual_dir}/{filename}"
        # AIO sandbox write_file does NOT create parent directories, so create
        # them explicitly before writing. execute_command returns its stdout
        # verbatim (including an "Error: ..." string on failure) rather than
        # raising, so we cannot rely on exception propagation here.
        sandbox.execute_command(f"mkdir -p {shlex.quote(virtual_dir)}")
        sandbox.write_file(virtual_path, content)
        # Validate the file landed completely: execute_command may have silently
        # failed to create the directory, or write_file may have truncated the
        # content (disk full, backend pipe error). Refuse to hand the model an
        # incomplete or unreadable read_file path.
        expected_bytes = len(content.encode("utf-8"))
        quoted_path = shlex.quote(virtual_path)
        check = sandbox.execute_command(f'test -f {quoted_path} && test "$(wc -c < {quoted_path})" -eq {expected_bytes} && echo OK || echo MISSING')
        if not isinstance(check, str) or check.strip() != "OK":
            logger.warning(
                "Sandbox externalize validation failed: path=%s, expected_bytes=%d, check=%r",
                virtual_path,
                expected_bytes,
                check,
            )
            return None
    except Exception:
        logger.exception(
            "Failed to externalize %s output to sandbox (call_id=%s)",
            tool_name,
            tool_call_id,
        )
        return None
    return virtual_path


# ---------------------------------------------------------------------------
# Preview / fallback builders
# ---------------------------------------------------------------------------


def _canonical_exit_marker(content: str) -> str | None:
    """Return the trailing bash exit marker as a single line, or ``None``."""
    match = _BASH_EXIT_MARKER_TAIL_RE.search(content)
    if match is None:
        return None
    return match.group(0).strip()


def _keep_exit_marker_last(original: str, rewritten: str, *, tool_name: str) -> str:
    """Re-append the original trailing exit marker after a budget rewrite.

    Preview construction always ends with an Access footer, so the harvest
    regex (``Exit Code: N`` anchored at the end) would otherwise miss the
    status and fall back to ``deerflow_tool_meta``'s success. Restricted to
    bash-family tools; other tools' text is left alone.
    """
    if tool_name not in _EXIT_MARKER_TOOL_NAMES:
        return rewritten
    marker = _canonical_exit_marker(original)
    if marker is None:
        return rewritten
    if rewritten.rstrip().endswith(marker):
        return rewritten
    return f"{rewritten.rstrip()}\n{marker}"


def _build_preview(
    content: str,
    *,
    tool_name: str,
    virtual_path: str,
    head_chars: int,
    tail_chars: int,
) -> str:
    """Build a typed synopsis preview with a file reference for externalized output."""
    preview = render_tool_output_preview(
        content,
        tool_name=tool_name,
        virtual_path=virtual_path,
        head_chars=head_chars,
        tail_chars=tail_chars,
    )
    return _keep_exit_marker_last(content, preview, tool_name=tool_name)


def _build_fallback(
    content: str,
    *,
    tool_name: str,
    max_chars: int,
    head_chars: int,
    tail_chars: int,
) -> str:
    """Build a head+tail truncation when disk persistence is unavailable.

    The returned string is guaranteed to be no longer than *max_chars*.
    A trailing bash exit marker (``Exit Code: N`` / ``Command exited with
    code N``) is reserved from the budget the way sandbox truncation does,
    so harvest can still recover the shell status. Only when *max_chars*
    is smaller than the marker line (including its leading newline) does
    the marker drop.
    """
    total = len(content)
    if max_chars <= 0 or total <= max_chars:
        return content

    preserved = ""
    body = content
    if tool_name in _EXIT_MARKER_TOOL_NAMES:
        match = _BASH_EXIT_MARKER_TAIL_RE.search(content)
        if match is not None:
            line = f"\n{match.group(0).strip()}"
            if len(line) <= max_chars:
                body = content[: match.start()]
                preserved = line
                max_chars -= len(preserved)
                if len(body) <= max_chars:
                    return body + preserved
                total = len(body)

    marker_template = "\n\n[... {n} chars omitted from {tn} output. Persistent storage unavailable. Consider narrowing the query or using more specific parameters.]\n\n"
    marker_overhead = len(marker_template.format(n=total, tn=tool_name))

    if marker_overhead >= max_chars:
        return body[:max_chars] + preserved

    budget = max_chars - marker_overhead
    effective_head = min(head_chars, budget)
    effective_tail = min(tail_chars, max(0, budget - effective_head))

    head_end = _snap_to_line_boundary(body, min(effective_head, total))
    tail_start = _snap_start_to_line_boundary(body, max(head_end, total - effective_tail))

    head = body[:head_end]
    tail = body[tail_start:] if tail_start < total else ""
    omitted = total - len(head) - len(tail)

    marker = marker_template.format(n=omitted, tn=tool_name)

    parts = [head, marker]
    if tail:
        parts.append(tail)
    return "".join(parts) + preserved


# ---------------------------------------------------------------------------
# Core budget logic
# ---------------------------------------------------------------------------


def _resolve_outputs_path(request: ToolCallRequest) -> str | None:
    """Best-effort extraction of the thread outputs path."""
    runtime = getattr(request, "runtime", None)
    if runtime is None:
        return None
    state = getattr(runtime, "state", None)
    if state is None:
        return None
    thread_data = state.get("thread_data")
    if not isinstance(thread_data, dict):
        return None
    outputs_path = thread_data.get("outputs_path")
    return outputs_path if isinstance(outputs_path, str) else None


def _resolve_thread_id(request: ToolCallRequest) -> str | None:
    """Resolve advisory blob provenance from runtime context or config."""
    runtime = getattr(request, "runtime", None)
    context = getattr(runtime, "context", None)
    if isinstance(context, Mapping):
        thread_id = context.get("thread_id")
        if isinstance(thread_id, str) and thread_id:
            return thread_id
    runtime_config = getattr(runtime, "config", None)
    configurable = runtime_config.get("configurable") if isinstance(runtime_config, Mapping) else None
    thread_id = configurable.get("thread_id") if isinstance(configurable, Mapping) else None
    return thread_id if isinstance(thread_id, str) and thread_id else None


def _resolve_sandbox(request: ToolCallRequest) -> Sandbox | None:
    """Resolve the active sandbox for the current tool call, or ``None``.

    Reads the sandbox_id that ``SandboxMiddleware`` (and the sandbox tools
    themselves) write into ``runtime.state["sandbox"]``. We intentionally do
    NOT call ``provider.acquire`` here: acquiring a sandbox can trigger
    blocking remote I/O, and this resolver runs on every tool call. Tools
    that do not use a sandbox (``web_search``, MCP, ...) will return ``None``
    here, which is fine -- the caller falls back to inline truncation.
    """
    runtime = getattr(request, "runtime", None)
    state = getattr(runtime, "state", None)
    if not isinstance(state, dict):
        return None
    from deerflow.sandbox.overwrite import unwrap_sandbox

    sandbox_state, _ = unwrap_sandbox(state.get("sandbox"))
    if not isinstance(sandbox_state, dict):
        return None
    sandbox_id = sandbox_state.get("sandbox_id")
    if not sandbox_id:
        return None
    try:
        return get_sandbox_provider().get(sandbox_id)
    except Exception:
        logger.exception("Failed to look up sandbox %s for tool-output externalization", sandbox_id)
        return None


def _budget_content(
    content: str,
    *,
    tool_name: str,
    tool_call_id: str,
    outputs_path: str | None,
    config: ToolOutputConfig,
    sandbox: Sandbox | None = None,
    thread_id: str | None = None,
) -> _BudgetedContent | None:
    """Apply budget to *content* and name the applied transform.

    Returns the replacement, transform kind, and optional durable blob
    metadata, or ``None`` if no change was needed.
    """
    threshold = config.tool_overrides.get(tool_name, config.externalize_min_chars)
    if threshold <= 0 and config.fallback_max_chars <= 0:
        return None
    if len(content) <= threshold and len(content) <= config.fallback_max_chars:
        return None

    if threshold > 0 and len(content) > threshold:
        virtual_path: str | None = None
        blob_metadata: dict[str, Any] | None = None
        host_outputs_path: str | None = None
        durable_fallback_required = False
        # Decide persistence target based on what's available, without touching
        # the sandbox provider unless a sandbox was actually resolved for this
        # call. This keeps the legacy host-disk path provider-free, so callers
        # without a configured sandbox (and CI environments without a
        # config.yaml) continue to externalize to the host as before.
        if sandbox is not None:
            provider = None
            try:
                provider = get_sandbox_provider()
            except Exception:
                logger.exception("Failed to get sandbox provider for tool-output externalization; falling back to inline truncation")
            if provider is not None and getattr(provider, "uses_thread_data_mounts", False):
                # Host-mounted sandbox: host outputs path is bind-mounted into
                # the sandbox at the same virtual path, so writing host-side is
                # equivalent. Preserve the original behavior to avoid extra
                # sandbox round-trips.
                if outputs_path:
                    host_outputs_path = outputs_path
            else:
                virtual_path = _externalize_to_sandbox(
                    content,
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    storage_subdir=config.storage_subdir,
                    sandbox=sandbox,
                )
        elif outputs_path:
            # No sandbox in this call (legacy / non-sandbox tools): write to
            # host outputs path directly, no provider needed.
            host_outputs_path = outputs_path

        if host_outputs_path is not None:
            blob_store = get_blob_store_if_enabled()
            try:
                blob_bytes = content.encode("utf-8") if blob_store is not None else None
            except UnicodeEncodeError:
                blob_bytes = None
                durable_fallback_required = True
                logger.warning("Tool output cannot be encoded as UTF-8 for durable blob externalization")
            if blob_bytes is not None and len(blob_bytes) > _MAX_TOOL_OUTPUT_BLOB_BYTES:
                durable_fallback_required = True
                logger.warning(
                    "Tool output is too large for durable blob externalization: %d bytes > %d",
                    len(blob_bytes),
                    _MAX_TOOL_OUTPUT_BLOB_BYTES,
                )
            elif not durable_fallback_required:
                virtual_path = _externalize(
                    content,
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    outputs_path=host_outputs_path,
                    storage_subdir=config.storage_subdir,
                )
                if virtual_path is not None and blob_store is not None and blob_bytes is not None:
                    try:
                        ref = blob_store.put_bytes(
                            blob_bytes,
                            kind=_TOOL_OUTPUT_BLOB_KIND,
                            content_type=_TOOL_OUTPUT_CONTENT_TYPE,
                            thread_id=thread_id,
                        )
                    except BlobStoreError:
                        durable_fallback_required = True
                        logger.warning(
                            "Failed to persist externalized %s output in shared blob storage",
                            tool_name,
                            exc_info=True,
                        )
                        # A concurrent publisher may already have replaced the
                        # deterministic host path. Do not unlink a file that
                        # may belong to another successful blob checkpoint.
                        virtual_path = None
                    else:
                        blob_metadata = {
                            "version": _TOOL_OUTPUT_BLOB_VERSION,
                            "ref": ref.model_dump(mode="json", exclude_none=True),
                            "virtual_path": virtual_path,
                            "storage_subdir": config.storage_subdir,
                            "encoding": "utf-8",
                        }
        if virtual_path is not None:
            logger.info(
                "Externalized %s output (%d chars) to %s",
                tool_name,
                len(content),
                virtual_path,
            )
            return _BudgetedContent(
                _build_preview(
                    content,
                    tool_name=tool_name,
                    virtual_path=virtual_path,
                    head_chars=config.preview_head_chars,
                    tail_chars=config.preview_tail_chars,
                ),
                "externalized",
                blob_metadata,
            )

        if durable_fallback_required:
            configured_limit = config.fallback_max_chars if config.fallback_max_chars > 0 else _DURABLE_FAILURE_FALLBACK_MAX_CHARS
            fallback_max_chars = min(configured_limit, _DURABLE_FAILURE_FALLBACK_MAX_CHARS)
        else:
            fallback_max_chars = config.fallback_max_chars
    else:
        fallback_max_chars = config.fallback_max_chars

    if fallback_max_chars > 0 and len(content) > fallback_max_chars:
        logger.warning(
            "Fallback-truncating %s output: %d chars → %d max",
            tool_name,
            len(content),
            fallback_max_chars,
        )
        return _BudgetedContent(
            _build_fallback(
                content,
                tool_name=tool_name,
                max_chars=fallback_max_chars,
                head_chars=config.fallback_head_chars,
                tail_chars=config.fallback_tail_chars,
            ),
            "truncated",
        )

    return None


# ---------------------------------------------------------------------------
# Result patchers
# ---------------------------------------------------------------------------


def _patch_tool_message(
    msg: ToolMessage,
    config: ToolOutputConfig,
    outputs_path: str | None,
    sandbox: Sandbox | None = None,
    thread_id: str | None = None,
) -> ToolMessage:
    """Apply budget to a single ToolMessage. Returns the original if unchanged."""
    tool_name = msg.name or "unknown"
    if tool_name in config.exempt_tools:
        return msg

    text, retained_blocks = _split_budgetable_content(msg.content)
    if text is None:
        return msg

    budgeted = _budget_content(
        text,
        tool_name=tool_name,
        tool_call_id=msg.tool_call_id or "",
        outputs_path=outputs_path,
        config=config,
        sandbox=sandbox,
        thread_id=thread_id,
    )
    update: dict[str, Any] = {}
    trigger = _effective_trigger(tool_name, config)
    citation_result = None
    if tool_name in {"knowledge_search", "task"} and trigger > 0 and len(text) > trigger:
        citation_result = budget_source_artifact(text, msg.artifact, trigger, summary=(budgeted.replacement if budgeted else text) if tool_name == "task" else "")
    if citation_result is not None:
        replacement, update["artifact"] = citation_result
        transform_kind = "truncated"
    elif budgeted is not None:
        replacement = budgeted.replacement
        transform_kind = budgeted.transform_kind
    else:
        return msg
    from deerflow.knowledge.sources import prune_sources

    replacement, artifact = prune_sources(replacement, update.get("artifact", msg.artifact))
    if artifact is not msg.artifact or "artifact" in update:
        update["artifact"] = artifact
    update["content"] = [{"type": "text", "text": replacement}, *retained_blocks] if retained_blocks else replacement
    if getattr(msg, "response_metadata", None):
        update["response_metadata"] = dict(msg.response_metadata)
    new_kwargs = dict(getattr(msg, "additional_kwargs", None) or {})
    new_kwargs.pop(TOOL_OUTPUT_BLOB_KEY, None)
    if budgeted is not None and budgeted.blob_metadata is not None:
        new_kwargs[TOOL_OUTPUT_BLOB_KEY] = budgeted.blob_metadata
    if citation_result is not None and budgeted is not None and budgeted.transform_kind == "externalized":
        append_tool_transform(new_kwargs, "externalized", by="ToolOutputBudgetMiddleware")
    append_tool_transform(new_kwargs, transform_kind, by="ToolOutputBudgetMiddleware")
    update["additional_kwargs"] = new_kwargs
    return msg.model_copy(update=update)


def _effective_trigger(tool_name: str, config: ToolOutputConfig) -> int:
    """Smallest content length that could trigger budgeting for *tool_name*.

    Mirrors the trigger conditions in :func:`_budget_content` (per-tool
    externalize threshold OR global fallback), so the pre-scan never produces
    a false negative. Returns ``-1`` when nothing could ever trigger.
    """
    candidates: list[int] = []
    externalize = config.tool_overrides.get(tool_name, config.externalize_min_chars)
    if externalize > 0:
        candidates.append(externalize)
    if config.fallback_max_chars > 0:
        candidates.append(config.fallback_max_chars)
    return min(candidates) if candidates else -1


def _tool_message_over_budget(msg: ToolMessage, config: ToolOutputConfig) -> bool:
    """Cheap, per-tool-aware check: is this ToolMessage non-exempt and over its trigger?"""
    if (msg.name or "") in config.exempt_tools:
        return False
    trigger = _effective_trigger(msg.name or "", config)
    if trigger < 0:
        return False
    text = _message_text(msg.content)
    return text is not None and len(text) > trigger


def _needs_budget(result: ToolMessage | Command, config: ToolOutputConfig) -> bool:
    """Fast check whether *result* could need budgeting (avoids thread offload for small outputs)."""
    if isinstance(result, ToolMessage):
        return _tool_message_over_budget(result, config)
    update = getattr(result, "update", None)
    if isinstance(update, dict):
        messages = update.get("messages", [])
        if isinstance(messages, ToolMessage):
            return _tool_message_over_budget(messages, config)
        if isinstance(messages, (list, tuple)):
            return any(isinstance(msg, ToolMessage) and _tool_message_over_budget(msg, config) for msg in messages)
    return False


def _patch_result(
    result: ToolMessage | Command,
    config: ToolOutputConfig,
    outputs_path: str | None,
    sandbox: Sandbox | None = None,
    thread_id: str | None = None,
) -> ToolMessage | Command:
    """Apply budget to a tool call result (ToolMessage or Command)."""
    if isinstance(result, ToolMessage):
        return _patch_tool_message(result, config, outputs_path, sandbox, thread_id)

    update = getattr(result, "update", None)
    if not isinstance(update, dict):
        return result

    messages = update.get("messages")
    if isinstance(messages, ToolMessage):
        patched = _patch_tool_message(messages, config, outputs_path, sandbox, thread_id)
        return result if patched is messages else dc_replace(result, update={**update, "messages": patched})
    if not isinstance(messages, (list, tuple)):
        return result

    new_messages: list[Any] = []
    changed = False
    for msg in messages:
        if isinstance(msg, ToolMessage):
            patched = _patch_tool_message(msg, config, outputs_path, sandbox, thread_id)
            if patched is not msg:
                changed = True
            new_messages.append(patched)
        else:
            new_messages.append(msg)

    if not changed:
        return result

    return dc_replace(result, update={**update, "messages": tuple(new_messages) if isinstance(messages, tuple) else new_messages})


def _record_visible_skill_usage(
    result: ToolMessage | Command,
    request: ToolCallRequest,
    *,
    skill_read_tool_names: frozenset[str],
    skills_root: str,
) -> ToolMessage | Command:
    """Register the snapshot after output budgeting has determined model-visible content."""
    tool_call = request.tool_call
    tool_name = str(tool_call.get("name") or "")
    tool_call_id = str(tool_call.get("id") or "")
    path = _tool_call_path(tool_call)
    runtime = getattr(request, "runtime", None)

    def record(message: ToolMessage) -> ToolMessage:
        if SKILL_USAGE_KEY not in message.additional_kwargs:
            return message
        usage = message.additional_kwargs[SKILL_USAGE_KEY]
        entry = build_skill_entry_metadata_from_read(path, message.content, skills_root=skills_root) if path is not None and isinstance(message.content, str) else None
        if tool_name not in skill_read_tool_names or str(message.tool_call_id) != tool_call_id or not isinstance(usage, dict) or entry is None or usage.get("path") != entry["path"]:
            kwargs = dict(message.additional_kwargs)
            kwargs.pop(SKILL_USAGE_KEY, None)
            return message.model_copy(update={"additional_kwargs": kwargs})
        visible_hash = hashlib.sha256(message.content.encode("utf-8")).hexdigest()
        if visible_hash != usage.get("content_hash"):
            usage = {
                **usage,
                "content": message.content[:MAX_SKILL_SNAPSHOT_CHARS],
                "content_hash": visible_hash,
                "partial": True,
            }
            message = message.model_copy(update={"additional_kwargs": {**message.additional_kwargs, SKILL_USAGE_KEY: usage}})
        record_skill_usage(runtime, usage)
        return message

    if isinstance(result, ToolMessage):
        return record(result)
    update = getattr(result, "update", None)
    if not isinstance(update, dict):
        return result
    messages = update.get("messages")
    if isinstance(messages, ToolMessage):
        updated = record(messages)
        return result if updated is messages else dc_replace(result, update={**update, "messages": updated})
    if not isinstance(messages, (list, tuple)):
        return result
    updated = [record(message) if isinstance(message, ToolMessage) else message for message in messages]
    if all(new is old for new, old in zip(updated, messages)):
        return result
    return dc_replace(result, update={**update, "messages": tuple(updated) if isinstance(messages, tuple) else updated})


def _patch_model_messages(messages: list[Any], config: ToolOutputConfig) -> list[Any] | None:
    """Apply budget to historical ToolMessages in a model request. Returns ``None`` if unchanged.

    A cheap pre-scan bails out before allocating a new list when no historical
    ToolMessage exceeds the budget — the common case once every result has
    already been budgeted at tool-call time, so a long history is not rebuilt
    on every model call.

    Historical messages do not get a ``sandbox`` argument: any oversized tool
    message in history was already budgeted (and possibly externalized) at
    tool-call time, so the only thing left for the history path to do is
    inline fallback truncation, which needs no sandbox.
    """
    if not any(isinstance(msg, ToolMessage) and _tool_message_over_budget(msg, config) for msg in messages):
        return None

    updated: list[Any] = []
    changed = False
    for msg in messages:
        if isinstance(msg, ToolMessage):
            patched = _patch_tool_message(msg, config, outputs_path=None)
            if patched is not msg:
                changed = True
            updated.append(patched)
        else:
            updated.append(msg)
    return updated if changed else None


def _model_outputs_path(request: ModelRequest) -> str | None:
    state = getattr(request, "state", None)
    if not isinstance(state, Mapping):
        return None
    thread_data = state.get("thread_data")
    if not isinstance(thread_data, Mapping):
        return None
    outputs_path = thread_data.get("outputs_path")
    return outputs_path if isinstance(outputs_path, str) and outputs_path else None


def _has_tool_output_blob_refs(messages: list[Any]) -> bool:
    """Cheap pre-scan used to keep normal async model calls on the event loop."""
    return any(isinstance(message, ToolMessage) and isinstance(getattr(message, "additional_kwargs", None), dict) and TOOL_OUTPUT_BLOB_KEY in message.additional_kwargs for message in messages)


def _write_restored_output(filepath: str, data: bytes) -> bool:
    """Atomically publish restored bytes without exposing a partial file."""
    directory = os.path.dirname(filepath)
    tmp_path: str | None = None
    try:
        os.makedirs(directory, exist_ok=True)
        candidate_path = os.path.join(directory, f".tool-output-{uuid.uuid4().hex}.tmp")
        # Match initial publication's creation permissions for mounted sandbox
        # readers, while retaining the recovering Gateway's restrictive umask.
        with open(candidate_path, "xb") as handle:
            tmp_path = candidate_path
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, filepath)
        tmp_path = None
        return True
    except OSError:
        logger.warning("Failed to restore externalized tool output on this Gateway", exc_info=True)
        return False
    finally:
        if tmp_path is not None:
            try:
                os.unlink(tmp_path)
            except FileNotFoundError:
                pass
            except OSError:
                logger.warning("Failed to clean up tool-output restore temp file", exc_info=True)


def _discard_mismatched_output(filepath: str) -> None:
    """Do not leave known-wrong bytes behind a trusted read_file reference."""
    try:
        os.unlink(filepath)
    except FileNotFoundError:
        pass
    except OSError:
        logger.warning("Failed to remove mismatched externalized tool output", exc_info=True)


def _restore_tool_output_blobs(messages: list[Any], *, outputs_path: str) -> None:
    """Materialize durable host-externalized results under this Gateway.

    Existing digest-matching files are reused without touching the blob store.
    Invalid metadata and unavailable blobs are ignored so a transient storage
    outage does not prevent the model from using the inline preview.
    """
    store_resolved = False
    blob_store = None
    for message in messages:
        if not isinstance(message, ToolMessage):
            continue
        payload = (message.additional_kwargs or {}).get(TOOL_OUTPUT_BLOB_KEY)
        if not isinstance(payload, Mapping):
            continue
        if payload.get("version") != _TOOL_OUTPUT_BLOB_VERSION or payload.get("encoding") != "utf-8":
            continue
        ref_data = payload.get("ref")
        virtual_path = payload.get("virtual_path")
        storage_subdir = payload.get("storage_subdir")
        if not isinstance(ref_data, Mapping) or not isinstance(virtual_path, str) or not isinstance(storage_subdir, str):
            continue
        try:
            ref = BlobRef.model_validate(dict(ref_data))
        except (TypeError, ValueError):
            continue
        if ref.kind != _TOOL_OUTPUT_BLOB_KIND or ref.content_type != _TOOL_OUTPUT_CONTENT_TYPE:
            continue
        filepath = _host_path_for_externalized_output(
            virtual_path,
            outputs_path=outputs_path,
            storage_subdir=storage_subdir,
        )
        if filepath is None:
            continue

        local_mismatch = False
        try:
            if os.stat(filepath).st_size != ref.size:
                local_mismatch = True
            else:
                with open(filepath, "rb") as handle:
                    if ref.matches(handle.read()):
                        continue
                    local_mismatch = True
        except FileNotFoundError:
            pass
        except OSError:
            logger.warning("Failed to inspect local externalized tool output", exc_info=True)

        if not store_resolved:
            blob_store = get_blob_store_if_enabled()
            store_resolved = True
        if blob_store is None:
            if local_mismatch:
                _discard_mismatched_output(filepath)
            continue
        try:
            data = blob_store.get_bytes(ref)
        except BlobStoreError:
            logger.warning(
                "Failed to resolve externalized tool output blob %s",
                ref.sha256[:12],
                exc_info=True,
            )
            if local_mismatch:
                _discard_mismatched_output(filepath)
            continue
        if not ref.matches(data):
            logger.warning("Blob backend returned mismatched tool output %s", ref.sha256[:12])
            if local_mismatch:
                _discard_mismatched_output(filepath)
            continue
        if not _write_restored_output(filepath, data) and local_mismatch:
            _discard_mismatched_output(filepath)


# ---------------------------------------------------------------------------
# Superseded write payload elision (issue #5328, step 2)
# ---------------------------------------------------------------------------

_WRITE_TOOL = "write_file"
# A successful call of these tools changes the file, so every earlier write's
# content is stale afterwards. ``str_replace`` payloads are never elided
# themselves: they are usually small, and the issue scopes step 2 to
# ``write_file.content``.
_FILE_MODIFYING_TOOLS = frozenset({"write_file", "str_replace"})
# A non-error read (full, ranged, or head-truncated — ``partial_success``)
# showed the model the on-disk file, which is what the placeholder points at.
_FILE_READING_TOOLS = frozenset({"read_file"})
_SUPERSEDING_READ_STATUSES = frozenset({"success", "partial_success"})
# Deterministic for a given payload so repeated model calls keep the same
# request prefix (prompt caching) instead of drifting. Framework-owned static
# text plus a character count; no model-supplied value is interpolated (the
# path stays visible in the call's own ``path`` argument). The template is
# shared with ``write_file``, which refuses to write it back out (#7319).
_ELIDED_WRITE_CONTENT_TEMPLATE = WRITE_ELISION_PLACEHOLDER_TEMPLATE


def elide_superseded_write_payloads(messages: list[Any], *, min_chars: int, keep_recent: int) -> list[Any] | None:
    """Return ``messages`` with superseded ``write_file`` content replaced by placeholders, or ``None`` if unchanged.

    Only the policy lives here. A call qualifies when its paired result is
    stamped ``deerflow_tool_meta.status == "success"``, its ``content`` is a
    string of at least ``min_chars`` characters, a *later* message holds a
    successful ``read_file`` / ``write_file`` / ``str_replace`` of the same
    normalized path, and it is not among the ``keep_recent`` newest successful
    writes. Calls are paired with results per occurrence
    (``tool_call_args.pair_tool_call_results``), and "later" means a later
    message index: the calls of one AIMessage ran concurrently, so a same-turn
    read may predate the write and never supersedes it. The surface-by-surface
    rewrite is ``rewrite_messages_tool_call_args``, which never mutates the
    input and passes untouched messages through by identity, so the stored
    history keeps the original arguments and the output is identical across
    model calls. The policy is monotonic: once a write is elided, more history
    never brings its content back.
    """
    if not _has_elidable_write(messages, min_chars):
        return None

    latest_touch: dict[str, int] = {}
    successful_writes: list[tuple[ToolCallOccurrence, str]] = []
    for occurrence in pair_tool_call_results(messages):
        path = _normalized_path_arg(occurrence.args)
        if path is None:
            continue
        name = occurrence.name
        if name in _FILE_MODIFYING_TOOLS:
            if _result_status(occurrence.result) != "success":
                continue
            if name == _WRITE_TOOL:
                successful_writes.append((occurrence, path))
        elif name in _FILE_READING_TOOLS:
            if _result_status(occurrence.result) not in _SUPERSEDING_READ_STATUSES:
                continue
        else:
            continue
        latest_touch[path] = max(latest_touch.get(path, -1), occurrence.index)

    replacements: dict[tuple[int, str], dict[str, Any]] = {}
    cutoff = max(0, len(successful_writes) - keep_recent)
    for occurrence, path in successful_writes[:cutoff]:
        content = occurrence.args.get("content")
        if not isinstance(content, str) or not content or len(content) < min_chars:
            continue
        if latest_touch.get(path, -1) <= occurrence.index:
            continue
        replacements[(id(occurrence.message), occurrence.call_id)] = {**occurrence.args, "content": _ELIDED_WRITE_CONTENT_TEMPLATE.format(chars=len(content))}
    if not replacements:
        return None

    def replacement_for(message: AIMessage, tool_call: dict[str, Any]) -> dict[str, Any] | None:
        return replacements.get((id(message), tool_call["id"]))

    return rewrite_messages_tool_call_args(messages, replacement_for)


def _has_elidable_write(messages: list[Any], min_chars: int) -> bool:
    """Cheap pre-scan so a history without a sizeable ``write_file`` call is never paired or rebuilt."""
    for message in messages:
        if not isinstance(message, AIMessage):
            continue
        for tool_call in message.tool_calls or ():
            if not isinstance(tool_call, dict) or tool_call.get("name") != _WRITE_TOOL:
                continue
            args = tool_call.get("args")
            content = args.get("content") if isinstance(args, dict) else None
            if isinstance(content, str) and content and len(content) >= min_chars:
                return True
    return False


def _result_status(result: ToolMessage | None) -> str | None:
    """``deerflow_tool_meta.status`` of a paired result; ``None`` when unanswered or unstamped (never treated as success)."""
    if result is None:
        return None
    meta = (result.additional_kwargs or {}).get(TOOL_META_KEY)
    status = meta.get("status") if isinstance(meta, dict) else None
    return status if isinstance(status, str) else None


def _normalized_path_arg(args: Mapping[str, Any]) -> str | None:
    """The call's ``path`` argument normalized the way the read-before-write gate keys its marks."""
    path = args.get("path")
    return posixpath.normpath(path) if isinstance(path, str) and path else None


# ---------------------------------------------------------------------------
# Middleware class
# ---------------------------------------------------------------------------


class ToolOutputBudgetMiddleware(AgentMiddleware[AgentState]):
    """Enforce per-result budget on tool outputs via externalization or truncation."""

    def __init__(
        self,
        config: ToolOutputConfig | None = None,
        *,
        skill_read_tool_names: list[str] | None = None,
        skills_root: str = DEFAULT_SKILLS_CONTAINER_PATH,
    ) -> None:
        super().__init__()
        self._config = config if config is not None else _default_config()
        self._skill_read_tool_names = frozenset(skill_read_tool_names if skill_read_tool_names is not None else DEFAULT_SKILL_FILE_READ_TOOL_NAMES)
        self._skills_root = skills_root

    def release_policy_parameters(self) -> dict[str, object]:
        return {"config": self._config.model_dump(mode="python"), "skill_read_tool_names": sorted(self._skill_read_tool_names), "skills_root": self._skills_root}

    @classmethod
    def from_app_config(cls, app_config: Any) -> ToolOutputBudgetMiddleware:
        tool_output = getattr(app_config, "tool_output", None)
        summarization = getattr(app_config, "summarization", None)
        skills = getattr(app_config, "skills", None)
        return cls(
            config=tool_output if isinstance(tool_output, ToolOutputConfig) else None,
            skill_read_tool_names=getattr(summarization, "skill_file_read_tool_names", None),
            skills_root=getattr(skills, "container_path", DEFAULT_SKILLS_CONTAINER_PATH),
        )

    # -- tool call hooks ---------------------------------------------------

    @override
    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command],
    ) -> ToolMessage | Command:
        result = handler(request)
        if self._config.enabled and _needs_budget(result, self._config):
            outputs_path = _resolve_outputs_path(request)
            sandbox = _resolve_sandbox(request)
            result = _patch_result(
                result,
                self._config,
                outputs_path,
                sandbox,
                _resolve_thread_id(request),
            )
        return _record_visible_skill_usage(result, request, skill_read_tool_names=self._skill_read_tool_names, skills_root=self._skills_root)

    @override
    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command]],
    ) -> ToolMessage | Command:
        result = await handler(request)
        if self._config.enabled and _needs_budget(result, self._config):
            outputs_path = _resolve_outputs_path(request)
            # _resolve_sandbox only touches runtime.state and the provider's
            # in-memory sandbox registry, so it is safe to call on the event
            # loop. The actual sandbox I/O happens in the worker thread.
            sandbox = _resolve_sandbox(request)
            result = await asyncio.to_thread(
                _patch_result,
                result,
                self._config,
                outputs_path,
                sandbox,
                _resolve_thread_id(request),
            )
        return _record_visible_skill_usage(result, request, skill_read_tool_names=self._skill_read_tool_names, skills_root=self._skills_root)

    # -- model call hooks (historical context budgeting) -------------------

    @override
    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelCallResult:
        return handler(self._budget_model_request(request))

    @override
    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        messages = getattr(request, "messages", None)
        outputs_path = _model_outputs_path(request)
        if isinstance(messages, list) and outputs_path is not None and _has_tool_output_blob_refs(messages):
            # A blob read and atomic host write may outlive cancellation. Drain
            # the worker before the request boundary releases its resources.
            prepared = await run_sync_lifecycle_operation(self._budget_model_request, request)
        else:
            prepared = self._budget_model_request(request)
        return await handler(prepared)

    def _budget_model_request(self, request: ModelRequest) -> ModelRequest:
        """Truncate oversized historical tool output and elide superseded write payloads in the request copy only."""
        original = getattr(request, "messages", None)
        if not isinstance(original, list):
            return request
        outputs_path = _model_outputs_path(request)
        if outputs_path is not None and _has_tool_output_blob_refs(original):
            _restore_tool_output_blobs(original, outputs_path=outputs_path)
        if not self._config.enabled:
            return request
        messages = original
        patched = _patch_model_messages(messages, self._config)
        if patched is not None:
            messages = patched
        if self._config.elide_superseded_writes:
            elided = elide_superseded_write_payloads(
                messages,
                min_chars=self._config.superseded_write_min_chars,
                keep_recent=self._config.keep_recent_writes,
            )
            if elided is not None:
                messages = elided
        if messages is original:
            return request
        return request.override(messages=messages)
