from __future__ import annotations

import hashlib
import json
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any, Literal

from sqlalchemy import and_, case, or_, select, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from deerflow.mcp.tasks import ATTENTION_TASK_STATUSES, POLLABLE_TASK_STATUSES, TERMINAL_TASK_STATUSES
from deerflow.mcp.tasks.models import TaskStatus
from deerflow.persistence.mcp_tasks.model import McpTaskRow
from deerflow.persistence.thread_meta.model import ThreadMetaRow
from deerflow.utils.time import coerce_iso

_POLLABLE_STATUS_VALUES = tuple(status.value for status in POLLABLE_TASK_STATUSES)
_ATTENTION_STATUS_VALUES = frozenset(status.value for status in ATTENTION_TASK_STATUSES)
_TERMINAL_STATUS_VALUES = frozenset(status.value for status in TERMINAL_TASK_STATUSES)
_TIMESTAMP_FIELDS = (
    "next_poll_at",
    "last_polled_at",
    "lease_expires_at",
    "notification_lease_expires_at",
    "next_notification_at",
    "cancel_requested_at",
    "next_cancel_at",
    "completed_at",
    "created_at",
    "updated_at",
)

_INFLIGHT_NOTIFICATION_STATUSES = frozenset({"claimed", "launching", "dispatched", "retry"})


def _new_claim_token() -> str:
    """Return a fresh per-claim token used to fence releases against reclaims."""
    return uuid.uuid4().hex


def _notification_event(row: McpTaskRow, *, tracking_degraded: bool) -> dict[str, Any] | None:
    if row.status not in _ATTENTION_STATUS_VALUES and not tracking_degraded:
        return None
    return {
        "task_id": row.id,
        "task_name": row.task_name,
        "status": row.status,
        "result": row.result,
        "result_preview": row.result_preview,
        "result_truncated": bool(row.result_truncated),
        "result_artifact": row.result_artifact,
        "error": row.error,
        "input_required": row.input_required,
        "tracking_degraded": tracking_degraded,
        "last_poll_error": row.last_poll_error if tracking_degraded else None,
    }


def _event_fingerprint(event: dict[str, Any]) -> str:
    encoded = json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _record_event_if_changed(row: McpTaskRow, *, tracking_degraded: bool, now: datetime) -> bool:
    event = _notification_event(row, tracking_degraded=tracking_degraded)
    if event is None:
        return False
    fingerprint = _event_fingerprint(event)
    if fingerprint == row.event_fingerprint:
        return False
    row.event_fingerprint = fingerprint
    row.event_version = int(row.event_version or 0) + 1
    if row.notification_status not in _INFLIGHT_NOTIFICATION_STATUSES:
        row.notification_status = "pending"
        row.next_notification_at = now
        row.notification_error = None
        row.notification_attempt_count = 0
        row.dispatch_version = None
        row.dispatch_attempt = 0
        row.dispatch_event = None
        row.notification_run_id = None
    return True


class DuplicateMcpRemoteTaskError(RuntimeError):
    """The current user already tracks this server's remote task handle."""


class McpTaskThreadMismatchError(RuntimeError):
    """The submitting run no longer owns the current thread incarnation."""


def _is_remote_task_unique_conflict(exc: IntegrityError) -> bool:
    original = exc.orig
    diagnostic = getattr(original, "diag", None)
    if getattr(diagnostic, "constraint_name", None) == "uq_mcp_tasks_user_server_remote":
        return True
    message = str(original)
    return "uq_mcp_tasks_user_server_remote" in message or "mcp_tasks.user_id, mcp_tasks.server_name, mcp_tasks.remote_task_id" in message


def _matches_current_thread_incarnation(
    *,
    user_id: str,
    thread_id: str,
    thread_incarnation: str | None,
):
    """Atomically match task, current thread, and caller-captured incarnation."""
    return (
        select(ThreadMetaRow.thread_id)
        .where(
            McpTaskRow.thread_id == thread_id,
            McpTaskRow.thread_incarnation.is_not_distinct_from(thread_incarnation),
            ThreadMetaRow.thread_id == thread_id,
            ThreadMetaRow.incarnation.is_not_distinct_from(thread_incarnation),
            or_(ThreadMetaRow.user_id == user_id, ThreadMetaRow.user_id.is_(None)),
        )
        .exists()
    )


async def _lock_current_thread_incarnation(
    session: AsyncSession,
    *,
    user_id: str,
    thread_id: str,
    thread_incarnation: str | None,
) -> bool:
    """Lock the expected thread incarnation until the transaction ends."""
    conditions = (
        ThreadMetaRow.thread_id == thread_id,
        ThreadMetaRow.incarnation.is_not_distinct_from(thread_incarnation),
        or_(ThreadMetaRow.user_id == user_id, ThreadMetaRow.user_id.is_(None)),
    )
    if session.get_bind().dialect.name == "sqlite":
        # SQLite has no row-level SELECT lock. A no-op UPDATE acquires its
        # database writer lock before we inspect or mutate an MCP task row.
        # Raw SQL avoids firing ThreadMetaRow.updated_at's ORM onupdate hook.
        result = await session.execute(
            text(
                """
                UPDATE threads_meta
                SET incarnation = incarnation
                WHERE thread_id = :thread_id
                  AND incarnation IS :thread_incarnation
                  AND (user_id = :user_id OR user_id IS NULL)
                """
            ),
            {
                "thread_id": thread_id,
                "thread_incarnation": thread_incarnation,
                "user_id": user_id,
            },
        )
        return result.rowcount == 1
    result = await session.execute(select(ThreadMetaRow.thread_id).where(*conditions).with_for_update(read=True))
    return result.one_or_none() is not None


class McpTaskRepository:
    """Durable source of truth for long-running MCP task lifecycle state."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._sf = session_factory

    @staticmethod
    def _row_to_dict(row: McpTaskRow, *, include_internal: bool = False) -> dict[str, Any]:
        data = row.to_dict()
        thread_incarnation = data.pop("thread_incarnation", None)
        if include_internal:
            data["_thread_incarnation"] = thread_incarnation
        for key in _TIMESTAMP_FIELDS:
            if data.get(key) is not None:
                data[key] = coerce_iso(data[key])
        return data

    async def create(
        self,
        *,
        task_id: str,
        user_id: str,
        thread_id: str,
        expected_thread_incarnation: str | None,
        run_id: str | None,
        tool_call_id: str | None,
        server_name: str,
        driver_name: str,
        remote_task_id: str,
        task_name: str,
        status: str,
        result: Any | None,
        result_preview: str | None,
        result_truncated: bool,
        result_artifact: dict[str, str] | None,
        error: str | None,
        input_required: dict[str, Any] | None,
        next_poll_at: datetime | None,
        driver_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(UTC)
        row = McpTaskRow(
            id=task_id,
            user_id=user_id,
            thread_id=thread_id,
            run_id=run_id,
            tool_call_id=tool_call_id,
            server_name=server_name,
            driver_name=driver_name,
            remote_task_id=remote_task_id,
            task_name=task_name,
            status=status,
            result=result,
            result_preview=result_preview,
            result_truncated=result_truncated,
            result_artifact=result_artifact,
            error=error,
            input_required=input_required,
            driver_data=dict(driver_data or {}),
            notification_status="none",
            next_poll_at=next_poll_at,
            completed_at=now if status in _TERMINAL_STATUS_VALUES else None,
            created_at=now,
            updated_at=now,
        )
        _record_event_if_changed(row, tracking_degraded=False, now=now)
        async with self._sf() as session:
            if not await _lock_current_thread_incarnation(
                session,
                user_id=user_id,
                thread_id=thread_id,
                thread_incarnation=expected_thread_incarnation,
            ):
                raise McpTaskThreadMismatchError("MCP task submission crossed a thread lifecycle boundary")
            row.thread_incarnation = expected_thread_incarnation
            session.add(row)
            try:
                await session.commit()
            except IntegrityError as exc:
                await session.rollback()
                if _is_remote_task_unique_conflict(exc):
                    raise DuplicateMcpRemoteTaskError(f"Remote MCP task {remote_task_id!r} is already tracked for server {server_name!r} by this user") from exc
                raise
            await session.refresh(row)
            return self._row_to_dict(row)

    async def get(
        self,
        task_id: str,
        *,
        user_id: str,
        thread_id: str,
        thread_incarnation: str | None,
    ) -> dict[str, Any] | None:
        async with self._sf() as session:
            stmt = select(McpTaskRow).where(
                McpTaskRow.id == task_id,
                McpTaskRow.user_id == user_id,
                McpTaskRow.thread_id == thread_id,
                McpTaskRow.thread_incarnation.is_not_distinct_from(thread_incarnation),
                _matches_current_thread_incarnation(
                    user_id=user_id,
                    thread_id=thread_id,
                    thread_incarnation=thread_incarnation,
                ),
            )
            row = (await session.execute(stmt)).scalar_one_or_none()
            return self._row_to_dict(row) if row is not None else None

    async def list_by_thread(
        self,
        thread_id: str,
        *,
        user_id: str,
        thread_incarnation: str | None,
        limit: int = 50,
        active_only: bool = False,
        status: TaskStatus | None = None,
    ) -> list[dict[str, Any]]:
        stmt = select(McpTaskRow).where(
            McpTaskRow.thread_id == thread_id,
            McpTaskRow.user_id == user_id,
            McpTaskRow.thread_incarnation.is_not_distinct_from(thread_incarnation),
            _matches_current_thread_incarnation(
                user_id=user_id,
                thread_id=thread_id,
                thread_incarnation=thread_incarnation,
            ),
        )
        if active_only:
            stmt = stmt.where(McpTaskRow.status.in_(_POLLABLE_STATUS_VALUES))
        if status is not None:
            stmt = stmt.where(McpTaskRow.status == TaskStatus(status).value)
        stmt = stmt.order_by(McpTaskRow.created_at.desc(), McpTaskRow.id.desc()).limit(limit)
        async with self._sf() as session:
            result = await session.execute(stmt)
            return [self._row_to_dict(row) for row in result.scalars()]

    async def claim_due_tasks(
        self,
        *,
        now: datetime,
        lease_owner: str,
        lease_seconds: int,
        limit: int,
        exclude_task_ids: tuple[str, ...] = (),
    ) -> list[dict[str, Any]]:
        lease_expires_at = now + timedelta(seconds=lease_seconds)
        claimable = (
            McpTaskRow.status.in_(_POLLABLE_STATUS_VALUES),
            McpTaskRow.cancel_requested_at.is_(None),
            McpTaskRow.next_poll_at.is_not(None),
            McpTaskRow.next_poll_at <= now,
            or_(
                McpTaskRow.lease_expires_at.is_(None),
                McpTaskRow.lease_expires_at < now,
            ),
        )
        stmt = select(McpTaskRow.id).where(*claimable).order_by(McpTaskRow.next_poll_at.asc(), McpTaskRow.id.asc()).limit(limit).with_for_update(skip_locked=True)
        if exclude_task_ids:
            stmt = stmt.where(McpTaskRow.id.not_in(exclude_task_ids))
        async with self._sf() as session:
            candidate_ids = list((await session.execute(stmt)).scalars())
            # Atomic fence: ``with_for_update()`` is a no-op on SQLite, so a
            # cancel request can commit between the SELECT and the claim. It
            # clears the poll lease for the cancellation worker; writing the
            # lease back would hold off the remote cancel until it expires.
            # Each conditional UPDATE re-checks the claim predicates, and a
            # row that stopped being claimable is skipped. It is not replaced
            # from beyond the LIMIT: such a batch comes back short (SQLite
            # only; Postgres row locks keep candidates claimable) and the
            # remaining due rows are claimed on the next poll cycle.
            claimed_ids: list[str] = []
            for task_id in candidate_ids:
                update_result = await session.execute(
                    update(McpTaskRow)
                    .where(McpTaskRow.id == task_id, *claimable)
                    .values(
                        lease_owner=lease_owner,
                        lease_expires_at=lease_expires_at,
                        lease_token=_new_claim_token(),
                        poll_attempt_count=McpTaskRow.poll_attempt_count + 1,
                        updated_at=now,
                    )
                )
                if update_result.rowcount:
                    claimed_ids.append(task_id)
            claimed: list[dict[str, Any]] = []
            if claimed_ids:
                rows = {row.id: row for row in (await session.execute(select(McpTaskRow).where(McpTaskRow.id.in_(claimed_ids)))).scalars()}
                claimed = [self._row_to_dict(rows[task_id], include_internal=True) for task_id in claimed_ids]
            await session.commit()
            return claimed

    async def renew_control_claim(
        self,
        task_id: str,
        *,
        phase: Literal["poll", "cancel"],
        lease_owner: str,
        lease_token: str,
        now: datetime,
        lease_seconds: int,
    ) -> bool:
        """Extend only the still-live control claim; never resurrect a lease."""
        if phase not in ("poll", "cancel"):
            raise ValueError("Unknown MCP control claim phase")
        expires_at = now + timedelta(seconds=lease_seconds)
        async with self._sf() as session:
            result = await session.execute(
                update(McpTaskRow)
                .where(
                    McpTaskRow.id == task_id,
                    McpTaskRow.lease_owner == lease_owner,
                    McpTaskRow.lease_token == lease_token,
                    McpTaskRow.lease_expires_at >= now,
                    McpTaskRow.status.not_in(_TERMINAL_STATUS_VALUES),
                    McpTaskRow.cancel_requested_at.is_(None) if phase == "poll" else McpTaskRow.cancel_requested_at.is_not(None),
                )
                .values(
                    # A backward wall-clock correction must not shorten a lease.
                    lease_expires_at=case((McpTaskRow.lease_expires_at > expires_at, McpTaskRow.lease_expires_at), else_=expires_at),
                    updated_at=McpTaskRow.updated_at,
                )
            )
            await session.commit()
            return bool(result.rowcount)

    async def apply_snapshot(
        self,
        task_id: str,
        *,
        lease_owner: str,
        lease_token: str,
        status: str,
        result: Any | None,
        result_preview: str | None,
        result_truncated: bool,
        result_artifact: dict[str, str] | None,
        error: str | None,
        input_required: dict[str, Any] | None,
        next_poll_at: datetime | None,
        polled_at: datetime,
    ) -> bool:
        async with self._sf() as session:
            # Atomic fence: a poll result from an older generation must not
            # overwrite a claim a newer generation reclaimed after lease expiry.
            values: dict[str, Any] = {
                "status": status,
                "result": result,
                "result_preview": result_preview,
                "result_truncated": result_truncated,
                "result_artifact": result_artifact,
                "error": error,
                "input_required": input_required,
                "next_poll_at": next_poll_at,
                "last_polled_at": polled_at,
                "last_poll_error": None,
                "consecutive_poll_error_count": 0,
                "lease_owner": None,
                "lease_expires_at": None,
                "lease_token": None,
                "updated_at": polled_at,
            }
            if status in _TERMINAL_STATUS_VALUES:
                values["completed_at"] = polled_at
            update_result = await session.execute(
                update(McpTaskRow)
                .where(
                    McpTaskRow.id == task_id,
                    McpTaskRow.lease_owner == lease_owner,
                    McpTaskRow.lease_token == lease_token,
                    McpTaskRow.lease_expires_at >= polled_at,
                    McpTaskRow.status.not_in(_TERMINAL_STATUS_VALUES),
                    McpTaskRow.cancel_requested_at.is_(None),
                )
                .values(**values)
            )
            if not update_result.rowcount:
                return False
            row = (await session.execute(select(McpTaskRow).where(McpTaskRow.id == task_id))).scalar_one_or_none()
            if row is not None:
                _record_event_if_changed(row, tracking_degraded=False, now=polled_at)
            await session.commit()
            return True

    async def release_claim(
        self,
        task_id: str,
        *,
        lease_owner: str,
        lease_token: str,
        next_poll_at: datetime,
        error: str,
        tracking_degraded_after_errors: int = 3,
    ) -> bool:
        async with self._sf() as session:
            now = datetime.now(UTC)
            # Atomic fence: only clear the claim if the owner AND per-claim token
            # still match. ``with_for_update()`` is a no-op on SQLite, so the old
            # select-then-write could clear a claim that a newer generation had
            # reclaimed after lease expiry. A conditional UPDATE makes the fence
            # atomic: a stale release (rowcount 0) is a no-op and never mutates a
            # newer claim.
            update_result = await session.execute(
                update(McpTaskRow)
                .where(
                    McpTaskRow.id == task_id,
                    McpTaskRow.lease_owner == lease_owner,
                    McpTaskRow.lease_token == lease_token,
                )
                .values(
                    next_poll_at=next_poll_at,
                    last_poll_error=error,
                    consecutive_poll_error_count=McpTaskRow.consecutive_poll_error_count + 1,
                    lease_owner=None,
                    lease_expires_at=None,
                    lease_token=None,
                    updated_at=now,
                )
            )
            if not update_result.rowcount:
                return False
            # The fence won and we hold the write lock, so read the released row
            # consistently and record the poll-failure tracking event.
            row = (await session.execute(select(McpTaskRow).where(McpTaskRow.id == task_id))).scalar_one_or_none()
            if row is not None:
                _record_event_if_changed(
                    row,
                    tracking_degraded=int(row.consecutive_poll_error_count or 0) >= tracking_degraded_after_errors,
                    now=now,
                )
            await session.commit()
            return True

    async def release_poll_claim_after_cancellation(
        self,
        task_id: str,
        *,
        lease_owner: str,
        lease_token: str,
    ) -> bool:
        """Release a cancelled poll's lease without recording a poll failure."""
        stmt = (
            update(McpTaskRow)
            .where(
                McpTaskRow.id == task_id,
                McpTaskRow.lease_owner == lease_owner,
                McpTaskRow.lease_token == lease_token,
            )
            .values(
                lease_owner=None,
                lease_expires_at=None,
                lease_token=None,
                updated_at=datetime.now(UTC),
            )
        )
        async with self._sf() as session:
            result = await session.execute(stmt)
            await session.commit()
            return bool(result.rowcount)

    async def request_cancel(
        self,
        task_id: str,
        *,
        user_id: str,
        thread_id: str,
        thread_incarnation: str | None,
        requested_at: datetime,
    ) -> dict[str, Any] | None:
        """Persist a user-scoped cancellation request without exposing the remote id."""
        async with self._sf() as session:
            if not await _lock_current_thread_incarnation(
                session,
                user_id=user_id,
                thread_id=thread_id,
                thread_incarnation=thread_incarnation,
            ):
                await session.rollback()
                return None
            stmt = (
                select(McpTaskRow)
                .where(
                    McpTaskRow.id == task_id,
                    McpTaskRow.user_id == user_id,
                    McpTaskRow.thread_id == thread_id,
                    McpTaskRow.thread_incarnation.is_not_distinct_from(thread_incarnation),
                    _matches_current_thread_incarnation(
                        user_id=user_id,
                        thread_id=thread_id,
                        thread_incarnation=thread_incarnation,
                    ),
                )
                .with_for_update()
            )
            row = (await session.execute(stmt)).scalar_one_or_none()
            if row is None:
                return None
            if row.status not in _TERMINAL_STATUS_VALUES and row.cancel_requested_at is None:
                row.cancel_requested_at = requested_at
                if row.next_cancel_at is None:
                    row.next_cancel_at = requested_at
                # A cancel request fences any in-flight poll result, so its
                # poll lease can be released immediately for the cancellation
                # worker. A repeated request must preserve an existing cancel
                # lease so it cannot trigger a concurrent remote cancellation.
                row.lease_owner = None
                row.lease_expires_at = None
                row.lease_token = None
                row.updated_at = requested_at
                await session.commit()
            return self._row_to_dict(row)

    async def claim_cancel_requests(
        self,
        *,
        now: datetime,
        lease_owner: str,
        lease_seconds: int,
        limit: int,
        exclude_task_ids: tuple[str, ...] = (),
        task_id: str | None = None,
    ) -> list[dict[str, Any]]:
        stmt = select(McpTaskRow).where(
            McpTaskRow.cancel_requested_at.is_not(None),
            McpTaskRow.status.not_in(_TERMINAL_STATUS_VALUES),
            McpTaskRow.next_cancel_at.is_not(None),
            McpTaskRow.next_cancel_at <= now,
            or_(McpTaskRow.lease_expires_at.is_(None), McpTaskRow.lease_expires_at < now),
        )
        if task_id is not None:
            stmt = stmt.where(McpTaskRow.id == task_id)
        stmt = stmt.order_by(McpTaskRow.next_cancel_at.asc(), McpTaskRow.id.asc()).limit(limit).with_for_update(skip_locked=True)
        if exclude_task_ids:
            stmt = stmt.where(McpTaskRow.id.not_in(exclude_task_ids))
        async with self._sf() as session:
            if session.get_bind().dialect.name == "sqlite":
                # SQLite ignores FOR UPDATE. Reserve its writer before reading
                # candidates so two workers cannot return the same claim.
                await session.execute(text("BEGIN IMMEDIATE"))
            rows = list((await session.execute(stmt)).scalars())
            expires_at = now + timedelta(seconds=lease_seconds)
            for row in rows:
                row.lease_owner = lease_owner
                row.lease_expires_at = expires_at
                row.lease_token = _new_claim_token()
                row.cancel_attempt_count = int(row.cancel_attempt_count or 0) + 1
                row.updated_at = now
            await session.commit()
            return [self._row_to_dict(row, include_internal=True) for row in rows]

    async def apply_cancel_snapshot(
        self,
        task_id: str,
        *,
        lease_owner: str,
        lease_token: str,
        status: str,
        result: Any | None,
        result_preview: str | None,
        result_truncated: bool,
        result_artifact: dict[str, str] | None,
        error: str | None,
        input_required: dict[str, Any] | None,
        completed_at: datetime,
    ) -> bool:
        if status not in _TERMINAL_STATUS_VALUES:
            raise ValueError("A cancellation response must report a terminal task status")
        async with self._sf() as session:
            update_result = await session.execute(
                update(McpTaskRow)
                .where(
                    McpTaskRow.id == task_id,
                    McpTaskRow.lease_owner == lease_owner,
                    McpTaskRow.lease_token == lease_token,
                    McpTaskRow.lease_expires_at >= completed_at,
                    McpTaskRow.status.not_in(_TERMINAL_STATUS_VALUES),
                )
                .values(
                    status=status,
                    result=result,
                    result_preview=result_preview,
                    result_truncated=result_truncated,
                    result_artifact=result_artifact,
                    error=error,
                    input_required=input_required,
                    next_poll_at=None,
                    next_cancel_at=None,
                    last_cancel_error=None,
                    lease_owner=None,
                    lease_expires_at=None,
                    lease_token=None,
                    completed_at=completed_at,
                    updated_at=completed_at,
                )
            )
            if not update_result.rowcount:
                return False
            row = (await session.execute(select(McpTaskRow).where(McpTaskRow.id == task_id))).scalar_one_or_none()
            if row is not None:
                _record_event_if_changed(row, tracking_degraded=False, now=completed_at)
            await session.commit()
            return True

    async def release_cancel_claim(
        self,
        task_id: str,
        *,
        lease_owner: str,
        lease_token: str,
        next_cancel_at: datetime,
        error: str | None,
    ) -> bool:
        stmt = (
            update(McpTaskRow)
            .where(
                McpTaskRow.id == task_id,
                McpTaskRow.lease_owner == lease_owner,
                McpTaskRow.lease_token == lease_token,
            )
            .values(
                next_cancel_at=next_cancel_at,
                last_cancel_error=error,
                lease_owner=None,
                lease_expires_at=None,
                lease_token=None,
                updated_at=datetime.now(UTC),
            )
        )
        async with self._sf() as session:
            result = await session.execute(stmt)
            await session.commit()
            return bool(result.rowcount)

    async def claim_notification_work(
        self,
        *,
        now: datetime,
        lease_owner: str,
        lease_seconds: int,
        limit: int,
        tracking_degraded_after_errors: int,
    ) -> list[dict[str, Any]]:
        statuses = ("pending", "claimed", "launching", "retry", "dispatched")
        stmt = (
            select(McpTaskRow)
            .where(
                McpTaskRow.event_version > McpTaskRow.notified_version,
                McpTaskRow.notification_status.in_(statuses),
                or_(McpTaskRow.next_notification_at.is_(None), McpTaskRow.next_notification_at <= now),
                or_(McpTaskRow.notification_lease_expires_at.is_(None), McpTaskRow.notification_lease_expires_at < now),
            )
            .order_by(McpTaskRow.next_notification_at.asc(), McpTaskRow.id.asc())
            .limit(limit)
            .with_for_update(skip_locked=True)
        )
        async with self._sf() as session:
            rows = list((await session.execute(stmt)).scalars())
            expires_at = now + timedelta(seconds=lease_seconds)
            # SQLite ignores ``FOR UPDATE``, so a claim is also fenced on the
            # state this read saw. A peer claim (future lease, changed phase), a
            # release/defer moving the next attempt, or a newer recorded event
            # changes one of those columns, the conditional UPDATE matches no
            # row, and the paused claim has no side effects instead of
            # overwriting the winning worker or bypassing its backoff.
            sqlite = session.get_bind().dialect.name == "sqlite"
            claimed: list[McpTaskRow] = []
            for row in rows:
                rebuild_snapshot = row.notification_status in ("pending", "claimed") or (row.notification_status == "retry" and row.dispatch_version != row.event_version)
                if not rebuild_snapshot and row.dispatch_event is None and row.dispatch_version != row.event_version:
                    # A legacy in-flight phase whose dispatch payload is gone, with
                    # a newer event already recorded: claim that newer event instead
                    # of consuming it. Terminal tasks stop polling, so a consumed
                    # completion would be lost permanently.
                    rebuild_snapshot = True
                event = (
                    _notification_event(
                        row,
                        tracking_degraded=int(row.consecutive_poll_error_count or 0) >= tracking_degraded_after_errors,
                    )
                    if rebuild_snapshot
                    else row.dispatch_event
                )
                dispatch_version_fence = McpTaskRow.dispatch_version.is_(None) if row.dispatch_version is None else McpTaskRow.dispatch_version == row.dispatch_version
                next_notification_fence = McpTaskRow.next_notification_at.is_(None) if row.next_notification_at is None else McpTaskRow.next_notification_at == row.next_notification_at
                if event is None:
                    # The condition behind this snapshot resolved before delivery
                    # (for example tracking recovered, or an input_required prompt
                    # was answered), or the row carries an empty generation left by
                    # a pre-fix claim. Consume only what was proven empty — the
                    # current event version for a rebuild, the empty dispatch
                    # generation otherwise — through a conditional UPDATE fenced on
                    # the event version, phase and dispatch version this read saw.
                    # SQLite has no ``SELECT FOR UPDATE``, so a newer event recorded
                    # after the read must win: the fence then matches no row, this
                    # consume is a no-op, and the newer event stays claimable.
                    # Clearing the content fingerprint keeps an identical later
                    # event from being suppressed by a snapshot that was never
                    # delivered.
                    consumed_version = row.event_version if rebuild_snapshot else (row.dispatch_version if row.dispatch_version is not None else row.event_version)
                    status_at_read = row.notification_status
                    session.expunge(row)
                    await session.execute(
                        update(McpTaskRow)
                        .where(
                            McpTaskRow.id == row.id,
                            McpTaskRow.event_version == consumed_version,
                            McpTaskRow.notification_status == status_at_read,
                            dispatch_version_fence,
                        )
                        .values(
                            notified_version=consumed_version,
                            event_fingerprint=None,
                            notification_status="none",
                            notification_error=None,
                            notification_attempt_count=0,
                            dispatch_version=None,
                            dispatch_attempt=0,
                            dispatch_event=None,
                            notification_run_id=None,
                            notification_lease_owner=None,
                            notification_lease_expires_at=None,
                            notification_lease_token=None,
                            updated_at=now,
                        )
                    )
                    continue
                claim_token = _new_claim_token()
                claim_values: dict[str, Any] = {
                    "notification_lease_owner": lease_owner,
                    "notification_lease_expires_at": expires_at,
                    "notification_lease_token": claim_token,
                    "updated_at": now,
                }
                if rebuild_snapshot:
                    claim_values.update(
                        dispatch_version=row.event_version,
                        dispatch_event=event,
                        notification_run_id=None,
                        notification_status="claimed",
                    )
                    if row.dispatch_version != row.event_version:
                        claim_values.update(dispatch_attempt=0, notification_attempt_count=0)
                if sqlite:
                    claim_result = await session.execute(
                        update(McpTaskRow)
                        .where(
                            McpTaskRow.id == row.id,
                            McpTaskRow.event_version == row.event_version,
                            McpTaskRow.notification_status == row.notification_status,
                            dispatch_version_fence,
                            next_notification_fence,
                            or_(
                                McpTaskRow.notification_lease_expires_at.is_(None),
                                McpTaskRow.notification_lease_expires_at < now,
                            ),
                        )
                        .values(**claim_values)
                        .execution_options(synchronize_session=False)
                    )
                    if not claim_result.rowcount:
                        # A peer claimed the row or a newer event was recorded
                        # after this read; leave it to the next claim cycle.
                        session.expunge(row)
                        continue
                    session.expunge(row)
                for field, value in claim_values.items():
                    setattr(row, field, value)
                claimed.append(row)
            await session.commit()
            return [self._row_to_dict(row) for row in claimed]

    async def begin_notification_launch(
        self,
        task_id: str,
        *,
        lease_owner: str,
        notification_lease_token: str,
        dispatch_version: int,
        lease_seconds: int,
        now: datetime,
    ) -> bool:
        """Reserve one idempotent Agent launch before starting the side effect."""
        launchable = or_(
            McpTaskRow.notification_status == "launching",
            and_(
                McpTaskRow.notification_status.in_(("claimed", "retry")),
                McpTaskRow.event_version == dispatch_version,
            ),
        )
        stmt = (
            update(McpTaskRow)
            .where(
                McpTaskRow.id == task_id,
                McpTaskRow.notification_lease_owner == lease_owner,
                McpTaskRow.notification_lease_token == notification_lease_token,
                McpTaskRow.notification_lease_expires_at >= now,
                McpTaskRow.dispatch_version == dispatch_version,
                launchable,
            )
            .values(
                notification_status="launching",
                notification_lease_expires_at=now + timedelta(seconds=lease_seconds),
                updated_at=now,
            )
        )
        async with self._sf() as session:
            result = await session.execute(stmt)
            await session.commit()
            return bool(result.rowcount)

    async def mark_notification_dispatched(
        self,
        task_id: str,
        *,
        lease_owner: str,
        notification_lease_token: str,
        dispatch_version: int,
        run_id: str,
        now: datetime,
    ) -> bool:
        stmt = (
            update(McpTaskRow)
            .where(
                McpTaskRow.id == task_id,
                McpTaskRow.notification_lease_owner == lease_owner,
                McpTaskRow.notification_lease_token == notification_lease_token,
                McpTaskRow.notification_lease_expires_at >= now,
                McpTaskRow.dispatch_version == dispatch_version,
                McpTaskRow.notification_status.in_(("claimed", "launching", "retry")),
            )
            .values(
                notification_status="dispatched",
                notification_run_id=run_id,
                notification_error=None,
                next_notification_at=now,
                notification_lease_owner=None,
                notification_lease_expires_at=None,
                notification_lease_token=None,
                updated_at=now,
            )
        )
        async with self._sf() as session:
            result = await session.execute(stmt)
            await session.commit()
            return bool(result.rowcount)

    async def release_notification_claim(
        self,
        task_id: str,
        *,
        lease_owner: str,
        notification_lease_token: str,
        next_notification_at: datetime,
        error: str | None,
        replace_with_latest: bool,
        count_failure: bool = False,
    ) -> bool:
        values: dict[str, Any] = {
            "notification_status": "pending" if replace_with_latest else "retry",
            "notification_error": error,
            "next_notification_at": next_notification_at,
            "notification_lease_owner": None,
            "notification_lease_expires_at": None,
            "notification_lease_token": None,
            "updated_at": datetime.now(UTC),
        }
        if replace_with_latest:
            values.update(
                dispatch_event=None,
                notification_run_id=None,
            )
        if count_failure:
            values["notification_attempt_count"] = McpTaskRow.notification_attempt_count + 1
        stmt = (
            update(McpTaskRow)
            .where(
                McpTaskRow.id == task_id,
                McpTaskRow.notification_lease_owner == lease_owner,
                McpTaskRow.notification_lease_token == notification_lease_token,
            )
            .values(**values)
        )
        async with self._sf() as session:
            result = await session.execute(stmt)
            await session.commit()
            return bool(result.rowcount)

    async def finish_notification_run(
        self,
        task_id: str,
        *,
        lease_owner: str,
        notification_lease_token: str,
        dispatch_version: int,
        delivered: bool,
        next_notification_at: datetime | None,
        error: str | None,
        now: datetime,
    ) -> bool:
        if delivered:
            # A newer event may have arrived after this dispatch was queued; keep
            # it pending for redelivery instead of swallowing it as delivered.
            newer = McpTaskRow.event_version > dispatch_version
            values: dict[str, Any] = {
                "notified_version": dispatch_version,
                "notification_status": case((newer, "pending"), else_="delivered"),
                "dispatch_version": None,
                "dispatch_attempt": 0,
                "dispatch_event": None,
                "notification_run_id": None,
                "notification_error": None,
                "notification_attempt_count": 0,
                "next_notification_at": case((newer, now), else_=None),
            }
        else:
            values = {
                "notification_status": "retry",
                "dispatch_attempt": McpTaskRow.dispatch_attempt + 1,
                "notification_attempt_count": McpTaskRow.notification_attempt_count + 1,
                "notification_run_id": None,
                "notification_error": error,
                "next_notification_at": next_notification_at,
            }
        values.update(
            notification_lease_owner=None,
            notification_lease_expires_at=None,
            notification_lease_token=None,
            updated_at=now,
        )
        async with self._sf() as session:
            result = await session.execute(
                update(McpTaskRow)
                .where(
                    McpTaskRow.id == task_id,
                    McpTaskRow.notification_lease_owner == lease_owner,
                    McpTaskRow.notification_lease_token == notification_lease_token,
                    McpTaskRow.notification_lease_expires_at >= now,
                    McpTaskRow.dispatch_version == dispatch_version,
                    McpTaskRow.notification_status == "dispatched",
                )
                .values(**values)
            )
            await session.commit()
            return bool(result.rowcount)

    async def release_notification_lease(
        self,
        task_id: str,
        *,
        lease_owner: str,
        notification_lease_token: str,
        next_notification_at: datetime,
        error: str | None,
        count_failure: bool = False,
    ) -> bool:
        """Release unexpected notification work without changing its phase."""
        values: dict[str, Any] = {
            "notification_error": error,
            "next_notification_at": next_notification_at,
            "notification_lease_owner": None,
            "notification_lease_expires_at": None,
            "notification_lease_token": None,
            "updated_at": datetime.now(UTC),
        }
        if count_failure:
            values["notification_attempt_count"] = McpTaskRow.notification_attempt_count + 1
        stmt = (
            update(McpTaskRow)
            .where(
                McpTaskRow.id == task_id,
                McpTaskRow.notification_lease_owner == lease_owner,
                McpTaskRow.notification_lease_token == notification_lease_token,
            )
            .values(**values)
        )
        async with self._sf() as session:
            result = await session.execute(stmt)
            await session.commit()
            return bool(result.rowcount)

    async def dead_letter_notification(
        self,
        task_id: str,
        *,
        lease_owner: str,
        notification_lease_token: str,
        dispatch_version: int,
        error: str,
        count_failure: bool,
        now: datetime,
    ) -> bool:
        """Stop one failed snapshot, preserving any newer event for delivery."""
        base_filters = (
            McpTaskRow.id == task_id,
            McpTaskRow.notification_lease_owner == lease_owner,
            McpTaskRow.notification_lease_token == notification_lease_token,
            McpTaskRow.notification_lease_expires_at >= now,
            McpTaskRow.dispatch_version == dispatch_version,
            McpTaskRow.notification_status.in_(("claimed", "launching", "retry", "dispatched")),
        )
        dead_letter_values: dict[str, Any] = {
            "notification_status": "dead_letter",
            "notification_error": error,
            "next_notification_at": None,
            "notification_lease_owner": None,
            "notification_lease_expires_at": None,
            "notification_lease_token": None,
            "dispatch_version": None,
            "dispatch_attempt": 0,
            "dispatch_event": None,
            "notification_run_id": None,
            "updated_at": now,
        }
        if count_failure:
            dead_letter_values["notification_attempt_count"] = McpTaskRow.notification_attempt_count + 1

        async with self._sf() as session:
            dead_lettered = await session.execute(update(McpTaskRow).where(*base_filters, McpTaskRow.event_version <= dispatch_version).values(**dead_letter_values))
            if dead_lettered.rowcount:
                await session.commit()
                return True

            replaced_by_latest = await session.execute(
                update(McpTaskRow)
                .where(*base_filters, McpTaskRow.event_version > dispatch_version)
                .values(
                    notification_status="pending",
                    notification_error=None,
                    notification_attempt_count=0,
                    next_notification_at=now,
                    notification_lease_owner=None,
                    notification_lease_expires_at=None,
                    notification_lease_token=None,
                    dispatch_version=None,
                    dispatch_attempt=0,
                    dispatch_event=None,
                    notification_run_id=None,
                    updated_at=now,
                )
            )
            await session.commit()
            return bool(replaced_by_latest.rowcount)

    async def defer_dispatched_notification(
        self,
        task_id: str,
        *,
        lease_owner: str,
        notification_lease_token: str,
        dispatch_version: int,
        next_notification_at: datetime,
        now: datetime,
    ) -> bool:
        """Release a notification lease while its Agent run is still active."""
        stmt = (
            update(McpTaskRow)
            .where(
                McpTaskRow.id == task_id,
                McpTaskRow.notification_lease_owner == lease_owner,
                McpTaskRow.notification_lease_token == notification_lease_token,
                McpTaskRow.notification_lease_expires_at >= now,
                McpTaskRow.dispatch_version == dispatch_version,
                McpTaskRow.notification_status == "dispatched",
            )
            .values(
                next_notification_at=next_notification_at,
                notification_lease_owner=None,
                notification_lease_expires_at=None,
                notification_lease_token=None,
                updated_at=now,
            )
        )
        async with self._sf() as session:
            result = await session.execute(stmt)
            await session.commit()
            return bool(result.rowcount)
