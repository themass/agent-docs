"""Server-side session storage in Redis."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from redis.asyncio import Redis


@dataclass(frozen=True, slots=True)
class SessionData:
    user_id: str


class RedisSessionStore:
    def __init__(
        self,
        redis: Redis,
        *,
        key_prefix: str = "jc:session:",
        ttl_seconds: int = 7 * 24 * 3600,
    ) -> None:
        self._redis = redis
        self._prefix = key_prefix
        self._ttl = ttl_seconds

    def _key(self, session_id: str) -> str:
        return f"{self._prefix}{session_id}"

    async def create(self, session_id: str, user_id: str) -> None:
        payload = json.dumps({"user_id": user_id})
        await self._redis.setex(self._key(session_id), self._ttl, payload)

    async def get(self, session_id: str) -> SessionData | None:
        raw = await self._redis.get(self._key(session_id))
        if raw is None:
            return None
        data: dict[str, Any] = json.loads(raw)
        user_id = data.get("user_id")
        if not isinstance(user_id, str):
            return None
        return SessionData(user_id=user_id)

    async def touch(self, session_id: str) -> bool:
        return bool(await self._redis.expire(self._key(session_id), self._ttl))

    async def delete(self, session_id: str) -> None:
        await self._redis.delete(self._key(session_id))
