"""AgentKit — shared platform components for agent products."""
__version__ = "0.1.0"
