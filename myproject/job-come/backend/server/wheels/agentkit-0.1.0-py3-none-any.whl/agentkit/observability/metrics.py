"""Prometheus metrics for agent services: one vocabulary, usable from any layer.

The metrics answer four questions an operator actually asks:

1. **Is it slow, and where?** — a duration histogram per *phase* (agent build,
   model call, tool call, stream), so "16 seconds" resolves into named pieces
   instead of one opaque number.
2. **Is it failing?** — a counter split by status and error type.
3. **How much is it doing?** — QPS from the same counter (`rate(...)` in
   PromQL), plus a token counter for model cost.
4. **Which model/gateway?** — labels carry the served model and the endpoint,
   which is what makes a provider regression visible before users report it.

Design constraints, all deliberate:

- **No label may take unbounded values.** A label holding a user id, session id
  or free-text error message explodes the series count and is the usual reason a
  metrics backend falls over. Everything here is a small closed set: scenario,
  model, phase, status, error class.
- **Recording never raises into the caller.** A metrics failure must not break a
  request; every public function is wrapped.
- **Missing ``prometheus_client`` is not an error.** The package stays importable
  in a bare library context and every function degrades to a no-op.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Final

logger = logging.getLogger(__name__)

try:  # pragma: no cover - exercised by the no-prometheus test
    from prometheus_client import (
        CONTENT_TYPE_LATEST,
        REGISTRY,
        Counter,
        Gauge,
        Histogram,
        generate_latest,
    )

    PROMETHEUS_AVAILABLE = True
except ImportError:  # pragma: no cover
    PROMETHEUS_AVAILABLE = False
    CONTENT_TYPE_LATEST = "text/plain; version=0.0.4; charset=utf-8"

    class _Missing:
        """Stand-in so module-level metric definitions stay importable."""

        def labels(self, *a: Any, **kw: Any) -> "_Missing":
            return self

        def inc(self, *a: Any, **kw: Any) -> None:
            return None

        def observe(self, *a: Any, **kw: Any) -> None:
            return None

        def set(self, *a: Any, **kw: Any) -> None:
            return None

    Counter = Gauge = Histogram = lambda *a, **kw: _Missing()  # noqa: E731
    REGISTRY = None
    generate_latest = lambda *_a, **_kw: b""  # noqa: E731

CONTENT_TYPE: Final = CONTENT_TYPE_LATEST

_lock = threading.Lock()
_state: dict[str, Any] = {"app": "agent", "env": "dev", "enabled": True}

#: Boundaries chosen from measured agent behaviour rather than a generic default:
#: a model call is 3–15 s here, an agent build 4–40 s, and a whole turn 10–60 s.
#: The dense region is 1–30 s because that is where "is this normal?" is decided;
#: 60 s+ exists only so a pathological run still lands in a bucket.
_LATENCY_BUCKETS: Final = (
    0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 8.0, 10.0,
    15.0, 20.0, 30.0, 45.0, 60.0, 90.0, 120.0, 180.0, 300.0, float("inf"),
)


def configure(*, application: str, environment: str, enabled: bool = True) -> None:
    """Name this service and its environment. Call once at startup.

    The two become labels on every series, which is what lets one Prometheus
    scrape several deployments and still tell them apart.
    """
    with _lock:
        _state["app"] = application
        _state["env"] = environment
        _state["enabled"] = bool(enabled) and PROMETHEUS_AVAILABLE
    if enabled and not PROMETHEUS_AVAILABLE:
        logger.warning(
            "observability.configure(enabled=True) but prometheus_client is not "
            "installed; all metrics are no-ops"
        )


def metrics_enabled() -> bool:
    return bool(_state["enabled"])


def _base() -> dict[str, str]:
    return {"application": str(_state["app"]), "env": str(_state["env"])}


def _metric(factory: Any, name: str, doc: str, labels: tuple[str, ...], **kw: Any) -> Any:
    """Create one metric, tolerating a duplicate registration in the same process.

    Tests and reloads can import this module twice; prometheus_client raises on a
    duplicate name. Returning the already-registered collector keeps that a
    non-event instead of a startup crash.
    """
    try:
        return factory(name, doc, labels, **kw)
    except ValueError:
        for coll in getattr(REGISTRY, "_names_to_collectors", {}).values():
            if getattr(coll, "_name", None) == name:
                return coll
        raise


# --------------------------------------------------------------------------
# Metric definitions
# --------------------------------------------------------------------------
# Only created when prometheus is present, so the no-dependency path never even
# touches the registry.

if PROMETHEUS_AVAILABLE:  # pragma: no branch
    LLM_LATENCY = _metric(
        Histogram, "llm_call_duration_seconds",
        "One model call, end to end (includes gateway queueing).",
        ("application", "env", "scenario", "model", "status"),
        buckets=_LATENCY_BUCKETS,
    )
    LLM_CALLS = _metric(
        Counter, "llm_calls_total",
        "Model calls by scenario, served model and outcome.",
        ("application", "env", "scenario", "model", "status", "error_type"),
    )
    LLM_TOKENS = _metric(
        Counter, "llm_tokens_total",
        "Tokens consumed, split by direction.",
        ("application", "env", "scenario", "model", "direction"),
    )
    LLM_ATTEMPTS = _metric(
        Histogram, "llm_attempts_per_call",
        "How many endpoints one logical call needed; >1 means failover kicked in.",
        ("application", "env", "scenario"),
        buckets=(1.0, 2.0, 3.0, 4.0, 5.0, float("inf")),
    )
    AGENT_PHASE = _metric(
        Histogram, "agent_phase_duration_seconds",
        "Named phase inside an agent turn (build / model / tool / stream).",
        ("application", "env", "phase", "outcome"),
        buckets=_LATENCY_BUCKETS,
    )
    AGENT_TURNS = _metric(
        Counter, "agent_turns_total",
        "Agent turns started, by role and outcome.",
        ("application", "env", "role", "status"),
    )
    METHOD_LATENCY = _metric(
        Histogram, "method_duration_seconds",
        "Any decorated method's duration; `target` is Class.method.",
        ("application", "env", "target", "status"),
        buckets=_LATENCY_BUCKETS,
    )
    METHOD_CALLS = _metric(
        Counter, "method_calls_total",
        "Any decorated method's call count and outcome.",
        ("application", "env", "target", "status", "error_type"),
    )
    INFLIGHT = _metric(
        Gauge, "agent_turns_in_flight",
        "Turns currently running; a number that only grows means something is stuck.",
        ("application", "env"),
    )


# --------------------------------------------------------------------------
# Recording
# --------------------------------------------------------------------------


def record_llm_metrics(
    *,
    scenario: str,
    model: str | None,
    duration: float | None = None,
    status: str = "success",
    error_type: str | None = None,
    prompt_tokens: int | None = None,
    completion_tokens: int | None = None,
    attempts: int | None = None,
) -> None:
    """One logical model call, after it finished or failed.

    ``status``/``error_type`` are the only place failure detail enters a metric,
    and both are short closed sets — never an exception message, which would be
    unbounded and can contain user data.
    """
    if not metrics_enabled():
        return
    try:
        labels = {**_base(), "scenario": scenario or "unknown",
                  "model": model or "unknown"}
        if duration is not None:
            LLM_LATENCY.labels(**labels, status=status).observe(duration)
        LLM_CALLS.labels(**labels, status=status,
                         error_type=(error_type or "")[:48]).inc()
        if prompt_tokens:
            LLM_TOKENS.labels(**labels, direction="input").inc(prompt_tokens)
        if completion_tokens:
            LLM_TOKENS.labels(**labels, direction="output").inc(completion_tokens)
        if attempts is not None:
            LLM_ATTEMPTS.labels(**_base(), scenario=scenario or "unknown").observe(attempts)
    except Exception:  # pragma: no cover - metrics must never break a request
        logger.debug("record_llm_metrics failed", exc_info=True)


def record_agent_phase(*, phase: str, duration: float, outcome: str = "ok") -> None:
    """One named phase of a turn. Phases are the unit that makes a slow turn legible.

    Called from the turn loop with e.g. ``build`` (graph construction), ``ttft``
    (send → first token), ``generate`` (first token → done), ``tool``.
    """
    if not metrics_enabled():
        return
    try:
        AGENT_PHASE.labels(**_base(), phase=phase, outcome=outcome).observe(duration)
    except Exception:  # pragma: no cover
        logger.debug("record_agent_phase failed", exc_info=True)


def record_agent_turn(*, role: str, status: str = "success") -> None:
    if not metrics_enabled():
        return
    try:
        AGENT_TURNS.labels(**_base(), role=role or "unknown", status=status).inc()
    except Exception:  # pragma: no cover
        logger.debug("record_agent_turn failed", exc_info=True)


def record_method(*, target: str, duration: float, status: str, error_type: str | None = None) -> None:
    if not metrics_enabled():
        return
    try:
        METHOD_LATENCY.labels(**_base(), target=target, status=status).observe(duration)
        METHOD_CALLS.labels(**_base(), target=target, status=status,
                            error_type=(error_type or "")[:48]).inc()
    except Exception:  # pragma: no cover
        logger.debug("record_method failed", exc_info=True)


class _Inflight:
    """Track concurrent turns so a leak shows up as a gauge that only rises."""

    def __enter__(self) -> "_Inflight":
        if metrics_enabled():
            try:
                INFLIGHT.labels(**_base()).inc()
            except Exception:  # pragma: no cover
                pass
        return self

    def __exit__(self, *exc: Any) -> None:
        if metrics_enabled():
            try:
                INFLIGHT.labels(**_base()).dec()
            except Exception:  # pragma: no cover
                pass


def inflight_turn() -> _Inflight:
    return _Inflight()


# Thin factories, kept only so a caller can add its own metric with the same
# conventions (base labels, same registry) instead of re-deriving them.
def counter(name: str, doc: str, labels: tuple[str, ...]) -> Any:
    return _metric(Counter, name, doc, (*labels, "application", "env"))


def gauge(name: str, doc: str, labels: tuple[str, ...]) -> Any:
    return _metric(Gauge, name, doc, (*labels, "application", "env"))


def histogram(name: str, doc: str, labels: tuple[str, ...]) -> Any:
    return _metric(Histogram, name, doc, (*labels, "application", "env"),
                   buckets=_LATENCY_BUCKETS)


def render_metrics() -> bytes:
    """The scrape payload. Empty (not an error) when metrics are off."""
    if not PROMETHEUS_AVAILABLE:
        return b"# prometheus_client not installed\n"
    try:
        return generate_latest(REGISTRY)
    except Exception:  # pragma: no cover
        logger.warning("render_metrics failed", exc_info=True)
        return b"# metrics unavailable\n"
