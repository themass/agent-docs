"""Memory updater for reading, writing, and updating memory data."""

import asyncio
import atexit
import concurrent.futures
import copy
import hashlib
import html
import json
import logging
import math
import re
import time
import uuid
from collections import OrderedDict
from datetime import UTC, datetime, timedelta
from typing import Any

from ..config import DeerMemConfig
from .eviction import (
    EVICTION_POLICY_CONFIDENCE,
    EVICTION_POLICY_HYBRID_V1,
    FactEvictionDecision,
    select_facts_for_capacity,
)
from .message_processing import detect_signals, extract_message_text
from .prompt import (
    format_conversation_for_update,
    load_prompt,
    load_prompt_messages,
)
from .storage import (
    MemoryManifestRevisionConflict,
    MemoryStorage,
    create_empty_memory,
    normalize_memory_data,
    utc_now_iso_z,
)

logger = logging.getLogger(__name__)


# Thread pool for offloading sync memory updates when called from an async
# context.  Unlike the previous asyncio.run() approach, this runs *sync*
# model.invoke() calls — no event loop is created, so the langchain async
# httpx client pool (globally cached via @lru_cache) is never touched and
# cross-loop connection reuse is impossible.
_SYNC_MEMORY_UPDATER_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=4,
    thread_name_prefix="memory-updater-sync",
)
atexit.register(lambda: _SYNC_MEMORY_UPDATER_EXECUTOR.shutdown(wait=False))


# Data-access + fact-CRUD functions (_save_memory_to_file / get_memory_data /
# reload_memory_data / import_memory_data / clear_memory_data / create_memory_fact /
# delete_memory_fact / update_memory_fact) moved into MemoryUpdater as instance
# methods (use self._storage). See the class below.
def _validate_confidence(confidence: float) -> float:
    """Validate persisted fact confidence so stored JSON stays standards-compliant."""
    if not math.isfinite(confidence) or confidence < 0 or confidence > 1:
        raise ValueError("confidence")
    return confidence


def _coerce_source_confidence(fact: dict[str, Any]) -> float:
    """Return a stored fact's confidence as a finite float in [0, 1], defaulting to 0.5.

    dict.get(key, default) returns the stored value (including None) when the key
    exists, so a fact written with "confidence": null would propagate None into
    arithmetic and crash max(). This helper guards against null, bool, non-numeric,
    and non-finite values from corrupted or manually edited memory files.
    """
    raw = fact.get("confidence")
    if raw is None or isinstance(raw, bool):
        return 0.5
    try:
        val = float(raw)
    except (TypeError, ValueError):
        return 0.5
    return max(0.0, min(val, 1.0)) if math.isfinite(val) else 0.5


def _next_confirmation_count(fact: dict[str, Any]) -> int:
    """Increment a valid prior confirmation count, resetting malformed values."""
    prior_count = fact.get("confirmationCount", 0)
    if isinstance(prior_count, bool) or not isinstance(prior_count, int) or prior_count < 0:
        return 1
    return prior_count + 1


def _extract_text(content: Any) -> str:
    """Extract plain text from LLM response content (str or list of content blocks).

    Modern LLMs may return structured content as a list of blocks instead of a
    plain string, e.g. [{"type": "text", "text": "..."}]. Using str() on such
    content produces Python repr instead of the actual text, breaking JSON
    parsing downstream.

    String chunks are concatenated without separators to avoid corrupting
    chunked JSON/text payloads. Dict-based text blocks are treated as full text
    blocks and joined with newlines for readability.
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        pieces: list[str] = []
        pending_str_parts: list[str] = []

        def flush_pending_str_parts() -> None:
            if pending_str_parts:
                pieces.append("".join(pending_str_parts))
                pending_str_parts.clear()

        for block in content:
            if isinstance(block, str):
                pending_str_parts.append(block)
            elif isinstance(block, dict):
                flush_pending_str_parts()
                text_val = block.get("text")
                if isinstance(text_val, str):
                    pieces.append(text_val)

        flush_pending_str_parts()
        return "\n".join(pieces)
    return str(content)


_REQUIRED_MEMORY_UPDATE_TOP_LEVEL_KEYS = frozenset({"user", "history", "newFacts"})
_FACT_CLASSIFICATION_FIELDS = ("scope", "durability", "authority")


def _normalize_gate_label(value: Any) -> str | None:
    """Normalize a model-produced scope-gate label without validating policy."""
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    return normalized or None


def _fact_scope_gate_reason(fact: dict[str, Any]) -> str | None:
    """Return the deterministic rejection reason for a model-extracted fact."""
    if any(_normalize_gate_label(fact.get(field)) is None for field in _FACT_CLASSIFICATION_FIELDS):
        return "missing"
    if _normalize_gate_label(fact.get("scope")) != "user":
        return "scope"
    if _normalize_gate_label(fact.get("durability")) != "durable":
        return "durability"
    if _normalize_gate_label(fact.get("authority")) != "descriptive":
        return "authority"
    return None


def _summary_scope_gate_reason(section_data: dict[str, Any]) -> str | None:
    """Return the deterministic rejection reason for a summary update."""
    scope = _normalize_gate_label(section_data.get("scope"))
    authority = _normalize_gate_label(section_data.get("authority"))
    if scope is None or authority is None:
        return "missing"
    if scope != "user":
        return "scope"
    if authority != "descriptive":
        return "authority"
    return None


def _removal_scope_gate_reason(removal: dict[str, Any]) -> str | None:
    """Return the deterministic rejection reason for a contradiction removal."""
    scope = _normalize_gate_label(removal.get("scope"))
    reason = removal.get("reason")
    if scope is None or not isinstance(reason, str) or not reason.strip():
        return "missing"
    if scope != "user":
        return "scope"
    return None


def _log_dropped_confidence(raw: object) -> None:
    """Make a systematic out-of-range confidence visible without logging content."""
    logger.warning(
        "Dropping an extracted fact with out-of-range confidence %s; expected 0.0-1.0. A model emitting a percentage scale would lose every extracted fact.",
        repr(raw)[:80],
    )


def _log_defaulted_consolidation_confidence(raw: object) -> None:
    """Make a systematically out-of-range consolidation confidence visible."""
    logger.warning(
        "Defaulting a consolidation with out-of-range confidence %s to 0.9; expected 0.0-1.0. A model emitting a percentage scale would lose the confidence signal.",
        repr(raw)[:80],
    )


def _normalize_memory_update_fact(fact: Any) -> dict[str, Any] | None:
    """Normalize a single fact entry from a model-produced memory update."""
    if not isinstance(fact, dict):
        return None

    raw_content = fact.get("content")
    if not isinstance(raw_content, str):
        return None
    content = raw_content.strip()
    if not content:
        return None

    raw_category = fact.get("category")
    category = raw_category.strip() if isinstance(raw_category, str) and raw_category.strip() else "context"

    raw_confidence = fact.get("confidence", 0.5)
    if isinstance(raw_confidence, bool):
        return None
    if isinstance(raw_confidence, str):
        raw_confidence = raw_confidence.strip()
        if not raw_confidence:
            return None
        try:
            raw_confidence = float(raw_confidence)
        except (OverflowError, ValueError):
            return None
    elif isinstance(raw_confidence, int):
        # Range-check before float(): an unbounded JSON integer such as 10**400
        # raises OverflowError in float() and would fail the whole batch.
        if not 0 <= raw_confidence <= 1:
            _log_dropped_confidence(raw_confidence)
            return None
        raw_confidence = float(raw_confidence)
    elif isinstance(raw_confidence, float):
        pass
    else:
        return None

    if not math.isfinite(raw_confidence) or not 0.0 <= raw_confidence <= 1.0:
        # Out-of-range confidence (for example a model emitting 95 or 1.5) is
        # malformed like every other shape above: drop this item instead of
        # letting the storage layer reject the whole update. A rejected batch
        # never advances the extraction watermark, so the same paid call would
        # otherwise repeat on every turn. Values are dropped, never rescaled:
        # silently rewriting the scale would change the confidence-threshold
        # semantics, and the warning makes a percentage-scale model visible.
        _log_dropped_confidence(raw_confidence)
        return None

    normalized_fact = {
        "content": content,
        "category": category,
        "confidence": raw_confidence,
    }
    source_error = fact.get("sourceError")
    if isinstance(source_error, str):
        normalized_source_error = source_error.strip()
        if normalized_source_error:
            normalized_fact["sourceError"] = normalized_source_error

    # Fact lifetime (expected_valid_days): optional LLM-assigned review window.
    # Validated via the shared _read_expected_valid_days rule (reject bool, require
    # finite, coerce to int, keep only positive); cap applied in _apply_updates.
    evd = _read_expected_valid_days(fact)
    if evd is not None:
        normalized_fact["expected_valid_days"] = evd

    # Scope classification is extraction-only metadata. Preserve it through
    # structural normalization so _apply_updates can fail closed per item, but
    # never copy it into the persisted fact_entry.
    for field in _FACT_CLASSIFICATION_FIELDS:
        normalized_value = _normalize_gate_label(fact.get(field))
        if normalized_value is not None:
            normalized_fact[field] = normalized_value

    return normalized_fact


def _normalize_memory_update_data(update_data: dict[str, Any]) -> dict[str, Any]:
    """Coerce parsed memory update data into the shape consumed by _apply_updates."""
    user = update_data.get("user")
    history = update_data.get("history")
    new_facts = update_data.get("newFacts")
    facts_to_remove = update_data.get("factsToRemove")
    facts_to_reinforce = update_data.get("factsToReinforce")
    normalized_facts_to_reinforce: list[dict[str, str]] = []
    if isinstance(facts_to_reinforce, list):
        for entry in facts_to_reinforce:
            if not isinstance(entry, dict):
                continue
            raw_id = entry.get("id")
            scope = _normalize_gate_label(entry.get("scope"))
            reason = entry.get("reason")
            if not isinstance(raw_id, str) or not raw_id.strip():
                continue
            normalized_entry = {"id": raw_id.strip()}
            if scope is not None:
                normalized_entry["scope"] = scope
            if isinstance(reason, str) and reason.strip():
                normalized_entry["reason"] = reason.strip()
            normalized_facts_to_reinforce.append(normalized_entry)
    normalized_facts_to_remove: list[dict[str, Any]] = []
    if isinstance(facts_to_remove, list):
        for entry in facts_to_remove:
            # Preserve the legacy string form as an unclassified removal. The
            # apply-layer gate will reject it as missing instead of continuing
            # to allow an unscoped destructive mutation.
            if isinstance(entry, str):
                fact_id = entry.strip()
                if fact_id:
                    normalized_facts_to_remove.append({"id": fact_id})
                continue
            if not isinstance(entry, dict):
                continue
            raw_id = entry.get("id")
            if not isinstance(raw_id, str) or not raw_id.strip():
                continue
            normalized_removal: dict[str, Any] = {"id": raw_id.strip()}
            scope = _normalize_gate_label(entry.get("scope"))
            if scope is not None:
                normalized_removal["scope"] = scope
            reason = entry.get("reason")
            if isinstance(reason, str) and reason.strip():
                normalized_removal["reason"] = reason.strip()
            if "replacementFactIndex" in entry:
                # Preserve invalid values too: the apply layer must reject an
                # invalid dependency rather than silently treating it as a pure
                # removal and deleting the old fact.
                normalized_removal["replacementFactIndex"] = entry.get("replacementFactIndex")
            normalized_facts_to_remove.append(normalized_removal)
    normalized_new_facts = []
    dropped_new_fact = not isinstance(new_facts, list)
    if isinstance(new_facts, list):
        for fact in new_facts:
            normalized_fact = _normalize_memory_update_fact(fact)
            if normalized_fact is not None:
                normalized_new_facts.append(normalized_fact)
            else:
                dropped_new_fact = True

    if normalized_facts_to_remove and dropped_new_fact:
        raise json.JSONDecodeError(
            "Unsafe partial memory update: factsToRemove with malformed newFacts",
            json.dumps(update_data, ensure_ascii=False),
            0,
        )

    # ── Normalize staleness review removals ──
    stale_removals_raw = update_data.get("staleFactsToRemove")
    normalized_stale_removals: list[dict[str, str]] = []
    if isinstance(stale_removals_raw, list):
        for entry in stale_removals_raw:
            if not isinstance(entry, dict):
                continue
            fact_id = entry.get("id")
            if not isinstance(fact_id, str) or not fact_id:
                continue
            reason = entry.get("reason", "")
            normalized_stale_removals.append(
                {
                    "id": fact_id,
                    "reason": reason if isinstance(reason, str) else "",
                }
            )

    # ── Normalize staleness review lifetime extensions ──
    stale_extensions_raw = update_data.get("staleFactsToExtend")
    normalized_stale_extensions: list[dict[str, Any]] = []
    if isinstance(stale_extensions_raw, list):
        for entry in stale_extensions_raw:
            if not isinstance(entry, dict):
                continue
            fact_id = entry.get("id")
            if not isinstance(fact_id, str) or not fact_id:
                continue
            # extend_by_days: accept int/float (reject bool), coerce to int, keep > 0.
            # A fractional value in (0, 1) coerces to 0 and is dropped here so the
            # apply path never silently writes a zero-delta extension.
            raw_extend = entry.get("extend_by_days")
            if isinstance(raw_extend, (int, float)) and not isinstance(raw_extend, bool):
                # int() raises on a non-finite float (a JSON number such as 1e400 parses
                # to inf), which would fail the whole batch; drop it like any other
                # unusable value. An int is kept as-is, including values beyond float range.
                extend_by = int(raw_extend) if isinstance(raw_extend, int) or math.isfinite(raw_extend) else 0
                if extend_by > 0:
                    reason = entry.get("reason", "")
                    normalized_stale_extensions.append(
                        {
                            "id": fact_id,
                            "extend_by_days": extend_by,
                            "reason": reason if isinstance(reason, str) else "",
                        }
                    )

    # ── Normalize consolidation decisions ──
    consolidation_raw = update_data.get("factsToConsolidate")
    normalized_consolidation: list[dict[str, Any]] = []
    if isinstance(consolidation_raw, list):
        for entry in consolidation_raw:
            if not isinstance(entry, dict):
                continue
            source_ids = entry.get("sourceIds")
            if not isinstance(source_ids, list) or not source_ids:
                continue
            # dict.fromkeys preserves order while deduplicating so ["f1","f1"]
            # collapses to ["f1"] and is correctly rejected as a single-source merge.
            clean_ids = list(dict.fromkeys(sid for sid in source_ids if isinstance(sid, str) and sid))
            if len(clean_ids) < 2:
                continue
            consolidated = entry.get("consolidated")
            if not isinstance(consolidated, dict):
                continue
            content = consolidated.get("content")
            if not isinstance(content, str) or not content.strip():
                continue
            # Normalize confidence: reject booleans (bool subclasses int, so the
            # isinstance check alone would silently accept True/False), coerce to float,
            # and reject non-finite values - matching _normalize_memory_update_fact.
            _raw_conf = consolidated.get("confidence", 0.9)
            if isinstance(_raw_conf, bool) or not isinstance(_raw_conf, (int, float)):
                _norm_conf = 0.9
            else:
                # float() raises on an unbounded JSON integer such as 10**400, which
                # would fail the whole batch; fall back like any other invalid value.
                try:
                    _f = float(_raw_conf)
                except OverflowError:
                    _f = math.inf
                if not math.isfinite(_f):
                    _log_defaulted_consolidation_confidence(_raw_conf)
                    _f = 0.9
                _norm_conf = _f
            _raw_cat = consolidated.get("category")
            _norm_cat = _raw_cat.strip() if isinstance(_raw_cat, str) and _raw_cat.strip() else "context"
            normalized_consolidation.append(
                {
                    "sourceIds": clean_ids,
                    "consolidated": {
                        "content": content.strip(),
                        "category": _norm_cat,
                        "confidence": _norm_conf,
                        **{field: normalized for field in _FACT_CLASSIFICATION_FIELDS if (normalized := _normalize_gate_label(consolidated.get(field))) is not None},
                    },
                }
            )

    return {
        "user": user if isinstance(user, dict) else {},
        "history": history if isinstance(history, dict) else {},
        "newFacts": normalized_new_facts,
        "factsToReinforce": normalized_facts_to_reinforce,
        "factsToRemove": normalized_facts_to_remove,
        "staleFactsToRemove": normalized_stale_removals,
        "staleFactsToExtend": normalized_stale_extensions,
        "factsToConsolidate": normalized_consolidation,
    }


def _parse_memory_update_response(response_content: Any) -> dict[str, Any]:
    """Parse the first valid memory-update JSON object from an LLM response.

    Some providers may wrap JSON in thinking traces, prose, or markdown fences
    even when prompted to return JSON only. This parser accepts safely
    extractable JSON objects but does not repair truncated or malformed JSON.
    """
    response_text = _extract_text(response_content).strip()
    decoder = json.JSONDecoder()

    for match in re.finditer(r"\{", response_text):
        try:
            parsed, _end = decoder.raw_decode(response_text[match.start() :])
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict) and _REQUIRED_MEMORY_UPDATE_TOP_LEVEL_KEYS.issubset(parsed):
            return _normalize_memory_update_data(parsed)

    raise json.JSONDecodeError("No valid memory update JSON object found", response_text, 0)


# Matches sentences that describe a file-upload *event* rather than general
# file-related work.  Deliberately narrow to avoid removing legitimate facts
# such as "User works with CSV files" or "prefers PDF export".
_UPLOAD_SENTENCE_RE = re.compile(
    r"[^.!?]*\b(?:"
    r"upload(?:ed|ing)?(?:\s+\w+){0,3}\s+(?:file|files?|document|documents?|attachment|attachments?)"
    r"|file\s+upload"
    r"|/mnt/user-data/uploads/"
    r"|<current_uploads>"
    r")[^.!?]*[.!?]?\s*",
    re.IGNORECASE,
)


def _strip_upload_mentions_from_memory(memory_data: dict[str, Any]) -> dict[str, Any]:
    """Remove sentences about file uploads from all memory summaries and facts.

    Uploaded files are session-scoped; persisting upload events in long-term
    memory causes the agent to search for non-existent files in future sessions.
    """
    # Scrub summaries in user/history sections
    for section in ("user", "history"):
        section_data = memory_data.get(section, {})
        for _key, val in section_data.items():
            if isinstance(val, dict) and "summary" in val:
                cleaned = _UPLOAD_SENTENCE_RE.sub("", val["summary"]).strip()
                cleaned = re.sub(r"  +", " ", cleaned)
                val["summary"] = cleaned

    # Also remove any facts that describe upload events
    facts = memory_data.get("facts", [])
    if facts:
        memory_data["facts"] = [f for f in facts if not _UPLOAD_SENTENCE_RE.search(f.get("content", ""))]

    return memory_data


def _fact_content_key(content: Any) -> str | None:
    if not isinstance(content, str):
        return None
    stripped = content.strip()
    if not stripped:
        return None
    return stripped.casefold()


_FACT_CJK_RANGE = "\u3400-\u4dbf\u4e00-\u9fff\U00020000-\U0002fa1f"
_FACT_TOKEN_RE = re.compile(rf"[a-zA-Z0-9_]+|[{_FACT_CJK_RANGE}]+(?:\s+[{_FACT_CJK_RANGE}]+)*")
_FACT_SIMILARITY_TOKEN_BUDGET = 128


def _fact_content_tokens(content: str) -> list[str]:
    """Deterministic, network-free tokenization for fact similarity.

    Latin words and CJK bigrams coexist in mixed-script text. Whitespace
    between CJK runs is ignored, retaining adjacent-character order even
    for spaced Chinese text, without joining across Latin words/punctuation.
    """
    lowered = content.strip().lower()
    if not lowered:
        return []
    tokens: list[str] = []
    for match in _FACT_TOKEN_RE.finditer(lowered):
        run = match.group()
        if run[0].isascii():
            tokens.append(run)
        else:
            run = "".join(run.split())
            tokens.extend([run] if len(run) == 1 else (run[index : index + 2] for index in range(len(run) - 1)))
    return tokens or lowered.split()


def _fact_content_similarity(left: str, right: str) -> float:
    """Bounded token-Jaccard similarity over case-folded token sets."""
    left_set = set(_fact_content_tokens(left)[:_FACT_SIMILARITY_TOKEN_BUDGET])
    right_set = set(_fact_content_tokens(right)[:_FACT_SIMILARITY_TOKEN_BUDGET])
    if not left_set or not right_set:
        return 0.0
    return len(left_set & right_set) / len(left_set | right_set)


def _find_dedup_merge_target(
    content: str,
    category: str,
    facts: list[dict[str, Any]],
    *,
    threshold: float,
) -> dict[str, Any] | None:
    """Return the most similar same-category fact at/above the similarity
    threshold, or ``None`` (write-side near-duplicate gate, issue #5252).

    Deterministic and offline: bounded token-Jaccard similarity. Only
    candidate facts whose content is a non-empty string participate;
    category mismatch never merges.
    """
    best_target: dict[str, Any] | None = None
    best_similarity = 0.0
    for fact in facts:
        if not isinstance(fact, dict):
            continue
        candidate_content = fact.get("content")
        if not isinstance(candidate_content, str) or not candidate_content.strip():
            continue
        if fact.get("category", "context") != category:
            continue
        similarity = _fact_content_similarity(content, candidate_content)
        if similarity >= threshold and similarity > best_similarity:
            best_target = fact
            best_similarity = similarity
    return best_target


def _raise_if_duplicate_fact_content(memory_data: dict[str, Any], content_key: str | None) -> None:
    """Reject a candidate fact whose normalized content already exists.

    Callers must invoke this against the freshest snapshot available inside
    their read-check-write critical section (i.e. on every revision-conflict
    retry), so two concurrent creators of the same content cannot both pass
    the check and store duplicate facts."""
    if content_key is None:
        return
    for fact in memory_data.get("facts", []):
        if isinstance(fact, dict) and _fact_content_key(fact.get("content")) == content_key:
            raise ValueError("Duplicate fact")


# ── Staleness review helpers ──────────────────────────────────────────────


def _parse_fact_datetime(raw: str) -> datetime | None:
    """Parse an ISO-8601 datetime string from a fact timestamp field.

    Returns ``None`` on any parse failure so callers can safely skip malformed facts.
    """
    if not raw:
        return None
    try:
        result = datetime.fromisoformat(raw)
        # Naive datetimes (no tzinfo) would cause TypeError when compared
        # with the timezone-aware cutoff.  Assume UTC for safety.
        if result.tzinfo is None:
            result = result.replace(tzinfo=UTC)
        return result
    except (ValueError, TypeError):
        return None


def _read_expected_valid_days(fact: dict[str, Any]) -> int | None:
    """Return a fact's ``expected_valid_days`` as a positive int, or ``None``.

    Accepts int/float (rejects ``bool``, which subclasses ``int``) and coerces
    to int *before* the positivity check, mirroring the original
    ``_normalize_memory_update_fact`` rule.  Coercing first matters for values
    in (0, 1): ``0.5`` passes a raw ``> 0`` check but truncates to ``0``, which
    would otherwise be returned as a (non-positive) lifetime instead of
    ``None``.  Non-finite floats (``NaN``, ``+/-inf``) are rejected, and huge
    ints are returned as-is rather than routed through ``float()`` (which
    raises ``OverflowError`` for ``10**400``): Python's JSON decoder parses an
    integer literal with no decimal point as an arbitrary-precision ``int``,
    so a hand-edited ``memory.json`` can carry one.  An int that is too large
    to participate in ``datetime`` arithmetic is bounded by the caller via
    :func:`_safe_add_days` - the helper's job is type/positivity validation,
    not datetime-range validation, because the safe bound depends on the
    ``datetime`` it is added to, not on the value alone.  Returning ``None``
    lets callers fall back to the global age or omit the field rather than
    silently writing a zero/negative/non-finite lifetime.
    """
    raw = fact.get("expected_valid_days")
    if isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        evd = raw  # arbitrary-precision int; never routed through float()
    elif isinstance(raw, float) and math.isfinite(raw):
        evd = int(raw)  # coerce before the positivity guard
    else:
        return None
    return evd if evd > 0 else None


def _safe_add_days(dt: datetime, days: int) -> datetime | None:
    """Return ``dt + timedelta(days=days)``, or ``None`` if it overflows.

    A huge persisted ``expected_valid_days`` (e.g. ``10**12``) can exceed
    ``timedelta.max.days`` or push the result past ``datetime.max`` / below
    ``datetime.min``.  Both raise ``OverflowError``.  The staleness and
    consolidation paths add an evd to a ``datetime`` to compute a review
    deadline; returning ``None`` lets the caller fall back to the configured
    global lifetime instead of aborting the whole update cycle.
    """
    try:
        return dt + timedelta(days=days)
    except (OverflowError, ValueError):
        return None


def _effective_fact_staleness_age(fact: dict[str, Any], config: Any) -> int:
    """Return the effective staleness review age in days for *fact*.

    Returns the stored ``expected_valid_days`` value directly when present and
    valid.  The ``staleness_max_lifetime_multiplier`` cap is applied once at
    *write time* (when a fact is first created) so the review window is bounded
    from the start.  Re-applying it here would prevent lifetime-extension
    operations from ever moving the review window beyond that initial cap,
    defeating the purpose of ``staleFactsToExtend``.  Falls back to the global
    ``staleness_age_days`` for facts that pre-date this feature or where the
    LLM did not provide an estimate.
    """
    evd = _read_expected_valid_days(fact)
    return evd if evd is not None else config.staleness_age_days


def _select_stale_candidates(
    current_memory: dict[str, Any],
    config: Any,
) -> list[dict[str, Any]]:
    """Return facts that have exceeded their individual review window.

    Each fact's effective review age is determined by
    ``_effective_fact_staleness_age``: facts with an LLM-assigned
    ``expected_valid_days`` use that value directly; facts without it fall back
    to the global ``staleness_age_days``. A valid ``lastConfirmedAt`` resets the
    review clock because it is explicit evidence that the fact is still true;
    otherwise ``createdAt`` remains the reference. Protected categories
    (default: ``correction``) are excluded because they represent explicit user
    feedback that should not be auto-pruned by age.
    """
    now = datetime.now(UTC)
    protected = frozenset(config.staleness_protected_categories)
    candidates: list[dict[str, Any]] = []
    for fact in current_memory.get("facts", []):
        if not isinstance(fact, dict):
            continue
        category = fact.get("category", "")
        if isinstance(category, str) and category in protected:
            continue
        review_reference = _parse_fact_datetime(fact.get("lastConfirmedAt", "")) or _parse_fact_datetime(fact.get("createdAt", ""))
        if review_reference is None:
            continue
        effective_age = _effective_fact_staleness_age(fact, config)
        # now - timedelta(days=effective_age) can overflow datetime.min when
        # effective_age is a huge persisted value; a window that large means the
        # fact cannot yet be stale, so skip it rather than aborting the cycle.
        cutoff = _safe_add_days(now, -effective_age)
        if cutoff is not None and review_reference < cutoff:
            candidates.append(fact)
    return candidates


def _build_staleness_section(
    stale_candidates: list[dict[str, Any]],
    config: Any,
    *,
    prompts_dir: str | None = None,
    agent_name: str | None = None,
) -> str:
    """Format the staleness review prompt section from candidate facts.

    Each fact line includes a ``valid:Nd`` annotation - the effective review
    window for that fact - so the LLM can calibrate its conservatism: a fact
    reviewed after 30 days was considered volatile at creation; one reviewed
    after 365 days was considered stable.
    """
    if not stale_candidates:
        return ""
    lines: list[str] = []
    for fact in stale_candidates:
        fid = fact.get("id", "?")
        cat = html.escape(str(fact.get("category", "context")).strip() or "context", quote=False)
        conf = _coerce_source_confidence(fact)
        review_reference = _parse_fact_datetime(fact.get("lastConfirmedAt", "")) or _parse_fact_datetime(fact.get("createdAt", ""))
        reviewed_short = review_reference.date().isoformat() if review_reference is not None else ""
        # quote=False: content is in element-text position (inside <stale_facts>
        # tags, never an attribute value), so only <, >, & can break structure -
        # leave ' and " untouched. Mirrors the convention in prompt.py #4028.
        content = html.escape(str(fact.get("content", "")), quote=False)
        effective_age = _effective_fact_staleness_age(fact, config)
        lines.append(f'- [{fid} | {cat} | {conf:.2f} | {reviewed_short} | valid:{effective_age}d] "{content}"')
    return load_prompt("staleness_review", prompts_dir=prompts_dir, agent_name=agent_name).format(stale_facts="\n".join(lines))


# ── Consolidation helpers ───────────────────────────────────────────────


def _select_consolidation_candidates(
    current_memory: dict[str, Any],
    config: Any,
) -> dict[str, list[dict[str, Any]]]:
    """Return fact categories that exceed the fragmentation threshold.

    Groups facts by category; only categories with at least
    ``consolidation_min_facts`` entries are returned.  Categories in
    ``staleness_protected_categories`` are exempt, mirroring the staleness
    contract so explicit user feedback is never surfaced for merging.
    """
    facts = current_memory.get("facts", [])
    if not facts:
        return {}
    by_category: dict[str, list[dict[str, Any]]] = {}
    for fact in facts:
        if not isinstance(fact, dict):
            continue
        cat = fact.get("category", "context")
        if isinstance(cat, str) and cat.strip():
            by_category.setdefault(cat.strip(), []).append(fact)
    threshold = config.consolidation_min_facts
    protected = set(config.staleness_protected_categories)
    return {cat: group for cat, group in by_category.items() if len(group) >= threshold and cat not in protected}


def _build_consolidation_section(
    candidates: dict[str, list[dict[str, Any]]],
    max_groups: int = 3,
    max_sources: int = 8,
    *,
    prompts_dir: str | None = None,
    agent_name: str | None = None,
) -> str:
    """Format consolidation candidate groups into the prompt section.

    Surfaces at most ``max_groups`` categories (largest fragmented groups first)
    and at most ``max_sources`` facts per group, matching the caps enforced at
    apply time so the LLM is never shown groups it cannot act on.
    """
    if not candidates:
        return ""
    # Prioritise the most fragmented categories; alphabetical tiebreak for stability.
    sorted_candidates = sorted(candidates.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    parts: list[str] = []
    for cat, group in sorted_candidates[:max_groups]:
        lines: list[str] = []
        for fact in group[:max_sources]:
            fid = fact.get("id", "?")
            conf = _coerce_source_confidence(fact)
            content = html.escape(str(fact.get("content", "")))
            lines.append(f'- [{fid} | {conf:.2f}] "{content}"')
        shown = min(len(group), max_sources)
        parts.append(f'<consolidation_candidates category="{html.escape(cat)}" count="{shown}">\n' + "\n".join(lines) + "\n</consolidation_candidates>")
    return load_prompt("consolidation", prompts_dir=prompts_dir, agent_name=agent_name).format(consolidation_groups="\n\n".join(parts), max_groups=max_groups)


def _escape_memory_for_prompt(memory: Any) -> Any:
    """Return a copy of ``memory`` with every string leaf HTML-escaped.

    The memory_update prompt embeds the full memory state as a ``json.dumps``
    blob inside a ``<current_memory>...</current_memory>`` block. ``json.dumps``
    escapes ``"`` and ``\\`` but leaves ``<``, ``>`` and ``&`` intact, so a
    user-influenced field - e.g. a fact ``content`` of
    ``</current_memory><evil>...`` - would otherwise reach the model verbatim
    and break out of the block (prompt injection, #4044).

    Escaping each string *value* before serialization (rather than the
    serialized blob) cannot corrupt the JSON structure, because ``json.dumps``
    re-quotes the already-safe values. Escaping every leaf - not just known
    fields - guarantees no current or future user-influenced field can carry a
    raw ``<``/``>``/``&``; controlled fields such as ids and timestamps contain
    none of those characters, so escaping them is a harmless no-op. This mirrors
    the ``html.escape`` treatment already applied to the staleness and
    consolidation sections (#4028).
    """
    if isinstance(memory, str):
        return html.escape(memory)
    if isinstance(memory, dict):
        return {key: _escape_memory_for_prompt(value) for key, value in memory.items()}
    if isinstance(memory, list):
        return [_escape_memory_for_prompt(item) for item in memory]
    return memory


def _memory_with_manual_markers(memory: Any) -> Any:
    """Return a deep copy of ``memory`` with ``[MANUAL]`` prefixed onto the
    content of manually-authored facts (``source.type == "manual"``).

    The marker is a prompt-only signal that tells the extraction LLM a fact is a
    high-trust user edit; the persisted memory is untouched (this copy is only
    fed to the prompt). Idempotent: a fact already carrying the prefix is not
    double-marked.
    """
    display = copy.deepcopy(memory)
    if not isinstance(display, dict):
        return display
    for fact in display.get("facts", []):
        if not isinstance(fact, dict):
            continue
        src = fact.get("source")
        src_type = src.get("type") if isinstance(src, dict) else None
        if src_type == "manual":
            content = fact.get("content")
            if isinstance(content, str) and not content.startswith("[MANUAL]"):
                fact["content"] = "[MANUAL] " + content
    return display


def _message_identity(msg: Any) -> tuple[str, ...] | None:
    """Return a hashable identity for ``msg`` for watermark tracking.

    The watermark is content/identity based rather than index based so it stays
    valid when summarization removes the conversation front (an index watermark
    would point at the wrong message after a front removal, silently skipping
    un-extracted turns). Prefers the langgraph message ``id`` (unique, robust to
    duplicate content); falls back to ``(type, sha256(content))`` when no id is
    set (e.g. plain ``HumanMessage(content=...)`` in tests) -- a digest because
    the identity is also persisted to the watermark sidecar, which must not hold
    conversation text. Returns ``None`` for a message with neither id nor
    extractable text -- the caller then feeds the full list, which is safe
    over-extraction and never loss.
    """
    mid = getattr(msg, "id", None)
    if isinstance(mid, str) and mid:
        return ("id", mid)
    text = extract_message_text(msg)
    if not text:
        return None
    msg_type = getattr(msg, "type", "") or ""
    return ("content", msg_type, hashlib.sha256(text.encode("utf-8")).hexdigest())


# DeerMem is portable; the host test pins this map to its UI allowlist.
_MEMORY_UI_LANGUAGES = {"en-US": "English", "zh-CN": "Simplified Chinese"}


def _memory_language_preference(messages: list[Any]) -> str:
    for message in reversed(messages):
        locale = (getattr(message, "additional_kwargs", {}) or {}).get("deerflow_ui_locale")
        if isinstance(locale, str) and locale in _MEMORY_UI_LANGUAGES:
            return f"Preferred memory language: {_MEMORY_UI_LANGUAGES[locale]} ({locale})"
    return ""


class MemoryUpdater:
    """Updates memory using LLM based on conversation context."""

    def __init__(self, config: DeerMemConfig, storage: MemoryStorage, llm: Any = None, *, prompts_dir: str | None = None, callbacks: Any = None):
        """Initialize the memory updater with injected config + storage + llm (DI).

        Args:
            config: DeerMem private configuration.
            storage: Memory storage instance (owned by DeerMem, injected here).
            llm: The chat model for memory extraction (owned by DeerMem, injected
                here). None when no LLM is configured; an update raises in that case.
            prompts_dir: Optional custom prompt-template directory forwarded to
                ``load_prompt`` / ``load_prompt_messages``. None = bundled defaults.
            callbacks: Optional ``MemoryCallbacks`` (owned by DeerMem, injected
                here). ``on_memory_llm_call`` is invoked before the LLM call to
                merge trace metadata into ``invoke_config``; None = no tracing.
        """
        self._config = config
        self._storage = storage
        self._llm = llm
        self._prompts_dir = prompts_dir
        self._callbacks = callbacks
        # Watermark: last-extracted message identity per (thread_id, user_id,
        # agent_name). This process caches it in a bounded LRU
        # (config.watermark_max_keys) so a long-lived gateway handling many
        # threads cannot grow it without limit, and writes it through to the
        # storage's per-agent sidecar so a restart or a peer replica sharing the
        # storage root continues from it. A key missing from both re-extracts
        # one batch on that thread's next turn.
        self._watermarks: OrderedDict[tuple[str | None, str | None, str | None], tuple[str, ...] | None] = OrderedDict()

    # ── Data access + fact CRUD (formerly module-level functions; use self._storage) ──

    def _save_memory_to_file(
        self,
        memory_data: dict[str, Any],
        agent_name: str | None = None,
        *,
        user_id: str | None = None,
        expected_revision: int | None = None,
    ) -> bool:
        """Persist memory data via the injected storage."""
        kwargs: dict[str, Any] = {"user_id": user_id}
        if expected_revision is not None:
            kwargs["expected_revision"] = expected_revision
        return self._storage.save(memory_data, agent_name, **kwargs)

    def get_memory_data(self, agent_name: str | None = None, *, user_id: str | None = None) -> dict[str, Any]:
        """Get the current memory data via the injected storage."""
        return self._storage.load(agent_name, user_id=user_id)

    def reload_memory_data(self, agent_name: str | None = None, *, user_id: str | None = None) -> dict[str, Any]:
        """Reload memory data via the injected storage."""
        return self._storage.reload(agent_name, user_id=user_id)

    def _select_for_capacity(
        self,
        facts: list[dict[str, Any]],
        *,
        agent_name: str | None,
        user_id: str | None,
    ) -> tuple[list[dict[str, Any]], FactEvictionDecision | None, FactEvictionDecision | None]:
        """Apply the configured policy and optionally compute hybrid shadow."""
        if len(facts) <= self._config.max_facts:
            return facts, None, None
        uses_hybrid_scoring = self._config.fact_eviction_policy == EVICTION_POLICY_HYBRID_V1 or self._config.fact_eviction_shadow_enabled
        usage = (
            self._storage.get_fact_usage(
                agent_name=agent_name,
                user_id=user_id,
            )
            if uses_hybrid_scoring and agent_name is not None
            else {}
        )
        common = {
            "max_facts": self._config.max_facts,
            "usage": usage,
            "confidence_weight": self._config.eviction_confidence_weight,
            "confirmation_weight": self._config.eviction_confirmation_weight,
            "access_weight": self._config.eviction_access_weight,
            "confirmation_half_life_days": self._config.eviction_confirmation_half_life_days,
            "access_half_life_days": self._config.eviction_access_half_life_days,
            "correction_reserved_fraction": self._config.eviction_correction_reserved_fraction,
            "correction_reserved_max": self._config.eviction_correction_reserved_max,
        }
        decision = select_facts_for_capacity(
            facts,
            policy=self._config.fact_eviction_policy,
            **common,
        )
        shadow_decision = None
        if self._config.fact_eviction_shadow_enabled and self._config.fact_eviction_policy == EVICTION_POLICY_CONFIDENCE:
            shadow_decision = select_facts_for_capacity(
                facts,
                policy=EVICTION_POLICY_HYBRID_V1,
                **common,
            )
        return decision.kept, decision, shadow_decision

    def _record_capacity_decision(
        self,
        decision: FactEvictionDecision | None,
        shadow_decision: FactEvictionDecision | None,
        *,
        agent_name: str | None,
        user_id: str | None,
    ) -> None:
        """Write best-effort audit only after canonical persistence succeeds."""
        if decision is None or agent_name is None:
            return
        try:
            self._storage.record_capacity_eviction(
                decision,
                max_facts=self._config.max_facts,
                agent_name=agent_name,
                user_id=user_id,
                shadow_decision=shadow_decision,
            )
        except Exception:
            logger.warning("Failed to record capacity-eviction audit", exc_info=True)

    def import_memory_data(
        self,
        memory_data: dict[str, Any],
        agent_name: str | None = None,
        *,
        user_id: str | None = None,
        replace_shared_summaries: bool = True,
    ) -> dict[str, Any]:
        """Persist imported memory data via the injected storage."""
        if not isinstance(memory_data, dict):
            raise ValueError("memory_data")
        # Replacement imports must not turn malformed facts into deletions.
        # Validate before lenient compatibility normalization or any storage read.
        raw_facts = memory_data.get("facts")
        if not isinstance(raw_facts, list) or any(not isinstance(fact, dict) or not isinstance(fact.get("content"), str) or not fact["content"].strip() for fact in raw_facts):
            raise ValueError("memory_data.facts must be a list of facts with non-empty content")
        memory_data = normalize_memory_data(memory_data)
        if agent_name is not None and getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes:
            current = self.get_memory_data(agent_name, user_id=user_id)
            incoming_facts = copy.deepcopy(memory_data.get("facts", []))
            if not isinstance(incoming_facts, list) or any(not isinstance(fact, dict) for fact in incoming_facts):
                raise ValueError("memory_data.facts")
            for fact in incoming_facts:
                fact["id"] = str(fact.get("id") or f"fact_{uuid.uuid4().hex}")
                fact["confidence"] = _coerce_source_confidence(fact)
            incoming_facts, capacity_decision, shadow_decision = self._select_for_capacity(
                incoming_facts,
                agent_name=agent_name,
                user_id=user_id,
            )
            current_by_id = {str(fact.get("id")): fact for fact in current.get("facts", []) if isinstance(fact, dict)}
            incoming_ids = {str(fact.get("id")) for fact in incoming_facts}
            change_set = {
                "upserts": incoming_facts,
                "upsertRevisions": {str(fact.get("id")): (int(current_by_id[str(fact.get("id"))].get("revision") or 1) if str(fact.get("id")) in current_by_id else None) for fact in incoming_facts},
                "deletes": [fact_id for fact_id in current_by_id if fact_id not in incoming_ids],
                "deleteRevisions": {fact_id: int(fact.get("revision") or 1) for fact_id, fact in current_by_id.items() if fact_id not in incoming_ids},
            }
            if replace_shared_summaries:
                change_set["summaries"] = {
                    "user": copy.deepcopy(memory_data.get("user", {})),
                    "history": copy.deepcopy(memory_data.get("history", {})),
                }
            self._storage.apply_changes(
                change_set,
                agent_name=agent_name,
                user_id=user_id,
                expected_manifest_revision=int(current.get("revision") or 0),
            )
            self._record_capacity_decision(
                capacity_decision,
                shadow_decision,
                agent_name=agent_name,
                user_id=user_id,
            )
            return self._storage.load(agent_name, user_id=user_id)
        if agent_name is None:
            memory_data["facts"] = []
            capacity_decision = None
            shadow_decision = None
        else:
            raw_facts = memory_data.get("facts", [])
            if not isinstance(raw_facts, list) or any(not isinstance(fact, dict) for fact in raw_facts):
                raise ValueError("memory_data.facts")
            normalized_facts = []
            for raw_fact in raw_facts:
                fact = copy.deepcopy(raw_fact)
                fact["id"] = str(fact.get("id") or f"fact_{uuid.uuid4().hex}")
                fact["confidence"] = _coerce_source_confidence(fact)
                normalized_facts.append(fact)
            memory_data["facts"], capacity_decision, shadow_decision = self._select_for_capacity(
                normalized_facts,
                agent_name=agent_name,
                user_id=user_id,
            )
        if not self._storage.save(memory_data, agent_name, user_id=user_id):
            raise OSError("Failed to save imported memory data")
        self._record_capacity_decision(
            capacity_decision,
            shadow_decision,
            agent_name=agent_name,
            user_id=user_id,
        )
        return self._storage.load(agent_name, user_id=user_id)

    def clear_memory_data(self, agent_name: str | None = None, *, user_id: str | None = None) -> dict[str, Any]:
        """Clear one selected agent's facts without resetting shared summaries."""
        if agent_name is not None and getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes:
            for attempt in range(3):
                current = self.get_memory_data(agent_name, user_id=user_id) if attempt == 0 else self.reload_memory_data(agent_name, user_id=user_id)
                facts = [fact for fact in current.get("facts", []) if isinstance(fact, dict)]
                try:
                    self._storage.apply_changes(
                        {
                            "deletes": [str(fact.get("id")) for fact in facts],
                            "deleteRevisions": {str(fact.get("id")): int(fact.get("revision") or 1) for fact in facts},
                        },
                        agent_name=agent_name,
                        user_id=user_id,
                        expected_manifest_revision=int(current.get("revision") or 0),
                    )
                    self._storage.clear_fact_metadata(
                        agent_name=agent_name,
                        user_id=user_id,
                    )
                    return self.reload_memory_data(agent_name, user_id=user_id)
                except MemoryManifestRevisionConflict:
                    if attempt == 2:
                        raise
                    logger.info("Retrying scoped memory clear from a fresh snapshot after a revision conflict")
            raise AssertionError("bounded scoped-clear retry did not return or raise")
        current = self.get_memory_data(agent_name, user_id=user_id)
        cleared_memory = copy.deepcopy(current)
        cleared_memory["facts"] = []
        if not self._save_memory_to_file(cleared_memory, agent_name, user_id=user_id, expected_revision=int(current.get("revision") or 0)):
            raise OSError("Failed to save cleared memory data")
        if agent_name is not None:
            self._storage.clear_fact_metadata(
                agent_name=agent_name,
                user_id=user_id,
            )
        return cleared_memory

    def clear_all_memory_data(self, *, user_id: str | None = None) -> dict[str, Any]:
        """Clear global summaries and every agent fact bucket for one user."""
        if getattr(type(self._storage), "clear_all", None) is not MemoryStorage.clear_all:
            return self._storage.clear_all(user_id=user_id)
        current = self.get_memory_data(user_id=user_id)
        cleared_memory = create_empty_memory()
        if not self._save_memory_to_file(
            cleared_memory,
            user_id=user_id,
            expected_revision=int(current.get("revision") or 0),
        ):
            raise OSError("Failed to save cleared memory data")
        return cleared_memory

    def create_memory_fact(self, content: str, category: str = "context", confidence: float = 0.5, agent_name: str | None = None, *, user_id: str | None = None) -> tuple[dict[str, Any], str | None]:
        """Create a new fact, persist it, and return ``(updated_memory, fact_id)``.

        The fact_id is returned directly so callers (e.g. the memory_add tool)
        don't have to re-derive it from the memory data by content matching --
        which would couple them to the backend's content normalization and could
        misreport a storage cap on backends that normalize differently.

        The new fact is then evaluated by the configured capacity policy. If
        the cap evicts the just-added fact, ``fact_id`` is ``None`` so callers report
        "not stored - cap reached" instead of a dangling id with a false
        "added" status. This restores both the max_facts cap and the post-trim
        existence check (upstream's ``create_memory_fact_with_created_fact``),
        which the vendored copy had dropped together to avoid the dangling id.

        Duplicate rejection is enforced here (not only by callers): the
        candidate's normalized content key is checked against the fresh
        memory snapshot inside the revision-conflict retry loop of both
        storage paths (apply_changes and legacy single-file save), so
        concurrent creators cannot both store the same content. Raises
        ``ValueError("Duplicate fact")`` on a normalized-content match.
        """
        if agent_name is None:
            raise ValueError("agent_name")
        normalized_content = content.strip()
        if not normalized_content:
            raise ValueError("content")
        normalized_category = category.strip() or "context"
        validated_confidence = _validate_confidence(confidence)
        candidate_key = _fact_content_key(normalized_content)
        now = utc_now_iso_z()
        fact_id = f"fact_{uuid.uuid4().hex[:8]}"
        candidate = {
            "id": fact_id,
            "content": normalized_content,
            "category": normalized_category,
            "confidence": validated_confidence,
            "createdAt": now,
            "source": "manual",
        }
        if getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes:
            for attempt in range(3):
                memory_data = self.get_memory_data(agent_name, user_id=user_id) if attempt == 0 else self.reload_memory_data(agent_name, user_id=user_id)
                # Duplicate rejection lives inside the conflict-retry loop so
                # it is re-evaluated against the fresh snapshot after every
                # revision conflict: two concurrent creators of the same
                # content cannot both store it (the loser reloads, sees the
                # winner's fact, and is rejected here).
                _raise_if_duplicate_fact_content(memory_data, candidate_key)
                updated_memory = dict(memory_data)
                updated_memory["facts"], capacity_decision, shadow_decision = self._select_for_capacity(
                    [*memory_data.get("facts", []), copy.deepcopy(candidate)],
                    agent_name=agent_name,
                    user_id=user_id,
                )
                kept_ids = {str(fact.get("id")) for fact in updated_memory["facts"]}
                deletions = [str(fact.get("id")) for fact in memory_data.get("facts", []) if str(fact.get("id")) not in kept_ids]
                try:
                    self._storage.apply_changes(
                        {
                            "upserts": [fact for fact in updated_memory["facts"] if fact.get("id") == fact_id],
                            "upsertRevisions": {fact_id: None},
                            "deletes": deletions,
                            "deleteRevisions": {str(fact.get("id")): int(fact.get("revision") or 1) for fact in memory_data.get("facts", []) if str(fact.get("id")) in deletions},
                        },
                        agent_name=agent_name,
                        user_id=user_id,
                        expected_manifest_revision=int(memory_data.get("revision") or 0),
                    )
                    self._record_capacity_decision(
                        capacity_decision,
                        shadow_decision,
                        agent_name=agent_name,
                        user_id=user_id,
                    )
                    fresh_memory = self.reload_memory_data(agent_name, user_id=user_id)
                    stored = any(fact.get("id") == fact_id for fact in fresh_memory.get("facts", []))
                    return fresh_memory, (fact_id if stored else None)
                except MemoryManifestRevisionConflict:
                    if attempt == 2:
                        raise
                    logger.info("Retrying capped fact creation from a fresh snapshot after a revision conflict")
            raise AssertionError("bounded create retry did not return or raise")
        # Legacy single-file path: same duplicate-rejection contract as the
        # apply_changes path above. A revision-conflicted save (False) reloads
        # the fresh snapshot and re-runs the duplicate check, so a concurrent
        # creator's commit is rejected with ValueError("Duplicate fact")
        # instead of surfacing as a generic save failure.
        for attempt in range(3):
            memory_data = self.get_memory_data(agent_name, user_id=user_id) if attempt == 0 else self.reload_memory_data(agent_name, user_id=user_id)
            _raise_if_duplicate_fact_content(memory_data, candidate_key)
            updated_memory = dict(memory_data)
            updated_memory["facts"], capacity_decision, shadow_decision = self._select_for_capacity(
                [*memory_data.get("facts", []), copy.deepcopy(candidate)],
                agent_name=agent_name,
                user_id=user_id,
            )
            if self._save_memory_to_file(updated_memory, agent_name, user_id=user_id, expected_revision=int(memory_data.get("revision") or 0)):
                self._record_capacity_decision(
                    capacity_decision,
                    shadow_decision,
                    agent_name=agent_name,
                    user_id=user_id,
                )
                # If the cap evicted the just-added (lower-confidence) fact,
                # signal via None so callers don't report a dangling id as
                # "added".
                stored = any(f.get("id") == fact_id for f in updated_memory["facts"])
                return updated_memory, (fact_id if stored else None)
            logger.info("Retrying capped fact creation from a fresh snapshot after a revision conflict")
        raise OSError("Failed to save memory data after creating fact")

    def delete_memory_fact(self, fact_id: str, agent_name: str | None = None, *, user_id: str | None = None) -> dict[str, Any]:
        """Delete a fact by its id and persist the updated memory data."""
        if agent_name is None:
            raise ValueError("agent_name")
        if getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes and hasattr(self._storage, "get_fact"):
            deleted = self._storage.get_fact(fact_id, agent_name=agent_name, user_id=user_id)
            if deleted is None:
                raise KeyError(fact_id)
            global_memory = self.get_memory_data(user_id=user_id)
            self._storage.apply_changes(
                {"deletes": [fact_id], "deleteRevisions": {fact_id: int(deleted.get("revision") or 1)}},
                agent_name=agent_name,
                user_id=user_id,
                expected_manifest_revision=int(global_memory.get("revision") or 0),
                allow_manifest_rebase=True,
            )
            return self.get_memory_data(agent_name, user_id=user_id)
        memory_data = self.get_memory_data(agent_name, user_id=user_id)
        facts = memory_data.get("facts", [])
        updated_facts = [fact for fact in facts if fact.get("id") != fact_id]
        if len(updated_facts) == len(facts):
            raise KeyError(fact_id)
        deleted = next(fact for fact in facts if fact.get("id") == fact_id)
        if getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes:
            self._storage.apply_changes(
                {"deletes": [fact_id], "deleteRevisions": {fact_id: int(deleted.get("revision") or 1)}},
                agent_name=agent_name,
                user_id=user_id,
                expected_manifest_revision=int(memory_data.get("revision") or 0),
                allow_manifest_rebase=True,
            )
            return self.get_memory_data(agent_name, user_id=user_id)
        updated_memory = dict(memory_data)
        updated_memory["facts"] = updated_facts
        if not self._save_memory_to_file(updated_memory, agent_name, user_id=user_id, expected_revision=int(memory_data.get("revision") or 0)):
            raise OSError(f"Failed to save memory data after deleting fact '{fact_id}'")
        return updated_memory

    def update_memory_fact(self, fact_id: str, content: str | None = None, category: str | None = None, confidence: float | None = None, agent_name: str | None = None, *, user_id: str | None = None) -> dict[str, Any]:
        """Update an existing fact and persist the updated memory data."""
        if agent_name is None:
            raise ValueError("agent_name")
        if getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes and hasattr(self._storage, "get_fact"):
            updated_fact = self._storage.get_fact(fact_id, agent_name=agent_name, user_id=user_id)
            if updated_fact is None:
                raise KeyError(fact_id)
            if content is not None:
                normalized_content = content.strip()
                if not normalized_content:
                    raise ValueError("content")
                updated_fact["content"] = normalized_content
            if category is not None:
                updated_fact["category"] = category.strip() or "context"
            if confidence is not None:
                updated_fact["confidence"] = _validate_confidence(confidence)
            global_memory = self.get_memory_data(user_id=user_id)
            self._storage.apply_changes(
                {"upserts": [updated_fact], "upsertRevisions": {fact_id: int(updated_fact.get("revision") or 1)}},
                agent_name=agent_name,
                user_id=user_id,
                expected_manifest_revision=int(global_memory.get("revision") or 0),
                allow_manifest_rebase=True,
            )
            return self.get_memory_data(agent_name, user_id=user_id)
        memory_data = self.get_memory_data(agent_name, user_id=user_id)
        updated_memory = dict(memory_data)
        updated_facts: list[dict[str, Any]] = []
        found = False
        for fact in memory_data.get("facts", []):
            if fact.get("id") == fact_id:
                found = True
                updated_fact = dict(fact)
                if content is not None:
                    normalized_content = content.strip()
                    if not normalized_content:
                        raise ValueError("content")
                    updated_fact["content"] = normalized_content
                if category is not None:
                    updated_fact["category"] = category.strip() or "context"
                if confidence is not None:
                    updated_fact["confidence"] = _validate_confidence(confidence)
                updated_facts.append(updated_fact)
            else:
                updated_facts.append(fact)
        if not found:
            raise KeyError(fact_id)
        if getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes:
            changed = next(fact for fact in updated_facts if fact.get("id") == fact_id)
            self._storage.apply_changes(
                {"upserts": [changed], "upsertRevisions": {fact_id: int(changed.get("revision") or 1)}},
                agent_name=agent_name,
                user_id=user_id,
                expected_manifest_revision=int(memory_data.get("revision") or 0),
                allow_manifest_rebase=True,
            )
            return self.get_memory_data(agent_name, user_id=user_id)
        updated_memory["facts"] = updated_facts
        if not self._save_memory_to_file(updated_memory, agent_name, user_id=user_id, expected_revision=int(memory_data.get("revision") or 0)):
            raise OSError(f"Failed to save memory data after updating fact '{fact_id}'")
        return updated_memory

    def _build_signal_hints(self, signals: frozenset[str]) -> str:
        """Build optional prompt hints for the detected signal classes.

        Each present signal contributes one instruction nudging the extraction
        LLM toward the right category and confidence. The variable is still
        rendered into the template's ``{correction_hint}`` slot (the name is
        historical -- it now carries the full signal-hint set, plus the manual
        fact note appended by :meth:`_prepare_update_prompt`).
        """
        hints: list[str] = []
        if "correction" in signals:
            hints.append(
                "IMPORTANT: Explicit correction signals were detected in this conversation. "
                "Record a correction with confidence >= 0.95 only when it describes a durable, user-level "
                "working preference that is safe to reuse across unrelated tasks. A correction to facts, files, "
                "directions, or constraints in the current task is thread- or project-scoped and must not be stored."
            )
        if "reinforcement" in signals:
            hints.append(
                "IMPORTANT: Positive reinforcement signals were detected in this conversation. "
                "Record the confirmed approach, style, or preference with high confidence only if it is a durable, "
                "user-level pattern. Approval of the current result or current task is thread-scoped and must not be stored."
            )
        if "preference" in signals:
            hints.append("IMPORTANT: A preference signal was detected. Record it with high confidence only when it is a durable, user-level preference; a one-off choice for the current task is thread-scoped and must not be stored.")
        if "identity" in signals:
            hints.append("IMPORTANT: An identity signal was detected. Record the user's stated role, profession, or background only when it is user-level and durable across tasks.")
        if "goal" in signals:
            hints.append("IMPORTANT: A goal signal was detected. Record only a durable, user-level goal that remains useful across unrelated tasks; the objective of the current task, sprint, PR, or thread must not be stored.")
        if "decision" in signals:
            hints.append("IMPORTANT: A decision signal was detected. Record only a durable, user-level decision or working pattern; a choice made for the current task, file, PR, or thread must not be stored.")
        return "\n".join(hints)

    def _prepare_update_prompt(
        self,
        messages: list[Any],
        agent_name: str | None,
        signals: frozenset[str],
        user_id: str | None = None,
        conversation_text: str | None = None,
    ) -> tuple[dict[str, Any], list[Any]] | None:
        """Load memory and build the update prompt for a conversation.

        ``conversation_text`` lets the caller hand over the formatted text it
        already produced for the memory judge, so the conversation is formatted
        once per batch instead of twice.
        """
        config = self._config
        if not messages:
            return None

        current_memory = self.get_memory_data(agent_name, user_id=user_id)
        if conversation_text is None:
            conversation_text = format_conversation_for_update(messages)
        if not conversation_text.strip():
            return None

        correction_hint = self._build_signal_hints(signals)

        # Manual-fact signal: tag high-trust user-authored facts with a [MANUAL]
        # prefix in the prompt's current_memory and instruct the model to preserve
        # them unless the new conversation is an explicit, unambiguous correction.
        display_memory = current_memory
        if self._has_manual_facts(current_memory):
            display_memory = _memory_with_manual_markers(current_memory)
            manual_hint = "NOTE: Facts marked [MANUAL] are high-trust user-authored edits. Update them only when the new conversation is an explicit, unambiguous correction; otherwise preserve them as-is."
            correction_hint = (correction_hint + "\n" + manual_hint).strip() if correction_hint else manual_hint

        # ── Build staleness review section ──
        staleness_section = ""
        if config.staleness_review_enabled:
            stale_candidates = _select_stale_candidates(current_memory, config)
            if len(stale_candidates) >= config.staleness_min_candidates:
                staleness_section = _build_staleness_section(stale_candidates, config, prompts_dir=self._prompts_dir, agent_name=agent_name)

        # ── Build consolidation section ──
        consolidation_section = ""
        if config.consolidation_enabled:
            consolidation_candidates = _select_consolidation_candidates(current_memory, config)
            if consolidation_candidates:
                consolidation_section = _build_consolidation_section(
                    consolidation_candidates,
                    max_groups=config.consolidation_max_groups_per_cycle,
                    max_sources=config.consolidation_max_sources,
                    prompts_dir=self._prompts_dir,
                    agent_name=agent_name,
                )

        variables = {
            "current_memory": json.dumps(_escape_memory_for_prompt(display_memory), indent=2, ensure_ascii=False),
            "conversation": conversation_text,
            "correction_hint": correction_hint,
            "staleness_review_section": staleness_section,
            "consolidation_section": consolidation_section,
        }
        prompt = load_prompt_messages("memory_update", variables, agent_name=agent_name, prompts_dir=self._prompts_dir)
        language_preference = _memory_language_preference(messages)
        if language_preference:
            # Per-run preference is data, not part of the cached system text.
            for index, message in enumerate(prompt):
                if message.type == "human":
                    prompt[index] = message.model_copy(update={"content": f"{language_preference}\n\n{message.content}"})
                    break
        if config.prompt_prepend or config.prompt_append:
            # Extend trusted instructions only, after formatting the original
            # template. Conversation/memory data stays in its human message.
            for index, message in enumerate(prompt):
                if message.type == "system":
                    content = "\n\n".join(part for part in (config.prompt_prepend, message.content, config.prompt_append) if part)
                    prompt[index] = message.model_copy(update={"content": content})
                    break
            else:
                raise ValueError("Memory prompt overlays require a system message in the configured chat template")
        return current_memory, prompt

    def _has_manual_facts(self, memory: dict[str, Any]) -> bool:
        """Return whether ``memory`` contains any user-authored (manual) fact."""
        return any(isinstance(f, dict) and isinstance(f.get("source"), dict) and f.get("source", {}).get("type") == "manual" for f in memory.get("facts", []))

    def _emit_extraction_metrics(
        self,
        metrics: dict[str, Any],
        *,
        thread_id: str | None,
        user_id: str | None,
        trace_id: str | None,
        model_name: str | None,
        response: Any,
        success: bool,
    ) -> None:
        """Invoke the post-extraction observability callback (Langfuse span etc.).

        No-op when ``extraction_callback`` is unset (default). Exceptions from
        the callback are logged and swallowed so observability never breaks the
        update path.
        """
        callback = self._config.extraction_callback
        if callback is None:
            return
        usage = getattr(response, "usage_metadata", None)
        payload: dict[str, Any] = {
            "thread_id": thread_id,
            "user_id": user_id,
            "trace_id": trace_id,
            "model_name": model_name,
            "success": success,
            "token_usage": usage if isinstance(usage, dict) else None,
        }
        payload.update(metrics)
        try:
            callback(payload)
        except Exception:
            logger.warning("extraction_callback raised; ignoring", exc_info=True)

    def _judge_batch(
        self,
        hook: Any,
        *,
        batch_text: str,
        signals: frozenset[str],
        thread_id: str | None,
        agent_name: str | None,
        user_id: str | None,
        trace_id: str | None,
        bypass_watermark: bool,
        message_count: int,
    ) -> Any:
        """Ask an injected memory judge about this batch; ``None`` when unjudged.

        The hook is a plain callable over a mapping -- the same convention as
        ``extraction_callback``'s payload -- so DeerMem stays host-agnostic (it
        imports no host judging types) while the host owns what a verdict means.

        A judge failure is logged and treated as "no opinion": pre-screening must
        never lose a memory and signal classification must never block one, so
        this path can only ever fall back to today's behaviour (design L2 / S2).
        """
        if hook is None:
            return None
        try:
            return hook(
                {
                    "batch_text": batch_text,
                    "signals": signals,
                    "staleness_review_enabled": bool(self._config.staleness_review_enabled),
                    "consolidation_enabled": bool(self._config.consolidation_enabled),
                    "bypass_watermark": bypass_watermark,
                    "thread_id": thread_id,
                    "user_id": user_id,
                    "agent_name": agent_name,
                    "trace_id": trace_id,
                    "message_count": message_count,
                }
            )
        except Exception:
            logger.warning("Memory judge failed; extracting as usual", exc_info=True)
            return None

    def _finalize_update(
        self,
        current_memory: dict[str, Any],
        response_content: Any,
        thread_id: str | None,
        agent_name: str | None,
        user_id: str | None = None,
        *,
        metrics: dict[str, Any] | None = None,
        signals: frozenset[str] = frozenset(),
    ) -> bool:
        """Parse the model response, apply updates, and persist memory."""
        update_data = _parse_memory_update_response(response_content)
        if metrics is not None:
            extracted = update_data.get("newFacts", [])
            extracted_list = extracted if isinstance(extracted, list) else []
            metrics["facts_extracted"] = len(extracted_list)
            # facts_passed_confidence / rejected_low_confidence are populated
            # inside _apply_updates at the real confidence-filter site, so the
            # metric tracks the actual filter rather than a re-derived copy here.
        if getattr(type(self._storage), "apply_changes", None) is not MemoryStorage.apply_changes:
            for attempt in range(3):
                capacity_decisions: list[tuple[FactEvictionDecision, FactEvictionDecision | None]] = []
                # Deep-copy before in-place mutation so a failed commit cannot
                # corrupt the cached snapshot. On a manifest conflict the
                # complete extraction result is reapplied to a fresh document;
                # its trim/consolidation/delete decisions are snapshot-wide and
                # must never be replayed as disjoint point writes.
                updated_memory = self._apply_updates(
                    copy.deepcopy(current_memory),
                    update_data,
                    thread_id,
                    metrics=metrics,
                    signals=signals,
                    agent_name=agent_name,
                    user_id=user_id,
                    capacity_decisions=capacity_decisions,
                )
                current_by_id = {str(fact.get("id")): fact for fact in current_memory.get("facts", [])}
                updated_by_id = {str(fact.get("id")): fact for fact in updated_memory.get("facts", [])}
                change_set = {
                    "upserts": [copy.deepcopy(fact) for fact_id, fact in updated_by_id.items() if current_by_id.get(fact_id) != fact],
                    "upsertRevisions": {fact_id: (int(current_by_id[fact_id].get("revision") or 1) if fact_id in current_by_id else None) for fact_id, fact in updated_by_id.items() if current_by_id.get(fact_id) != fact},
                    "deletes": [fact_id for fact_id in current_by_id if fact_id not in updated_by_id],
                    "deleteRevisions": {fact_id: int(current_by_id[fact_id].get("revision") or 1) for fact_id in current_by_id if fact_id not in updated_by_id},
                }
                summaries_changed = updated_memory.get("user", {}) != current_memory.get("user", {}) or updated_memory.get("history", {}) != current_memory.get("history", {})
                if summaries_changed:
                    change_set["summaries"] = {
                        "user": copy.deepcopy(updated_memory.get("user", {})),
                        "history": copy.deepcopy(updated_memory.get("history", {})),
                    }
                try:
                    self._storage.apply_changes(
                        change_set,
                        agent_name=agent_name,
                        user_id=user_id,
                        expected_manifest_revision=int(current_memory.get("revision") or 0),
                    )
                    for decision, shadow_decision in capacity_decisions:
                        self._record_capacity_decision(
                            decision,
                            shadow_decision,
                            agent_name=agent_name,
                            user_id=user_id,
                        )
                    return True
                except MemoryManifestRevisionConflict:
                    if attempt == 2:
                        raise
                    current_memory = self.reload_memory_data(agent_name, user_id=user_id)
                    logger.info("Retrying extracted memory update from a fresh snapshot after a revision conflict")
            raise AssertionError("bounded extracted-update retry did not return or raise")
        # Deep-copy before in-place mutation so a subsequent save() failure
        # cannot corrupt the still-cached original object reference.
        capacity_decisions = []
        updated_memory = self._apply_updates(
            copy.deepcopy(current_memory),
            update_data,
            thread_id,
            metrics=metrics,
            signals=signals,
            agent_name=agent_name,
            user_id=user_id,
            capacity_decisions=capacity_decisions,
        )
        saved = self._storage.save(
            updated_memory,
            agent_name,
            user_id=user_id,
            expected_revision=int(current_memory.get("revision") or 0),
        )
        if saved:
            for decision, shadow_decision in capacity_decisions:
                self._record_capacity_decision(
                    decision,
                    shadow_decision,
                    agent_name=agent_name,
                    user_id=user_id,
                )
        return saved

    async def aupdate_memory(
        self,
        messages: list[Any],
        thread_id: str | None = None,
        agent_name: str | None = None,
        signals: frozenset[str] = frozenset(),
        user_id: str | None = None,
        trace_id: str | None = None,
        *,
        bypass_watermark: bool = False,
        judge: bool = True,
    ) -> bool:
        """Update memory asynchronously by delegating to the sync path.

        Uses ``asyncio.to_thread`` to run the *sync* ``model.invoke()`` path
        in a worker thread so no second event loop is created and the
        langchain async httpx client pool (shared with the lead agent) is
        never touched.  This eliminates the cross-loop connection-reuse bug
        described in issue #2615.
        """
        return await asyncio.to_thread(
            self._do_update_memory_sync,
            messages=messages,
            thread_id=thread_id,
            agent_name=agent_name,
            signals=signals,
            user_id=user_id,
            trace_id=trace_id,
            bypass_watermark=bypass_watermark,
            judge=judge,
        )

    def _do_update_memory_sync(
        self,
        messages: list[Any],
        thread_id: str | None = None,
        agent_name: str | None = None,
        signals: frozenset[str] = frozenset(),
        user_id: str | None = None,
        trace_id: str | None = None,
        *,
        bypass_watermark: bool = False,
        judge: bool = True,
    ) -> bool:
        """Pure-sync memory update; bind ``trace_id`` into the request-trace
        ContextVar for the worker thread, then delegate to the impl.

        The update runs on a Timer / executor thread with no request ContextVar
        inheritance, so log records emitted here would otherwise lose the
        request trace id (it only reached the pre-LLM-call tracing hook before). The
        host-injected ``trace_context_manager`` hook (``None`` when DeerMem runs
        standalone, outside the deer-flow factory) binds ``trace_id`` for the
        duration of the call and restores the prior binding on exit. A ``None``
        trace_id leaves the ContextVar untouched (no fabricated id).
        """
        cm = self._config.trace_context_manager
        if cm is not None and trace_id is not None:
            with cm(trace_id):
                return self._do_update_memory_sync_impl(
                    messages=messages,
                    thread_id=thread_id,
                    agent_name=agent_name,
                    signals=signals,
                    user_id=user_id,
                    trace_id=trace_id,
                    bypass_watermark=bypass_watermark,
                    judge=judge,
                )
        return self._do_update_memory_sync_impl(
            messages=messages,
            thread_id=thread_id,
            agent_name=agent_name,
            signals=signals,
            user_id=user_id,
            trace_id=trace_id,
            bypass_watermark=bypass_watermark,
            judge=judge,
        )

    def _watermark_get(self, key: tuple[str | None, str | None, str | None]) -> tuple[str, ...] | None:
        """Return the watermark for ``key``, marking it most-recently-used.

        Uses key presence (not value truthiness) so a stored ``None`` identity
        still counts as a live entry for LRU ordering.
        """
        if key not in self._watermarks:
            return None
        self._watermarks.move_to_end(key)
        return self._watermarks[key]

    def _watermark_set(
        self,
        key: tuple[str | None, str | None, str | None],
        value: tuple[str, ...] | None,
    ) -> None:
        """Store ``value`` for ``key``, evicting the least-recently-used entry
        when the bounded LRU cache exceeds ``config.watermark_max_keys``, and
        write a real identity through to the storage sidecar.

        A dropped key is safe: the next turn for that thread finds no watermark
        and re-extracts one batch. ``0`` = unbounded (no eviction).
        """
        self._watermarks[key] = value
        self._watermarks.move_to_end(key)
        cap = self._config.watermark_max_keys
        if cap > 0 and len(self._watermarks) > cap:
            self._watermarks.popitem(last=False)
        self._store_persisted_watermark(key, value)

    @staticmethod
    def _persisted_watermark_scope(key: tuple[str | None, str | None, str | None]) -> tuple[str, str | None, str] | None:
        """Return ``(thread_id, user_id, agent_name)`` when ``key`` can be
        persisted; the sidecar is per agent and keyed by thread id."""
        thread_id, user_id, agent_name = key
        if not isinstance(thread_id, str) or not thread_id or agent_name is None:
            return None
        return thread_id, user_id, agent_name

    def _load_persisted_watermark(self, key: tuple[str | None, str | None, str | None]) -> tuple[str, ...] | None:
        """Read ``key``'s watermark from the storage sidecar.

        ``None`` when the storage keeps none or the read fails: the sidecar is
        best-effort, so the in-process cache then decides alone.
        """
        scope = self._persisted_watermark_scope(key)
        getter = getattr(self._storage, "get_extraction_watermark", None)
        if scope is None or getter is None:
            return None
        thread_id, user_id, agent_name = scope
        try:
            value = getter(thread_id, agent_name=agent_name, user_id=user_id)
        except Exception:
            logger.warning("Failed to read the persisted memory watermark (thread=%s)", thread_id, exc_info=True)
            return None
        if isinstance(value, list | tuple) and value and all(isinstance(part, str) for part in value):
            return tuple(value)
        return None

    def _store_persisted_watermark(
        self,
        key: tuple[str | None, str | None, str | None],
        value: tuple[str, ...] | None,
    ) -> None:
        """Write ``key``'s watermark to the storage sidecar, best-effort.

        A ``None`` identity (the last message has neither id nor text) is not
        written: the persisted entry, possibly advanced by a peer, still marks
        an extracted prefix, and the furthest-of-both read keeps using it.
        A failure is logged and leaves the in-process cache authoritative for
        this process; the extraction it follows has already been persisted, so
        it must not turn into a failed update.
        """
        scope = self._persisted_watermark_scope(key)
        setter = getattr(self._storage, "set_extraction_watermark", None)
        if value is None or scope is None or setter is None:
            return
        thread_id, user_id, agent_name = scope
        try:
            setter(thread_id, list(value), agent_name=agent_name, user_id=user_id)
        except Exception:
            logger.warning("Failed to persist the memory watermark (thread=%s)", thread_id, exc_info=True)

    def _feed_after_watermark(
        self,
        watermark_key: tuple[str | None, str | None, str | None],
        messages: list[Any],
    ) -> list[Any]:
        """Return the slice of ``messages`` not yet extracted.

        The watermark stores the identity of the last-extracted message (see
        :func:`_message_identity`). Two copies are consulted: this process's LRU
        entry and the storage sidecar (written by this process, an earlier one,
        or a peer replica sharing the storage root). Each marks a prefix that
        was already extracted, so the feed starts after whichever is found
        furthest along ``messages``; a stale copy therefore costs nothing. If
        neither is present (front removed by summarization, or the first-ever
        extraction for this key) the full list is fed. Re-feeding is safe
        over-extraction -- it never skips a turn, which is the only failure
        direction that would lose facts.
        """
        candidates = {self._watermark_get(watermark_key), self._load_persisted_watermark(watermark_key)} - {None}
        if not candidates:
            return messages
        identities = [_message_identity(msg) for msg in messages]
        start = 0
        for last_id in candidates:
            if last_id in identities:
                start = max(start, identities.index(last_id) + 1)
        return messages[start:]

    def _do_update_memory_sync_impl(
        self,
        messages: list[Any],
        thread_id: str | None = None,
        agent_name: str | None = None,
        signals: frozenset[str] = frozenset(),
        user_id: str | None = None,
        trace_id: str | None = None,
        *,
        bypass_watermark: bool = False,
        judge: bool = True,
    ) -> bool:
        """Pure-sync memory update using ``model.invoke()``.

        Uses the *sync* LLM call path so no event loop is created.  This
        guarantees that the langchain provider's globally cached async
        httpx ``AsyncClient`` / connection pool (the one shared with the
        lead agent) is never touched - no cross-loop connection reuse is
        possible.

        Watermark: the middleware passes the full conversation each turn, so
        without skipping already-extracted turns every update re-feeds old
        messages. The watermark stores the identity of the last-extracted
        message (content/id based, cached in-process and persisted per agent
        by the storage) so it stays correct when summarization removes the
        conversation front and survives a restart or a move to a peer replica
        (see :meth:`_feed_after_watermark`). ``bypass_watermark`` is set by the
        emergency (summarization) flush path: the subset it carries is a one-shot
        "extract before removal" snapshot, so it is fed in full and does not
        read or advance the conversation watermark (advancing it from the
        subset's own length would regress the watermark and skip un-extracted
        tail turns on the next normal feed).
        """
        metrics: dict[str, Any] = {}
        response: Any = None
        model_name: str | None = None
        success = False
        attempted = False
        try:
            watermark_key = (thread_id, user_id, agent_name)
            if bypass_watermark:
                # Emergency flush: extract the carried subset in full.
                feed_messages = messages
            else:
                feed_messages = self._feed_after_watermark(watermark_key, messages)
            if not feed_messages:
                logger.debug("Memory update skipped: no new messages since watermark (thread=%s)", thread_id)
                return True
            # Re-detect signals on the post-watermark feed so extraction hints
            # reference only turns the LLM will actually see. The admission-time
            # ``signals`` (detected on the full conversation in DeerMem) already
            # served their purpose (backpressure admission at enqueue); the hint
            # is a soft nudge and must not point at turns the watermark excluded.
            feed_signals = detect_signals(feed_messages, patterns_dir=self._config.patterns_dir)
            # The judge's L3 veto reads the whole batch, not the hint window: a skip
            # consumes every turn fed here (it advances the watermark), so an explicit
            # signal anywhere in the batch has to keep that batch out of judging. The
            # extraction hint above keeps the default 6-message window -- a hint points
            # at recent turns, a veto answers for the batch.
            batch_signals = detect_signals(feed_messages, patterns_dir=self._config.patterns_dir, window=None)
            batch_text = format_conversation_for_update(feed_messages)
            # The memory judge (when the host injected one) runs here: still off the
            # turn path, before any LLM call, on exactly the text the extractor would
            # see -- no second truncation. ``judge=False`` (the shutdown drain) and a
            # ``None`` hook both leave the batch unjudged.
            verdict = self._judge_batch(
                self._config.judge if judge else None,
                batch_text=batch_text,
                signals=frozenset(batch_signals),
                thread_id=thread_id,
                agent_name=agent_name,
                user_id=user_id,
                trace_id=trace_id,
                bypass_watermark=bypass_watermark,
                message_count=len(feed_messages),
            )
            verdict_payload = getattr(verdict, "payload", None)
            if isinstance(verdict_payload, dict):
                metrics.update({key: value for key, value in verdict_payload.items() if value is not None})
            if getattr(verdict, "skip", False):
                # The pre-screen decided this batch is not worth a call: consume it
                # and advance the watermark (nothing else runs -- no prompt, no
                # invoke, no apply). Advancing is what makes the saving real; leaving
                # the watermark put would re-judge a longer batch every turn and the
                # digest-keyed cache could never hit.
                if not bypass_watermark:
                    self._watermark_set(watermark_key, _message_identity(messages[-1]))
                success = True
                # The judge record is this batch's only trace, so emit it even though
                # no LLM call happened (the finally-block gate reads this flag).
                attempted = True
                logger.info("Memory extraction skipped by the pre-screen (thread=%s)", thread_id)
                return True
            model_hints = getattr(verdict, "hints", None)
            prepared = self._prepare_update_prompt(
                messages=feed_messages,
                agent_name=agent_name,
                # Hint text takes the union (deterministic + model hints); the
                # reinforcement evidence gate below still reads the deterministic
                # set only, so a model verdict can never confirm a fact (S4).
                signals=frozenset(feed_signals) | (model_hints if isinstance(model_hints, frozenset) else frozenset()),
                user_id=user_id,
                conversation_text=batch_text,
            )
            if prepared is None:
                return False

            current_memory, prompt = prepared
            model_name = self._config.model.model
            model = self._llm
            if model is None:
                raise RuntimeError("DeerMem memory update requested but no LLM is configured (set memory.backend_config.model in config).")
            invoke_config: dict[str, Any] = {"run_name": "memory_agent"}
            # Pre-LLM-call observability hook (e.g. langfuse): merge trace
            # metadata into invoke_config before the call so a tracer emits a
            # span at the LLM boundary. None = no tracing (langfuse not
            # hard-required). Subsumes the former backend_config.tracing_callback.
            if self._callbacks is not None:
                self._callbacks.on_memory_llm_call(
                    invoke_config,
                    thread_id=thread_id,
                    user_id=user_id,
                    trace_id=trace_id,
                    model_name=model_name,
                )
            logger.info("Invoking memory-update LLM (thread=%s trace_id=%s)", thread_id, trace_id)
            attempted = True
            started = time.monotonic()
            try:
                response = model.invoke(prompt, config=invoke_config)
            # Deliberately broader than `Exception` so no terminal path of the
            # provider call goes unobserved. This is NOT about asyncio
            # cancellation: this whole method runs on a worker thread (the
            # debounce timer, or the executor `update_memory` offloads to), and
            # cancelling the awaiting side never interrupts a running thread, so
            # `CancelledError` cannot arrive here. Reporting costs nothing on
            # this path either way — the hook below is a non-blocking submit.
            except BaseException as exc:
                self._notify_llm_result(
                    invoke_config,
                    prompt=prompt,
                    response=None,
                    error=exc,
                    started=started,
                    model_name=model_name,
                )
                raise
            self._notify_llm_result(
                invoke_config,
                prompt=prompt,
                response=response,
                error=None,
                started=started,
                model_name=model_name,
            )
            success = self._finalize_update(
                current_memory=current_memory,
                response_content=response.content,
                thread_id=thread_id,
                agent_name=agent_name,
                user_id=user_id,
                metrics=metrics,
                signals=frozenset(feed_signals),
            )
            if success and not bypass_watermark:
                # Advance the watermark to the last message fed (the feed is a
                # suffix, so this is messages[-1]). Skipped on the emergency
                # path -- the subset's last message is older than the
                # conversation's latest, so advancing from it would regress.
                self._watermark_set(watermark_key, _message_identity(messages[-1]))
            return success
        except json.JSONDecodeError as e:
            logger.warning("Failed to parse LLM response for memory update: %s", e)
            return False
        except Exception as e:
            logger.exception("Memory update failed: %s", e)
            return False
        finally:
            # Emit metrics even when _finalize_update (or invoke) raises, so the
            # observability callback sees exception failures (parse errors,
            # storage errors after retry) rather than only the happy path. The
            # pre-attempt early returns (no new messages, empty conversation, no
            # model) do not emit, matching the prior behavior.
            if attempted:
                if not success:
                    # A failed extraction persisted nothing, so the apply-site
                    # counter must not be published. The evaluation script scores a
                    # present counter even on ``success=False`` (it is treated as an
                    # outcome, not a censored failure), which would register a
                    # rejected commit as a missed memory. Absent + failed is censored
                    # -- the honest reading (persistent-mutation contract).
                    metrics.pop("mutations_accepted", None)
                self._emit_extraction_metrics(
                    metrics,
                    thread_id=thread_id,
                    user_id=user_id,
                    trace_id=trace_id,
                    model_name=model_name,
                    response=response,
                    success=success,
                )

    def _notify_llm_result(
        self,
        invoke_config: dict[str, Any],
        *,
        prompt: Any,
        response: Any,
        error: BaseException | None,
        started: float,
        model_name: str | None,
    ) -> None:
        """Fire the optional host result hook without affecting the update."""
        if self._callbacks is None:
            return
        hook = getattr(self._callbacks, "on_memory_llm_result", None)
        if hook is None:
            return
        try:
            hook(
                invoke_config,
                prompt=prompt,
                response=response,
                error=error,
                duration_ms=(time.monotonic() - started) * 1000,
                model_name=model_name,
            )
        except Exception:
            # Only the hook's own failures are non-fatal. `SystemExit` /
            # `KeyboardInterrupt` mean the process is going down and must not be
            # swallowed by an observability path.
            logger.warning("Memory LLM result hook failed (non-fatal)", exc_info=True)

    def update_memory(
        self,
        messages: list[Any],
        thread_id: str | None = None,
        agent_name: str | None = None,
        signals: frozenset[str] = frozenset(),
        user_id: str | None = None,
        trace_id: str | None = None,
        *,
        bypass_watermark: bool = False,
        judge: bool = True,
    ) -> bool:
        """Synchronously update memory using the sync LLM path.

        Uses ``model.invoke()`` (sync HTTP) which operates on a completely
        separate connection pool from the async ``AsyncClient`` shared by
        the lead agent.  This eliminates the cross-loop connection-reuse
        bug described in issue #2615.

        ``judge=False`` forbids this batch from being judged by the injected
        memory judge (the shutdown-drain path sets it: the drain budget belongs
        to persistence, not to a cost optimization).

        When called from within a running event loop (e.g. from a LangGraph
        node), the blocking sync call is offloaded to a thread pool so the
        caller's loop is not blocked.

        Args:
            messages: List of conversation messages.
            thread_id: Optional thread ID for tracking source.
            agent_name: If provided, updates per-agent memory. If None, updates global memory.
            signals: Signal classes detected in the conversation (correction /
                reinforcement / preference / ...), used as extraction hints.
            user_id: If provided, scopes memory to a specific user.

        Returns:
            True if the update persisted. False on any failure (no content,
            unparseable response, LLM error); failures are swallowed (best-effort)
            -- a failed update is re-fed on the next conversation turn because the
            watermark does not advance on failure.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            try:
                future = _SYNC_MEMORY_UPDATER_EXECUTOR.submit(
                    self._do_update_memory_sync,
                    messages=messages,
                    thread_id=thread_id,
                    agent_name=agent_name,
                    signals=signals,
                    user_id=user_id,
                    trace_id=trace_id,
                    bypass_watermark=bypass_watermark,
                    judge=judge,
                )
                return future.result()
            except Exception:
                logger.exception("Failed to offload memory update to executor")
                return False

        return self._do_update_memory_sync(
            messages=messages,
            thread_id=thread_id,
            agent_name=agent_name,
            signals=signals,
            user_id=user_id,
            trace_id=trace_id,
            bypass_watermark=bypass_watermark,
            judge=judge,
        )

    def _apply_updates(
        self,
        current_memory: dict[str, Any],
        update_data: dict[str, Any],
        thread_id: str | None = None,
        *,
        metrics: dict[str, Any] | None = None,
        signals: frozenset[str] = frozenset(),
        agent_name: str | None = None,
        user_id: str | None = None,
        capacity_decisions: list[tuple[FactEvictionDecision, FactEvictionDecision | None]] | None = None,
    ) -> dict[str, Any]:
        """Apply LLM-generated updates to memory.

        Args:
            current_memory: Current memory data.
            update_data: Updates from LLM.
            thread_id: Optional thread ID for tracking.
            metrics: Optional observability dict. When provided, populated with
                confidence and scope-gate counters counted at their real filter
                sites, so observability cannot drift from actual acceptance.

        Returns:
            Updated memory data.
        """
        config = self._config
        now = utc_now_iso_z()
        # Mutations that actually landed, counted at their real apply sites. New
        # facts are counted only after they survive capacity enforcement (and any
        # consolidation pass), not at the append. This is the pre-screen's "worth
        # remembering" signal: a batch whose only effect was a summary rewrite
        # counts zero, so a skip that dropped it is not a missed memory
        # (pre-screening design §5).
        mutations_accepted = 0
        scope_gate_rejections: dict[str, dict[str, int]] = {
            "facts": {"missing": 0, "scope": 0, "durability": 0, "authority": 0},
            "summaries": {"missing": 0, "scope": 0, "authority": 0},
            "removals": {"missing": 0, "scope": 0, "replacement": 0},
            "consolidations": {"missing": 0, "scope": 0, "durability": 0, "authority": 0},
        }

        def reject_by_scope_gate(kind: str, reason: str) -> None:
            scope_gate_rejections[kind][reason] += 1

        # Explicit confirmation is distinct from extraction duplication. The
        # deterministic gate is batch-level: it proves only that a human
        # message among the last six filtered messages matched a reinforcement
        # pattern. The LLM remains responsible for binding that signal to an
        # existing id, which must be user-scoped and carry a non-empty reason.
        tracks_hybrid_signals = config.fact_eviction_policy == EVICTION_POLICY_HYBRID_V1 or config.fact_eviction_shadow_enabled
        if tracks_hybrid_signals and "reinforcement" in signals:
            reinforced_ids = {
                entry["id"]
                for entry in update_data.get("factsToReinforce", [])
                if isinstance(entry, dict) and entry.get("scope") == "user" and isinstance(entry.get("reason"), str) and entry["reason"].strip() and isinstance(entry.get("id"), str)
            }
            # Only an id that actually exists can be confirmed. A nonexistent
            # target changes nothing, so counting it would report an accepted
            # mutation that never landed (the pre-screen evaluation reads the
            # counter as "worth remembering").
            reinforced_ids &= {fact.get("id") for fact in current_memory.get("facts", []) if isinstance(fact, dict)}
            if reinforced_ids:
                current_memory["facts"] = [
                    {
                        **fact,
                        "lastConfirmedAt": now,
                        "confirmationCount": _next_confirmation_count(fact),
                    }
                    if isinstance(fact, dict) and fact.get("id") in reinforced_ids
                    else fact
                    for fact in current_memory.get("facts", [])
                ]
                mutations_accepted += len(reinforced_ids)

        # Update user sections
        user_updates = update_data.get("user", {})
        for section in ["workContext", "personalContext", "topOfMind", "cognitiveStyle"]:
            section_data = user_updates.get(section, {})
            if not isinstance(section_data, dict) or not section_data.get("shouldUpdate") or not section_data.get("summary"):
                continue
            rejection_reason = _summary_scope_gate_reason(section_data)
            if rejection_reason is not None:
                reject_by_scope_gate("summaries", rejection_reason)
            else:
                current_memory["user"][section] = {
                    "summary": section_data["summary"],
                    "updatedAt": now,
                }

        # Update history sections
        history_updates = update_data.get("history", {})
        for section in ["recentMonths", "earlierContext", "longTermBackground"]:
            section_data = history_updates.get(section, {})
            if not isinstance(section_data, dict) or not section_data.get("shouldUpdate") or not section_data.get("summary"):
                continue
            rejection_reason = _summary_scope_gate_reason(section_data)
            if rejection_reason is not None:
                reject_by_scope_gate("summaries", rejection_reason)
            else:
                current_memory["history"][section] = {
                    "summary": section_data["summary"],
                    "updatedAt": now,
                }

        # ── Staleness review: removals + lifetime extensions ──
        # Both operations share one staleness-candidate guardrail pass and one
        # candidate_ids set. proposed_remove_ids is hoisted out of the removals
        # sub-block so it covers ALL LLM-proposed removals, not just the ones
        # the per-cycle cap actually deleted: a fact the LLM wanted to remove
        # must never be silently extended even when the cap spares it.
        stale_removals = update_data.get("staleFactsToRemove", [])
        stale_extensions = update_data.get("staleFactsToExtend", [])
        has_staleness_ops = (isinstance(stale_removals, list) and stale_removals) or (isinstance(stale_extensions, list) and stale_extensions)
        if has_staleness_ops:
            # Deterministic guardrail: intersect with actual staleness candidates
            # so an LLM slip that emits a protected-category or non-aged fact id
            # is silently rejected.  Runs unconditionally so the apply-layer
            # protection is independent of model behavior AND of the
            # staleness_review_enabled flag.  Guard against legacy / hand-edited
            # facts that predate the id field: an aged, non-protected fact with
            # no "id" is a valid staleness candidate but has no id to intersect
            # against, so skip it here instead of raising KeyError.
            candidate_ids = {f["id"] for f in _select_stale_candidates(current_memory, config) if f.get("id") is not None}

            # ── Removals ──
            proposed_remove_ids: set[str] = set()
            if isinstance(stale_removals, list) and stale_removals:
                proposed_remove_ids = {entry["id"] for entry in stale_removals if isinstance(entry, dict) and "id" in entry}
                stale_ids_to_remove = proposed_remove_ids & candidate_ids

                if not stale_ids_to_remove:
                    stale_removals = []
                else:
                    # Safety cap: limit max staleness removals per cycle.  When
                    # the LLM returns more than the cap, keep only the
                    # lowest-confidence entries up to the limit so the most
                    # questionable facts are removed first.
                    max_stale = config.staleness_max_removals_per_cycle
                    if len(stale_ids_to_remove) > max_stale:
                        stale_facts = [f for f in current_memory.get("facts", []) if f.get("id") in stale_ids_to_remove]
                        stale_facts.sort(key=_coerce_source_confidence)
                        stale_ids_to_remove = {f["id"] for f in stale_facts[:max_stale]}

                    current_memory["facts"] = [f for f in current_memory.get("facts", []) if f.get("id") not in stale_ids_to_remove]

                # Log removals for observability
                for entry in stale_removals:
                    if isinstance(entry, dict) and entry.get("id") in stale_ids_to_remove:
                        logger.info(
                            "Staleness review removed fact %s: %s",
                            entry["id"],
                            entry.get("reason", "no reason provided"),
                        )

            # ── Lifetime extensions ──
            # Recalibrate expected_valid_days for facts the LLM chose to keep.
            # Eligible facts are stale candidates that the LLM did NOT propose
            # for removal - including those that survived only because the
            # per-cycle cap prevented their deletion.  The new window is
            # min(days_since + extend_by_days, staleness_max_extension_days).
            # Extensions use an absolute ceiling rather than the creation-time
            # multiplier cap: they are deliberate review decisions and must be
            # able to advance the window beyond the original creation cap, but
            # an absolute bound prevents timedelta overflow and LLM misfire.
            if isinstance(stale_extensions, list) and stale_extensions:
                # Exclude all LLM-proposed removals, not just the trimmed set,
                # so a cap-surviving proposed-removal fact is never extended.
                extendable_ids = candidate_ids - proposed_remove_ids
                ext_by_id = {e["id"]: e for e in stale_extensions if isinstance(e, dict) and isinstance(e.get("id"), str) and e["id"] in extendable_ids}
                if ext_by_id:
                    now_utc = datetime.now(UTC)
                    max_ext = config.staleness_max_extension_days
                    updated_facts: list[dict[str, Any]] = []
                    for fact in current_memory.get("facts", []):
                        fid = fact.get("id")
                        ext = ext_by_id.get(fid) if fid else None
                        if ext is not None:
                            extend_by = ext.get("extend_by_days")
                            if isinstance(extend_by, (int, float)) and not isinstance(extend_by, bool):
                                extend_by_int = int(extend_by)  # coerce before guard
                                if extend_by_int > 0:
                                    created = _parse_fact_datetime(fact.get("createdAt", ""))
                                    if created is None:
                                        # Unreachable: _select_stale_candidates already
                                        # excludes facts with unparseable createdAt.
                                        updated_facts.append(fact)
                                        continue
                                    days_since = int((now_utc - created).total_seconds() // 86400)
                                    new_evd = min(days_since + extend_by_int, max_ext)
                                    fact = {**fact, "expected_valid_days": new_evd}
                                    logger.info(
                                        "Staleness review extended fact %s by %d days (new expected_valid_days: %d): %s",
                                        fid,
                                        extend_by_int,
                                        new_evd,
                                        ext.get("reason", "no reason provided"),
                                    )
                        updated_facts.append(fact)
                    current_memory["facts"] = updated_facts

        # Add new facts
        existing_fact_keys = {fact_key for fact_key in (_fact_content_key(fact.get("content")) for fact in current_memory.get("facts", [])) if fact_key is not None}
        new_facts = update_data.get("newFacts", [])
        # Creation-time lifetime cap shared with the consolidation path below, so
        # both fact-creation sites apply the identical bound in one place.
        creation_cap = int(config.staleness_age_days * config.staleness_max_lifetime_multiplier)
        # Two independent accept filters govern new facts: the deterministic
        # scope gate and this confidence threshold. Each is counted at its own
        # filter site so neither metric can drift from the filter it reports:
        # ``facts_passed_confidence`` counts threshold-passers even when the
        # scope gate rejects them, and the scope-gate counters increment
        # whether or not the confidence check passes. Duplicate / empty /
        # over-cap facts that pass the threshold are still counted here -- the
        # metric is a confidence-gate signal (the host's rejection-rate
        # warning monitors confidence filtering, not dedup / over-cap), not a
        # persisted-fact count.
        passed_threshold = 0
        replacement_fact_keys: dict[int, str] = {}
        # Fact IDs appended by this pass. They count as accepted mutations only
        # if they survive to the final fact set (see the metrics block): capacity
        # enforcement can evict one immediately, and a later consolidation can
        # consume one as a source.
        added_fact_ids: list[str] = []
        # Existing fact IDs a near-duplicate merge actually changed (confidence
        # raised). Counted under the same survival rule: a no-op merge (proposed
        # confidence not higher) changed nothing and must not count.
        changed_merge_ids: set[str] = set()
        # Legacy id-less facts cannot be matched by id, so they are tracked by
        # object identity; the target dicts stay alive in the memory being edited.
        changed_merge_facts: dict[int, dict[str, Any]] = {}
        # A correction must keep its proposed content, not inherit an older
        # paraphrase. Also avoid strengthening any proposed removal target,
        # including stale targets retained by candidate guards or the cap.
        # This only excludes dedup matches; removal validation remains below.
        removal_proposals = [removal for key in ("factsToRemove", "staleFactsToRemove") for removal in (update_data.get(key) if isinstance(update_data.get(key), list) else []) if isinstance(removal, dict)]
        removal_target_ids = {removal["id"] for removal in removal_proposals if isinstance(removal.get("id"), str)}
        replacement_indices = {index for removal in removal_proposals if isinstance(index := removal.get("replacementFactIndex"), int) and not isinstance(index, bool) and index >= 0}
        for fact_index, fact in enumerate(new_facts):
            confidence = fact.get("confidence", 0.5)
            if confidence >= config.fact_confidence_threshold:
                passed_threshold += 1
            rejection_reason = _fact_scope_gate_reason(fact)
            if rejection_reason is not None:
                reject_by_scope_gate("facts", rejection_reason)
                continue
            if confidence < config.fact_confidence_threshold:
                continue
            raw_content = fact.get("content", "")
            if not isinstance(raw_content, str):
                continue
            normalized_content = raw_content.strip()
            fact_key = _fact_content_key(normalized_content)
            if fact_key is None:
                # Empty / whitespace-only content: skip it the same way the
                # non-string guard above does, instead of appending a blank
                # fact that violates the non-empty-content invariant.
                continue
            # Remember every eligible replacement's content key even when it is
            # already present. A paired removal is safe only if the post-trim
            # memory contains this content under an ID other than its target.
            replacement_fact_keys[fact_index] = fact_key
            if fact_key in existing_fact_keys:
                continue

            # Write-side near-duplicate gate (issue #5252): a proposed new fact
            # that paraphrases an existing same-category fact merges into it
            # instead of being appended. The existing id/content/createdAt stay
            # authoritative; source follows only a confidence increase, never
            # an unconfirmed lower-confidence restatement.
            if config.fact_dedup_enabled and fact_index not in replacement_indices:
                merge_target = _find_dedup_merge_target(
                    normalized_content,
                    fact.get("category", "context"),
                    [candidate for candidate in current_memory.get("facts", []) if candidate.get("id") not in removal_target_ids],
                    threshold=config.fact_dedup_similarity_threshold,
                )
                if merge_target is not None:
                    try:
                        existing_confidence = float(merge_target.get("confidence"))
                        if not math.isfinite(existing_confidence):
                            raise ValueError
                    except (TypeError, ValueError):
                        existing_confidence = 0.0
                    if confidence > existing_confidence:
                        merge_target["confidence"] = confidence
                        merge_target["source"] = thread_id or "unknown"
                        # This merge persisted a change to an existing fact, so it
                        # is a mutation outcome too -- but only once we know the
                        # target survives (the count below checks the final set).
                        merge_target_id = merge_target.get("id")
                        if isinstance(merge_target_id, str):
                            changed_merge_ids.add(merge_target_id)
                        else:
                            changed_merge_facts[id(merge_target)] = merge_target
                    if metrics is not None:
                        metrics["facts_merged_dedup"] = metrics.get("facts_merged_dedup", 0) + 1
                    # New proposals have no durable ID yet. Log their batch
                    # index, not personal fact text; this is a proposed write,
                    # not a claim that persistence has already succeeded.
                    logger.info(
                        "Near-duplicate fact merge proposed: target_id=%s proposal_index=%d confidence_raised=%s",
                        merge_target.get("id"),
                        fact_index,
                        confidence > existing_confidence,
                    )
                    continue

            fact_entry = {
                "id": f"fact_{uuid.uuid4().hex[:8]}",
                "content": normalized_content,
                "category": fact.get("category", "context"),
                "confidence": confidence,
                "createdAt": now,
                "source": thread_id or "unknown",
            }
            source_error = fact.get("sourceError")
            if isinstance(source_error, str):
                normalized_source_error = source_error.strip()
                if normalized_source_error:
                    fact_entry["sourceError"] = normalized_source_error
            evd = _read_expected_valid_days(fact)
            if evd is not None:
                # Apply the creation-time cap so the LLM cannot assign an
                # unbounded lifetime that defers staleness review indefinitely.
                # Extensions (staleFactsToExtend) bypass this cap via their own
                # staleness_max_extension_days ceiling because they represent a
                # deliberate review decision, not an unchecked initial assignment.
                fact_entry["expected_valid_days"] = min(evd, creation_cap)
            current_memory["facts"].append(fact_entry)
            existing_fact_keys.add(fact_key)
            added_fact_ids.append(fact_entry["id"])

        # Enforce one capacity policy across automatic, manual, and import
        # writes. Usage comes from a separate sidecar, so scoring never rewrites
        # canonical fact timestamps merely because a query recalled them.
        current_memory["facts"], capacity_decision, shadow_decision = self._select_for_capacity(
            current_memory["facts"],
            agent_name=agent_name,
            user_id=user_id,
        )
        if capacity_decision is not None and capacity_decisions is not None:
            capacity_decisions.append((capacity_decision, shadow_decision))

        # Remove contradicted facts only after replacements have passed both
        # gates and survived deduplication/trimming. Task-local contradictions
        # cannot delete user memory, and a failed paired replacement cannot
        # degrade into a delete-only update.
        fact_ids_to_remove: set[str] = set()
        for removal in update_data.get("factsToRemove", []):
            if not isinstance(removal, dict):
                reject_by_scope_gate("removals", "missing")
                continue
            rejection_reason = _removal_scope_gate_reason(removal)
            if rejection_reason is not None:
                reject_by_scope_gate("removals", rejection_reason)
                continue
            fact_id = removal.get("id")
            if not isinstance(fact_id, str) or not fact_id:
                reject_by_scope_gate("removals", "missing")
                continue
            if "replacementFactIndex" in removal:
                replacement_index = removal.get("replacementFactIndex")
                if not isinstance(replacement_index, int) or isinstance(replacement_index, bool) or replacement_index < 0:
                    reject_by_scope_gate("removals", "replacement")
                    continue
                replacement_key = replacement_fact_keys.get(replacement_index)
                if replacement_key is None or not any(fact.get("id") != fact_id and _fact_content_key(fact.get("content")) == replacement_key for fact in current_memory.get("facts", [])):
                    reject_by_scope_gate("removals", "replacement")
                    continue
            fact_ids_to_remove.add(fact_id)

        if fact_ids_to_remove:
            # Count only targets that actually existed: a scope-valid removal of
            # a nonexistent id deletes nothing, so counting it would report an
            # accepted mutation that never landed (the pre-screen evaluation
            # reads the counter as "worth remembering").
            landed_removals = fact_ids_to_remove & {fact.get("id") for fact in current_memory.get("facts", []) if isinstance(fact, dict)}
            if landed_removals:
                current_memory["facts"] = [fact for fact in current_memory.get("facts", []) if fact.get("id") not in landed_removals]
                mutations_accepted += len(landed_removals)

        # ── Memory consolidation ──
        # Runs after the max_facts trim so source facts that were just evicted
        # (low confidence, pushed out by high-confidence newFacts) are absent
        # from fact_index and rejected by the existence guardrail - preventing
        # the only real data-loss scenario where sources are deleted but the
        # merged replacement is itself trimmed away.  Because consolidation
        # always removes ≥2 facts and adds 1, running it after trim cannot push
        # the total above max_facts.
        # Gate on the feature flag at apply time so a config change that races
        # with a debounced update does not silently merge facts the operator
        # intended to keep separate.
        if config.consolidation_enabled:
            consolidation_decisions = update_data.get("factsToConsolidate", [])
            if isinstance(consolidation_decisions, list) and consolidation_decisions:
                fact_index = {f.get("id"): f for f in current_memory.get("facts", []) if isinstance(f, dict)}
                max_groups = config.consolidation_max_groups_per_cycle
                max_sources = config.consolidation_max_sources
                # Creation-time lifetime cap shared with the newFacts path: an
                # inherited expected_valid_days is clamped so a merge of long-lived
                # sources cannot defer first review indefinitely.
                creation_cap = int(config.staleness_age_days * config.staleness_max_lifetime_multiplier)
                ids_consumed: set[str] = set()
                new_consolidated: list[dict[str, Any]] = []
                merge_count = 0

                # Mirror the staleness-pass guardrail: build the set of IDs the LLM
                # was legitimately allowed to see as candidates (excludes protected
                # categories and categories below the threshold).  Any LLM slip that
                # proposes a protected or ineligible fact ID is rejected here regardless
                # of model behaviour, matching how staleness intersects with
                # _select_stale_candidates before applying removals.  Skip id-less
                # legacy facts (they can never be targeted by the id-based source set).
                allowed_source_ids = {f["id"] for group in _select_consolidation_candidates(current_memory, config).values() for f in group if f.get("id") is not None}

                # Iterate all decisions and count successes rather than pre-slicing,
                # so guard failures on early decisions cannot silently starve valid
                # later ones from the configured merge budget.
                for decision in consolidation_decisions:
                    if merge_count >= max_groups:
                        break

                    source_ids = decision.get("sourceIds", [])
                    consolidated = decision.get("consolidated", {})

                    # Guardrail: all source IDs must exist in the post-trim index,
                    # must not already be consumed by an earlier merge this cycle,
                    # and must be in allowed_source_ids - the set built from
                    # _select_consolidation_candidates, which excludes categories in
                    # staleness_protected_categories (default: "correction").  This
                    # mirrors the staleness apply-time check and ensures explicit user
                    # feedback is never silently merged away regardless of model behaviour.
                    if any(sid in ids_consumed or sid not in fact_index or sid not in allowed_source_ids for sid in source_ids):
                        continue
                    # Guardrail: 2..max_sources per group
                    if not (2 <= len(source_ids) <= max_sources):
                        continue

                    content = consolidated.get("content", "")
                    if not isinstance(content, str) or not content.strip():
                        continue
                    rejection_reason = _fact_scope_gate_reason(consolidated)
                    if rejection_reason is not None:
                        reject_by_scope_gate("consolidations", rejection_reason)
                        continue

                    source_confidences = [_coerce_source_confidence(fact_index[sid]) for sid in source_ids]
                    # _coerce_source_confidence already clamps each value to [0, 1],
                    # so max(source_confidences) ≤ 1.0 by contract.
                    max_source_conf = max(source_confidences)

                    # Use the LLM's returned confidence, capped at the source maximum so
                    # consolidation cannot inflate confidence.  Clamp to [0, 1] first so
                    # out-of-range values (e.g. 1.5) never leak even if the cap is later
                    # relaxed.  Falls back to max_source_conf when absent or malformed.
                    raw_llm_conf = consolidated.get("confidence")
                    if isinstance(raw_llm_conf, (int, float)) and not isinstance(raw_llm_conf, bool) and math.isfinite(float(raw_llm_conf)):
                        fact_confidence = min(max(0.0, min(float(raw_llm_conf), 1.0)), max_source_conf)
                    else:
                        fact_confidence = max_source_conf

                    # Skip merges whose result would fall below the storage threshold -
                    # same gate applied to newFacts, so consolidation never admits
                    # facts that the normal ingestion path would reject.
                    if fact_confidence < config.fact_confidence_threshold:
                        continue

                    # Carry the newest source's createdAt so the staleness clock
                    # reflects the age of the underlying information, not when
                    # synthesis happened.  consolidatedAt records the merge time
                    # for audit without resetting staleness eligibility.
                    # Use _parse_fact_datetime for crash-safe, timezone-aware comparison:
                    # a numeric createdAt would make string max() raise TypeError, and
                    # mixed Z/+00:00 formats sort wrong lexicographically.
                    _fallback_dt = _parse_fact_datetime(now) or datetime.now(UTC)
                    _source_dts = [_parse_fact_datetime(fact_index[sid].get("createdAt") or "") or _fallback_dt for sid in source_ids]
                    _newest_dt = max(_source_dts)
                    source_created_at = _newest_dt.isoformat().removesuffix("+00:00") + "Z"
                    new_fact: dict[str, Any] = {
                        "id": f"fact_{uuid.uuid4().hex[:8]}",
                        "content": content.strip(),
                        "category": consolidated.get("category", "context"),
                        "confidence": fact_confidence,
                        "createdAt": source_created_at,
                        "consolidatedAt": now,
                        "source": "consolidation",
                        "consolidatedFrom": list(source_ids),
                    }
                    # Propagate sourceError from any source fact so correction
                    # context (what went wrong and why) is not silently lost.
                    source_errors = list(dict.fromkeys(e for sid in source_ids if isinstance((e := fact_index[sid].get("sourceError")), str) and e.strip()))
                    if source_errors:
                        new_fact["sourceError"] = "\n".join(source_errors)

                    # Inherit expected_valid_days from the sources so the merged
                    # fact keeps the lifetime signal of the underlying information
                    # rather than silently degrading to the global staleness_age_days.
                    # The merged fact is re-reviewed at the EARLIEST source review
                    # deadline (createdAt + effective lifetime): a merge combines
                    # details from every source, and a volatile sub-detail (e.g.
                    # evd=7) must not inherit a stable source's 3650-day window and
                    # escape staleness review for years - staleness KEEP/REMOVE is the
                    # only path that re-validates a merged fact, so biasing toward the
                    # soonest deadline keeps uncertain merges re-checked sooner.
                    # Every source participates, including legacy facts without an
                    # explicit evd: their effective lifetime is the configured global
                    # staleness_age_days (matching _effective_fact_staleness_age's
                    # read-time fallback), so a legacy source's default 90-day window
                    # is not silently swallowed by a long-lived sibling. The deadline
                    # is expressed relative to the merged fact's createdAt (the newest
                    # source's), so a source already past its deadline yields a
                    # minimal positive window (review next cycle) rather than the
                    # global fallback, which would otherwise defer an overdue review.
                    # Capped at the creation-time multiplier (hoisted above the loop)
                    # like any new fact so consolidation cannot defer first review
                    # indefinitely.
                    # Compute each source's absolute review deadline
                    # (createdAt + effective lifetime). A huge persisted evd can
                    # overflow datetime arithmetic; _safe_add_days returns None
                    # then, and the source falls back to the global lifetime's
                    # deadline - the same treatment as a legacy (no-evd) source,
                    # so one malformed field cannot abort the merge.
                    global_age = config.staleness_age_days
                    source_deadlines: list[datetime] = []
                    for sid, dt in zip(source_ids, _source_dts):
                        eff = _effective_fact_staleness_age(fact_index[sid], config)
                        deadline = _safe_add_days(dt, eff)
                        if deadline is None:
                            deadline = _safe_add_days(dt, global_age) or _newest_dt
                        source_deadlines.append(deadline)
                    earliest_deadline = min(source_deadlines)
                    # int(total_seconds() // 86400) avoids the .days toward-zero
                    # truncation inconsistency flagged in #4143; a negative result
                    # (a source already past its deadline) is clamped below.
                    days_until_earliest = int((earliest_deadline - _newest_dt).total_seconds() // 86400)
                    # A non-positive value means a source is already past its
                    # deadline (the merge itself was the overdue review) - surface
                    # a minimal positive window so the merged fact is re-reviewed
                    # next cycle instead of inheriting the global fallback.
                    inherited_evd = max(days_until_earliest, 1)
                    new_fact["expected_valid_days"] = min(inherited_evd, creation_cap)

                    ids_consumed.update(source_ids)
                    new_consolidated.append(new_fact)
                    merge_count += 1
                    logger.info(
                        "Consolidation merged %d facts into: %s",
                        len(source_ids),
                        content.strip()[:80],
                    )

                if ids_consumed:
                    current_memory["facts"] = [f for f in current_memory.get("facts", []) if f.get("id") not in ids_consumed]
                    current_memory["facts"].extend(new_consolidated)
                    mutations_accepted += merge_count

        # Finalization scrubs upload-event facts (session-scoped) from the memory it
        # persists; apply that here, before scoring survival, so a fact accepted by
        # the apply but dropped by the scrub is not counted as a landed mutation
        # (the shadow evaluation reads a positive count on a skip as a lost memory).
        current_memory = _strip_upload_mentions_from_memory(current_memory)

        # Count new facts and changed near-duplicate targets only once they survive
        # capacity enforcement. A proposed fact can pass the confidence gate and be
        # appended, then be immediately evicted by _select_for_capacity; a merge
        # target can be evicted the same way. Counting either would report an
        # accepted mutation even though the persistent facts are unchanged, and the
        # pre-screen evaluation reads any positive mutations_accepted on a skip as a
        # lost memory (memory/AGENTS.md, "worth remembering"). Scoring against the
        # final fact set also excludes a fact a later consolidation consumed as a
        # source, whose merge is counted separately.
        final_fact_ids = {fact.get("id") for fact in current_memory.get("facts", []) if isinstance(fact, dict)}
        mutations_accepted += sum(1 for fact_id in added_fact_ids if fact_id in final_fact_ids)
        mutations_accepted += sum(1 for fact_id in changed_merge_ids if fact_id in final_fact_ids)
        if changed_merge_facts:
            surviving_objects = {id(fact) for fact in current_memory.get("facts", []) if isinstance(fact, dict)}
            mutations_accepted += sum(1 for object_id in changed_merge_facts if object_id in surviving_objects)

        if metrics is not None:
            metrics["facts_passed_confidence"] = passed_threshold
            metrics["rejected_low_confidence"] = len(new_facts) - passed_threshold
            metrics["facts_passed_scope_gate"] = len(new_facts) - sum(scope_gate_rejections["facts"].values())
            metrics["rejected_by_scope_gate"] = sum(count for reasons in scope_gate_rejections.values() for count in reasons.values())
            metrics["scope_gate_rejections"] = scope_gate_rejections
            metrics["mutations_accepted"] = mutations_accepted

        return current_memory
